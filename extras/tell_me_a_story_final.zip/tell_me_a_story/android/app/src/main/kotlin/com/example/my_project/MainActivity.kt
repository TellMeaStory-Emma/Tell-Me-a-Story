package com.mycompany.tellmeastory

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
