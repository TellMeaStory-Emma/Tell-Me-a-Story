import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:csv/csv.dart';
import 'package:synchronized/synchronized.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    secureStorage = FlutterSecureStorage();
    await _safeInitAsync(() async {
      _lastReadingTime =
          await secureStorage.read(key: 'ff_lastReadingTime') != null
              ? DateTime.fromMillisecondsSinceEpoch(
                  (await secureStorage.getInt('ff_lastReadingTime'))!)
              : _lastReadingTime;
    });
    await _safeInitAsync(() async {
      _dailyStoryCount =
          await secureStorage.getInt('ff_dailyStoryCount') ?? _dailyStoryCount;
    });
    await _safeInitAsync(() async {
      _isPremium = await secureStorage.getBool('ff_isPremium') ?? _isPremium;
    });
    await _safeInitAsync(() async {
      _ReadStoriesList =
          (await secureStorage.getStringList('ff_ReadStoriesList'))
                  ?.map(int.parse)
                  .toList() ??
              _ReadStoriesList;
    });
    await _safeInitAsync(() async {
      _IDStory1 = await secureStorage.getInt('ff_IDStory1') ?? _IDStory1;
    });
    await _safeInitAsync(() async {
      _IDStory2 = await secureStorage.getInt('ff_IDStory2') ?? _IDStory2;
    });
    await _safeInitAsync(() async {
      _IDStory3 = await secureStorage.getInt('ff_IDStory3') ?? _IDStory3;
    });
    await _safeInitAsync(() async {
      _IDStory4 = await secureStorage.getInt('ff_IDStory4') ?? _IDStory4;
    });
    await _safeInitAsync(() async {
      _IDStory5 = await secureStorage.getInt('ff_IDStory5') ?? _IDStory5;
    });
    await _safeInitAsync(() async {
      _IDStory6 = await secureStorage.getInt('ff_IDStory6') ?? _IDStory6;
    });
    await _safeInitAsync(() async {
      _IDStory7 = await secureStorage.getInt('ff_IDStory7') ?? _IDStory7;
    });
    await _safeInitAsync(() async {
      _IDStory8 = await secureStorage.getInt('ff_IDStory8') ?? _IDStory8;
    });
    await _safeInitAsync(() async {
      _IDStory9 = await secureStorage.getInt('ff_IDStory9') ?? _IDStory9;
    });
    await _safeInitAsync(() async {
      _IDStory10 = await secureStorage.getInt('ff_IDStory10') ?? _IDStory10;
    });
    await _safeInitAsync(() async {
      _IDStory111 = await secureStorage.getInt('ff_IDStory111') ?? _IDStory111;
    });
    await _safeInitAsync(() async {
      _IDStory112 = await secureStorage.getInt('ff_IDStory112') ?? _IDStory112;
    });
    await _safeInitAsync(() async {
      _IDStory113 = await secureStorage.getInt('ff_IDStory113') ?? _IDStory113;
    });
    await _safeInitAsync(() async {
      _IDStory115 = await secureStorage.getInt('ff_IDStory115') ?? _IDStory115;
    });
    await _safeInitAsync(() async {
      _IDStory114 = await secureStorage.getInt('ff_IDStory114') ?? _IDStory114;
    });
    await _safeInitAsync(() async {
      _IDStory121 = await secureStorage.getInt('ff_IDStory121') ?? _IDStory121;
    });
    await _safeInitAsync(() async {
      _IDStory122 = await secureStorage.getInt('ff_IDStory122') ?? _IDStory122;
    });
    await _safeInitAsync(() async {
      _IDStory123 = await secureStorage.getInt('ff_IDStory123') ?? _IDStory123;
    });
    await _safeInitAsync(() async {
      _goldenHourStartTime =
          await secureStorage.read(key: 'ff_goldenHourStartTime') != null
              ? DateTime.fromMillisecondsSinceEpoch(
                  (await secureStorage.getInt('ff_goldenHourStartTime'))!)
              : _goldenHourStartTime;
    });
    await _safeInitAsync(() async {
      _isGoldenHour =
          await secureStorage.getBool('ff_isGoldenHour') ?? _isGoldenHour;
    });
    await _safeInitAsync(() async {
      _readStoryIDs =
          await secureStorage.getStringList('ff_readStoryIDs') ?? _readStoryIDs;
    });
    await _safeInitAsync(() async {
      _triggerNextPage =
          await secureStorage.getBool('ff_triggerNextPage') ?? _triggerNextPage;
    });
    await _safeInitAsync(() async {
      _isFirstTime =
          await secureStorage.getBool('ff_isFirstTime') ?? _isFirstTime;
    });
    await _safeInitAsync(() async {
      _isRated = await secureStorage.getBool('ff_isRated') ?? _isRated;
    });
    await _safeInitAsync(() async {
      _lastRatingPromptDate =
          await secureStorage.read(key: 'ff_lastRatingPromptDate') != null
              ? DateTime.fromMillisecondsSinceEpoch(
                  (await secureStorage.getInt('ff_lastRatingPromptDate'))!)
              : _lastRatingPromptDate;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late FlutterSecureStorage secureStorage;

  DateTime? _lastReadingTime =
      DateTime.fromMillisecondsSinceEpoch(1582549800000);
  DateTime? get lastReadingTime => _lastReadingTime;
  set lastReadingTime(DateTime? value) {
    _lastReadingTime = value;
    value != null
        ? secureStorage.setInt(
            'ff_lastReadingTime', value.millisecondsSinceEpoch)
        : secureStorage.remove('ff_lastReadingTime');
  }

  void deleteLastReadingTime() {
    secureStorage.delete(key: 'ff_lastReadingTime');
  }

  int _dailyStoryCount = 0;
  int get dailyStoryCount => _dailyStoryCount;
  set dailyStoryCount(int value) {
    _dailyStoryCount = value;
    secureStorage.setInt('ff_dailyStoryCount', value);
  }

  void deleteDailyStoryCount() {
    secureStorage.delete(key: 'ff_dailyStoryCount');
  }

  bool _isPremium = false;
  bool get isPremium => _isPremium;
  set isPremium(bool value) {
    _isPremium = value;
    secureStorage.setBool('ff_isPremium', value);
  }

  void deleteIsPremium() {
    secureStorage.delete(key: 'ff_isPremium');
  }

  List<int> _ReadStoriesList = [];
  List<int> get ReadStoriesList => _ReadStoriesList;
  set ReadStoriesList(List<int> value) {
    _ReadStoriesList = value;
    secureStorage.setStringList(
        'ff_ReadStoriesList', value.map((x) => x.toString()).toList());
  }

  void deleteReadStoriesList() {
    secureStorage.delete(key: 'ff_ReadStoriesList');
  }

  void addToReadStoriesList(int value) {
    ReadStoriesList.add(value);
    secureStorage.setStringList('ff_ReadStoriesList',
        _ReadStoriesList.map((x) => x.toString()).toList());
  }

  void removeFromReadStoriesList(int value) {
    ReadStoriesList.remove(value);
    secureStorage.setStringList('ff_ReadStoriesList',
        _ReadStoriesList.map((x) => x.toString()).toList());
  }

  void removeAtIndexFromReadStoriesList(int index) {
    ReadStoriesList.removeAt(index);
    secureStorage.setStringList('ff_ReadStoriesList',
        _ReadStoriesList.map((x) => x.toString()).toList());
  }

  void updateReadStoriesListAtIndex(
    int index,
    int Function(int) updateFn,
  ) {
    ReadStoriesList[index] = updateFn(_ReadStoriesList[index]);
    secureStorage.setStringList('ff_ReadStoriesList',
        _ReadStoriesList.map((x) => x.toString()).toList());
  }

  void insertAtIndexInReadStoriesList(int index, int value) {
    ReadStoriesList.insert(index, value);
    secureStorage.setStringList('ff_ReadStoriesList',
        _ReadStoriesList.map((x) => x.toString()).toList());
  }

  int _IDStory1 = 1;
  int get IDStory1 => _IDStory1;
  set IDStory1(int value) {
    _IDStory1 = value;
    secureStorage.setInt('ff_IDStory1', value);
  }

  void deleteIDStory1() {
    secureStorage.delete(key: 'ff_IDStory1');
  }

  int _IDStory2 = 2;
  int get IDStory2 => _IDStory2;
  set IDStory2(int value) {
    _IDStory2 = value;
    secureStorage.setInt('ff_IDStory2', value);
  }

  void deleteIDStory2() {
    secureStorage.delete(key: 'ff_IDStory2');
  }

  int _IDStory3 = 3;
  int get IDStory3 => _IDStory3;
  set IDStory3(int value) {
    _IDStory3 = value;
    secureStorage.setInt('ff_IDStory3', value);
  }

  void deleteIDStory3() {
    secureStorage.delete(key: 'ff_IDStory3');
  }

  int _IDStory4 = 4;
  int get IDStory4 => _IDStory4;
  set IDStory4(int value) {
    _IDStory4 = value;
    secureStorage.setInt('ff_IDStory4', value);
  }

  void deleteIDStory4() {
    secureStorage.delete(key: 'ff_IDStory4');
  }

  int _IDStory5 = 5;
  int get IDStory5 => _IDStory5;
  set IDStory5(int value) {
    _IDStory5 = value;
    secureStorage.setInt('ff_IDStory5', value);
  }

  void deleteIDStory5() {
    secureStorage.delete(key: 'ff_IDStory5');
  }

  int _IDStory6 = 6;
  int get IDStory6 => _IDStory6;
  set IDStory6(int value) {
    _IDStory6 = value;
    secureStorage.setInt('ff_IDStory6', value);
  }

  void deleteIDStory6() {
    secureStorage.delete(key: 'ff_IDStory6');
  }

  int _IDStory7 = 7;
  int get IDStory7 => _IDStory7;
  set IDStory7(int value) {
    _IDStory7 = value;
    secureStorage.setInt('ff_IDStory7', value);
  }

  void deleteIDStory7() {
    secureStorage.delete(key: 'ff_IDStory7');
  }

  int _IDStory8 = 8;
  int get IDStory8 => _IDStory8;
  set IDStory8(int value) {
    _IDStory8 = value;
    secureStorage.setInt('ff_IDStory8', value);
  }

  void deleteIDStory8() {
    secureStorage.delete(key: 'ff_IDStory8');
  }

  int _IDStory9 = 9;
  int get IDStory9 => _IDStory9;
  set IDStory9(int value) {
    _IDStory9 = value;
    secureStorage.setInt('ff_IDStory9', value);
  }

  void deleteIDStory9() {
    secureStorage.delete(key: 'ff_IDStory9');
  }

  int _IDStory10 = 10;
  int get IDStory10 => _IDStory10;
  set IDStory10(int value) {
    _IDStory10 = value;
    secureStorage.setInt('ff_IDStory10', value);
  }

  void deleteIDStory10() {
    secureStorage.delete(key: 'ff_IDStory10');
  }

  int _IDStory111 = 111;
  int get IDStory111 => _IDStory111;
  set IDStory111(int value) {
    _IDStory111 = value;
    secureStorage.setInt('ff_IDStory111', value);
  }

  void deleteIDStory111() {
    secureStorage.delete(key: 'ff_IDStory111');
  }

  int _IDStory112 = 112;
  int get IDStory112 => _IDStory112;
  set IDStory112(int value) {
    _IDStory112 = value;
    secureStorage.setInt('ff_IDStory112', value);
  }

  void deleteIDStory112() {
    secureStorage.delete(key: 'ff_IDStory112');
  }

  int _IDStory113 = 113;
  int get IDStory113 => _IDStory113;
  set IDStory113(int value) {
    _IDStory113 = value;
    secureStorage.setInt('ff_IDStory113', value);
  }

  void deleteIDStory113() {
    secureStorage.delete(key: 'ff_IDStory113');
  }

  int _IDStory115 = 115;
  int get IDStory115 => _IDStory115;
  set IDStory115(int value) {
    _IDStory115 = value;
    secureStorage.setInt('ff_IDStory115', value);
  }

  void deleteIDStory115() {
    secureStorage.delete(key: 'ff_IDStory115');
  }

  int _IDStory114 = 114;
  int get IDStory114 => _IDStory114;
  set IDStory114(int value) {
    _IDStory114 = value;
    secureStorage.setInt('ff_IDStory114', value);
  }

  void deleteIDStory114() {
    secureStorage.delete(key: 'ff_IDStory114');
  }

  int _IDStory121 = 121;
  int get IDStory121 => _IDStory121;
  set IDStory121(int value) {
    _IDStory121 = value;
    secureStorage.setInt('ff_IDStory121', value);
  }

  void deleteIDStory121() {
    secureStorage.delete(key: 'ff_IDStory121');
  }

  int _IDStory122 = 122;
  int get IDStory122 => _IDStory122;
  set IDStory122(int value) {
    _IDStory122 = value;
    secureStorage.setInt('ff_IDStory122', value);
  }

  void deleteIDStory122() {
    secureStorage.delete(key: 'ff_IDStory122');
  }

  int _IDStory123 = 123;
  int get IDStory123 => _IDStory123;
  set IDStory123(int value) {
    _IDStory123 = value;
    secureStorage.setInt('ff_IDStory123', value);
  }

  void deleteIDStory123() {
    secureStorage.delete(key: 'ff_IDStory123');
  }

  int _currentStoryID = 0;
  int get currentStoryID => _currentStoryID;
  set currentStoryID(int value) {
    _currentStoryID = value;
  }

  DateTime? _goldenHourStartTime =
      DateTime.fromMillisecondsSinceEpoch(954583920000);
  DateTime? get goldenHourStartTime => _goldenHourStartTime;
  set goldenHourStartTime(DateTime? value) {
    _goldenHourStartTime = value;
    value != null
        ? secureStorage.setInt(
            'ff_goldenHourStartTime', value.millisecondsSinceEpoch)
        : secureStorage.remove('ff_goldenHourStartTime');
  }

  void deleteGoldenHourStartTime() {
    secureStorage.delete(key: 'ff_goldenHourStartTime');
  }

  bool _isGoldenHour = false;
  bool get isGoldenHour => _isGoldenHour;
  set isGoldenHour(bool value) {
    _isGoldenHour = value;
    secureStorage.setBool('ff_isGoldenHour', value);
  }

  void deleteIsGoldenHour() {
    secureStorage.delete(key: 'ff_isGoldenHour');
  }

  List<String> _readStoryIDs = [];
  List<String> get readStoryIDs => _readStoryIDs;
  set readStoryIDs(List<String> value) {
    _readStoryIDs = value;
    secureStorage.setStringList('ff_readStoryIDs', value);
  }

  void deleteReadStoryIDs() {
    secureStorage.delete(key: 'ff_readStoryIDs');
  }

  void addToReadStoryIDs(String value) {
    readStoryIDs.add(value);
    secureStorage.setStringList('ff_readStoryIDs', _readStoryIDs);
  }

  void removeFromReadStoryIDs(String value) {
    readStoryIDs.remove(value);
    secureStorage.setStringList('ff_readStoryIDs', _readStoryIDs);
  }

  void removeAtIndexFromReadStoryIDs(int index) {
    readStoryIDs.removeAt(index);
    secureStorage.setStringList('ff_readStoryIDs', _readStoryIDs);
  }

  void updateReadStoryIDsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    readStoryIDs[index] = updateFn(_readStoryIDs[index]);
    secureStorage.setStringList('ff_readStoryIDs', _readStoryIDs);
  }

  void insertAtIndexInReadStoryIDs(int index, String value) {
    readStoryIDs.insert(index, value);
    secureStorage.setStringList('ff_readStoryIDs', _readStoryIDs);
  }

  bool _stopVideo = false;
  bool get stopVideo => _stopVideo;
  set stopVideo(bool value) {
    _stopVideo = value;
  }

  List<StoryBookStruct> _allStories = [];
  List<StoryBookStruct> get allStories => _allStories;
  set allStories(List<StoryBookStruct> value) {
    _allStories = value;
  }

  void addToAllStories(StoryBookStruct value) {
    allStories.add(value);
  }

  void removeFromAllStories(StoryBookStruct value) {
    allStories.remove(value);
  }

  void removeAtIndexFromAllStories(int index) {
    allStories.removeAt(index);
  }

  void updateAllStoriesAtIndex(
    int index,
    StoryBookStruct Function(StoryBookStruct) updateFn,
  ) {
    allStories[index] = updateFn(_allStories[index]);
  }

  void insertAtIndexInAllStories(int index, StoryBookStruct value) {
    allStories.insert(index, value);
  }

  StoryBookStruct _currentStory = StoryBookStruct();
  StoryBookStruct get currentStory => _currentStory;
  set currentStory(StoryBookStruct value) {
    _currentStory = value;
  }

  void updateCurrentStoryStruct(Function(StoryBookStruct) updateFn) {
    updateFn(_currentStory);
  }

  bool _isStoryPlaying = true;
  bool get isStoryPlaying => _isStoryPlaying;
  set isStoryPlaying(bool value) {
    _isStoryPlaying = value;
  }

  bool _audioFinished = false;
  bool get audioFinished => _audioFinished;
  set audioFinished(bool value) {
    _audioFinished = value;
  }

  bool _triggerNextPage = false;
  bool get triggerNextPage => _triggerNextPage;
  set triggerNextPage(bool value) {
    _triggerNextPage = value;
    secureStorage.setBool('ff_triggerNextPage', value);
  }

  void deleteTriggerNextPage() {
    secureStorage.delete(key: 'ff_triggerNextPage');
  }

  String _currentvideo = '';
  String get currentvideo => _currentvideo;
  set currentvideo(String value) {
    _currentvideo = value;
  }

  bool _isFirstTime = false;
  bool get isFirstTime => _isFirstTime;
  set isFirstTime(bool value) {
    _isFirstTime = value;
    secureStorage.setBool('ff_isFirstTime', value);
  }

  void deleteIsFirstTime() {
    secureStorage.delete(key: 'ff_isFirstTime');
  }

  bool _isGiftCollectedToday = false;
  bool get isGiftCollectedToday => _isGiftCollectedToday;
  set isGiftCollectedToday(bool value) {
    _isGiftCollectedToday = value;
  }

  bool _showBook = false;
  bool get showBook => _showBook;
  set showBook(bool value) {
    _showBook = value;
  }

  bool _isWelcomeBannerDismissed = false;
  bool get isWelcomeBannerDismissed => _isWelcomeBannerDismissed;
  set isWelcomeBannerDismissed(bool value) {
    _isWelcomeBannerDismissed = value;
  }

  bool _isRated = false;
  bool get isRated => _isRated;
  set isRated(bool value) {
    _isRated = value;
    secureStorage.setBool('ff_isRated', value);
  }

  void deleteIsRated() {
    secureStorage.delete(key: 'ff_isRated');
  }

  DateTime? _lastRatingPromptDate =
      DateTime.fromMillisecondsSinceEpoch(1596546600000);
  DateTime? get lastRatingPromptDate => _lastRatingPromptDate;
  set lastRatingPromptDate(DateTime? value) {
    _lastRatingPromptDate = value;
    value != null
        ? secureStorage.setInt(
            'ff_lastRatingPromptDate', value.millisecondsSinceEpoch)
        : secureStorage.remove('ff_lastRatingPromptDate');
  }

  void deleteLastRatingPromptDate() {
    secureStorage.delete(key: 'ff_lastRatingPromptDate');
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}

extension FlutterSecureStorageExtensions on FlutterSecureStorage {
  static final _lock = Lock();

  Future<void> writeSync({required String key, String? value}) async =>
      await _lock.synchronized(() async {
        await write(key: key, value: value);
      });

  void remove(String key) => delete(key: key);

  Future<String?> getString(String key) async => await read(key: key);
  Future<void> setString(String key, String value) async =>
      await writeSync(key: key, value: value);

  Future<bool?> getBool(String key) async => (await read(key: key)) == 'true';
  Future<void> setBool(String key, bool value) async =>
      await writeSync(key: key, value: value.toString());

  Future<int?> getInt(String key) async =>
      int.tryParse(await read(key: key) ?? '');
  Future<void> setInt(String key, int value) async =>
      await writeSync(key: key, value: value.toString());

  Future<double?> getDouble(String key) async =>
      double.tryParse(await read(key: key) ?? '');
  Future<void> setDouble(String key, double value) async =>
      await writeSync(key: key, value: value.toString());

  Future<List<String>?> getStringList(String key) async =>
      await read(key: key).then((result) {
        if (result == null || result.isEmpty) {
          return null;
        }
        return CsvToListConverter()
            .convert(result)
            .first
            .map((e) => e.toString())
            .toList();
      });
  Future<void> setStringList(String key, List<String> value) async =>
      await writeSync(key: key, value: ListToCsvConverter().convert([value]));
}
