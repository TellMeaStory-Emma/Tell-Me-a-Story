import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyACLbgh37OnmkhEWh32XQSiVDAXTCuczg4",
            authDomain: "tell-me-a-story-1d609.firebaseapp.com",
            projectId: "tell-me-a-story-1d609",
            storageBucket: "tell-me-a-story-1d609.firebasestorage.app",
            messagingSenderId: "386300568391",
            appId: "1:386300568391:web:89a4b0c400b10bb3bca262",
            measurementId: "G-8JXPR3EY6Q"));
  } else {
    await Firebase.initializeApp();
  }
}
