import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PartsRecord extends FirestoreRecord {
  PartsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "part_number" field.
  int? _partNumber;
  int get partNumber => _partNumber ?? 0;
  bool hasPartNumber() => _partNumber != null;

  // "part_title" field.
  String? _partTitle;
  String get partTitle => _partTitle ?? '';
  bool hasPartTitle() => _partTitle != null;

  // "part_image" field.
  String? _partImage;
  String get partImage => _partImage ?? '';
  bool hasPartImage() => _partImage != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _partNumber = castToType<int>(snapshotData['part_number']);
    _partTitle = snapshotData['part_title'] as String?;
    _partImage = snapshotData['part_image'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('parts')
          : FirebaseFirestore.instance.collectionGroup('parts');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('parts').doc(id);

  static Stream<PartsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PartsRecord.fromSnapshot(s));

  static Future<PartsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PartsRecord.fromSnapshot(s));

  static PartsRecord fromSnapshot(DocumentSnapshot snapshot) => PartsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PartsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PartsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PartsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PartsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPartsRecordData({
  int? partNumber,
  String? partTitle,
  String? partImage,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'part_number': partNumber,
      'part_title': partTitle,
      'part_image': partImage,
    }.withoutNulls,
  );

  return firestoreData;
}

class PartsRecordDocumentEquality implements Equality<PartsRecord> {
  const PartsRecordDocumentEquality();

  @override
  bool equals(PartsRecord? e1, PartsRecord? e2) {
    return e1?.partNumber == e2?.partNumber &&
        e1?.partTitle == e2?.partTitle &&
        e1?.partImage == e2?.partImage;
  }

  @override
  int hash(PartsRecord? e) =>
      const ListEquality().hash([e?.partNumber, e?.partTitle, e?.partImage]);

  @override
  bool isValidKey(Object? o) => o is PartsRecord;
}
