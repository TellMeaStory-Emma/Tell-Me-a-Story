import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class StoriesRecord extends FirestoreRecord {
  StoriesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "story_id" field.
  int? _storyId;
  int get storyId => _storyId ?? 0;
  bool hasStoryId() => _storyId != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  // "display_order" field.
  int? _displayOrder;
  int get displayOrder => _displayOrder ?? 0;
  bool hasDisplayOrder() => _displayOrder != null;

  // "is_locked" field.
  bool? _isLocked;
  bool get isLocked => _isLocked ?? false;
  bool hasIsLocked() => _isLocked != null;

  // "story_type" field.
  String? _storyType;
  String get storyType => _storyType ?? '';
  bool hasStoryType() => _storyType != null;

  // "introduction" field.
  String? _introduction;
  String get introduction => _introduction ?? '';
  bool hasIntroduction() => _introduction != null;

  // "cover_image" field.
  String? _coverImage;
  String get coverImage => _coverImage ?? '';
  bool hasCoverImage() => _coverImage != null;

  // "publish_date" field.
  DateTime? _publishDate;
  DateTime? get publishDate => _publishDate;
  bool hasPublishDate() => _publishDate != null;

  // "long_introduction" field.
  String? _longIntroduction;
  String get longIntroduction => _longIntroduction ?? '';
  bool hasLongIntroduction() => _longIntroduction != null;

  // "reward_order" field.
  int? _rewardOrder;
  int get rewardOrder => _rewardOrder ?? 0;
  bool hasRewardOrder() => _rewardOrder != null;

  // "is_reward_unlocked" field.
  bool? _isRewardUnlocked;
  bool get isRewardUnlocked => _isRewardUnlocked ?? false;
  bool hasIsRewardUnlocked() => _isRewardUnlocked != null;

  // "is_reward_story" field.
  bool? _isRewardStory;
  bool get isRewardStory => _isRewardStory ?? false;
  bool hasIsRewardStory() => _isRewardStory != null;

  // "is_published" field.
  bool? _isPublished;
  bool get isPublished => _isPublished ?? false;
  bool hasIsPublished() => _isPublished != null;

  void _initializeFields() {
    _storyId = castToType<int>(snapshotData['story_id']);
    _category = snapshotData['category'] as String?;
    _displayOrder = castToType<int>(snapshotData['display_order']);
    _isLocked = snapshotData['is_locked'] as bool?;
    _storyType = snapshotData['story_type'] as String?;
    _introduction = snapshotData['introduction'] as String?;
    _coverImage = snapshotData['cover_image'] as String?;
    _publishDate = snapshotData['publish_date'] as DateTime?;
    _longIntroduction = snapshotData['long_introduction'] as String?;
    _rewardOrder = castToType<int>(snapshotData['reward_order']);
    _isRewardUnlocked = snapshotData['is_reward_unlocked'] as bool?;
    _isRewardStory = snapshotData['is_reward_story'] as bool?;
    _isPublished = snapshotData['is_published'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('stories');

  static Stream<StoriesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => StoriesRecord.fromSnapshot(s));

  static Future<StoriesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => StoriesRecord.fromSnapshot(s));

  static StoriesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      StoriesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static StoriesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      StoriesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'StoriesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is StoriesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createStoriesRecordData({
  int? storyId,
  String? category,
  int? displayOrder,
  bool? isLocked,
  String? storyType,
  String? introduction,
  String? coverImage,
  DateTime? publishDate,
  String? longIntroduction,
  int? rewardOrder,
  bool? isRewardUnlocked,
  bool? isRewardStory,
  bool? isPublished,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'story_id': storyId,
      'category': category,
      'display_order': displayOrder,
      'is_locked': isLocked,
      'story_type': storyType,
      'introduction': introduction,
      'cover_image': coverImage,
      'publish_date': publishDate,
      'long_introduction': longIntroduction,
      'reward_order': rewardOrder,
      'is_reward_unlocked': isRewardUnlocked,
      'is_reward_story': isRewardStory,
      'is_published': isPublished,
    }.withoutNulls,
  );

  return firestoreData;
}

class StoriesRecordDocumentEquality implements Equality<StoriesRecord> {
  const StoriesRecordDocumentEquality();

  @override
  bool equals(StoriesRecord? e1, StoriesRecord? e2) {
    return e1?.storyId == e2?.storyId &&
        e1?.category == e2?.category &&
        e1?.displayOrder == e2?.displayOrder &&
        e1?.isLocked == e2?.isLocked &&
        e1?.storyType == e2?.storyType &&
        e1?.introduction == e2?.introduction &&
        e1?.coverImage == e2?.coverImage &&
        e1?.publishDate == e2?.publishDate &&
        e1?.longIntroduction == e2?.longIntroduction &&
        e1?.rewardOrder == e2?.rewardOrder &&
        e1?.isRewardUnlocked == e2?.isRewardUnlocked &&
        e1?.isRewardStory == e2?.isRewardStory &&
        e1?.isPublished == e2?.isPublished;
  }

  @override
  int hash(StoriesRecord? e) => const ListEquality().hash([
        e?.storyId,
        e?.category,
        e?.displayOrder,
        e?.isLocked,
        e?.storyType,
        e?.introduction,
        e?.coverImage,
        e?.publishDate,
        e?.longIntroduction,
        e?.rewardOrder,
        e?.isRewardUnlocked,
        e?.isRewardStory,
        e?.isPublished
      ]);

  @override
  bool isValidKey(Object? o) => o is StoriesRecord;
}
