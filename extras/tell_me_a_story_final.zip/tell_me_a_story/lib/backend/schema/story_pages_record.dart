import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class StoryPagesRecord extends FirestoreRecord {
  StoryPagesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "page_number" field.
  int? _pageNumber;
  int get pageNumber => _pageNumber ?? 0;
  bool hasPageNumber() => _pageNumber != null;

  // "page_text" field.
  String? _pageText;
  String get pageText => _pageText ?? '';
  bool hasPageText() => _pageText != null;

  // "audio_duration" field.
  int? _audioDuration;
  int get audioDuration => _audioDuration ?? 0;
  bool hasAudioDuration() => _audioDuration != null;

  // "page_audio" field.
  String? _pageAudio;
  String get pageAudio => _pageAudio ?? '';
  bool hasPageAudio() => _pageAudio != null;

  // "page_image" field.
  String? _pageImage;
  String get pageImage => _pageImage ?? '';
  bool hasPageImage() => _pageImage != null;

  // "page_video" field.
  String? _pageVideo;
  String get pageVideo => _pageVideo ?? '';
  bool hasPageVideo() => _pageVideo != null;

  // "age_category" field.
  String? _ageCategory;
  String get ageCategory => _ageCategory ?? '';
  bool hasAgeCategory() => _ageCategory != null;

  // "is_last_page" field.
  bool? _isLastPage;
  bool get isLastPage => _isLastPage ?? false;
  bool hasIsLastPage() => _isLastPage != null;

  // "part_number" field.
  int? _partNumber;
  int get partNumber => _partNumber ?? 0;
  bool hasPartNumber() => _partNumber != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _pageNumber = castToType<int>(snapshotData['page_number']);
    _pageText = snapshotData['page_text'] as String?;
    _audioDuration = castToType<int>(snapshotData['audio_duration']);
    _pageAudio = snapshotData['page_audio'] as String?;
    _pageImage = snapshotData['page_image'] as String?;
    _pageVideo = snapshotData['page_video'] as String?;
    _ageCategory = snapshotData['age_category'] as String?;
    _isLastPage = snapshotData['is_last_page'] as bool?;
    _partNumber = castToType<int>(snapshotData['part_number']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('story_pages')
          : FirebaseFirestore.instance.collectionGroup('story_pages');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('story_pages').doc(id);

  static Stream<StoryPagesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => StoryPagesRecord.fromSnapshot(s));

  static Future<StoryPagesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => StoryPagesRecord.fromSnapshot(s));

  static StoryPagesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      StoryPagesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static StoryPagesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      StoryPagesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'StoryPagesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is StoryPagesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createStoryPagesRecordData({
  int? pageNumber,
  String? pageText,
  int? audioDuration,
  String? pageAudio,
  String? pageImage,
  String? pageVideo,
  String? ageCategory,
  bool? isLastPage,
  int? partNumber,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'page_number': pageNumber,
      'page_text': pageText,
      'audio_duration': audioDuration,
      'page_audio': pageAudio,
      'page_image': pageImage,
      'page_video': pageVideo,
      'age_category': ageCategory,
      'is_last_page': isLastPage,
      'part_number': partNumber,
    }.withoutNulls,
  );

  return firestoreData;
}

class StoryPagesRecordDocumentEquality implements Equality<StoryPagesRecord> {
  const StoryPagesRecordDocumentEquality();

  @override
  bool equals(StoryPagesRecord? e1, StoryPagesRecord? e2) {
    return e1?.pageNumber == e2?.pageNumber &&
        e1?.pageText == e2?.pageText &&
        e1?.audioDuration == e2?.audioDuration &&
        e1?.pageAudio == e2?.pageAudio &&
        e1?.pageImage == e2?.pageImage &&
        e1?.pageVideo == e2?.pageVideo &&
        e1?.ageCategory == e2?.ageCategory &&
        e1?.isLastPage == e2?.isLastPage &&
        e1?.partNumber == e2?.partNumber;
  }

  @override
  int hash(StoryPagesRecord? e) => const ListEquality().hash([
        e?.pageNumber,
        e?.pageText,
        e?.audioDuration,
        e?.pageAudio,
        e?.pageImage,
        e?.pageVideo,
        e?.ageCategory,
        e?.isLastPage,
        e?.partNumber
      ]);

  @override
  bool isValidKey(Object? o) => o is StoryPagesRecord;
}
