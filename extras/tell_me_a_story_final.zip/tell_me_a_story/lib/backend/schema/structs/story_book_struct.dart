// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class StoryBookStruct extends FFFirebaseStruct {
  StoryBookStruct({
    String? ageCategory,
    bool? isLocked,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _ageCategory = ageCategory,
        _isLocked = isLocked,
        super(firestoreUtilData);

  // "ageCategory" field.
  String? _ageCategory;
  String get ageCategory => _ageCategory ?? '';
  set ageCategory(String? val) => _ageCategory = val;

  bool hasAgeCategory() => _ageCategory != null;

  // "isLocked" field.
  bool? _isLocked;
  bool get isLocked => _isLocked ?? false;
  set isLocked(bool? val) => _isLocked = val;

  bool hasIsLocked() => _isLocked != null;

  static StoryBookStruct fromMap(Map<String, dynamic> data) => StoryBookStruct(
        ageCategory: data['ageCategory'] as String?,
        isLocked: data['isLocked'] as bool?,
      );

  static StoryBookStruct? maybeFromMap(dynamic data) => data is Map
      ? StoryBookStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'ageCategory': _ageCategory,
        'isLocked': _isLocked,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'ageCategory': serializeParam(
          _ageCategory,
          ParamType.String,
        ),
        'isLocked': serializeParam(
          _isLocked,
          ParamType.bool,
        ),
      }.withoutNulls;

  static StoryBookStruct fromSerializableMap(Map<String, dynamic> data) =>
      StoryBookStruct(
        ageCategory: deserializeParam(
          data['ageCategory'],
          ParamType.String,
          false,
        ),
        isLocked: deserializeParam(
          data['isLocked'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'StoryBookStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is StoryBookStruct &&
        ageCategory == other.ageCategory &&
        isLocked == other.isLocked;
  }

  @override
  int get hashCode => const ListEquality().hash([ageCategory, isLocked]);
}

StoryBookStruct createStoryBookStruct({
  String? ageCategory,
  bool? isLocked,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    StoryBookStruct(
      ageCategory: ageCategory,
      isLocked: isLocked,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

StoryBookStruct? updateStoryBookStruct(
  StoryBookStruct? storyBook, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    storyBook
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addStoryBookStructData(
  Map<String, dynamic> firestoreData,
  StoryBookStruct? storyBook,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (storyBook == null) {
    return;
  }
  if (storyBook.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && storyBook.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final storyBookData = getStoryBookFirestoreData(storyBook, forFieldValue);
  final nestedData = storyBookData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = storyBook.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getStoryBookFirestoreData(
  StoryBookStruct? storyBook, [
  bool forFieldValue = false,
]) {
  if (storyBook == null) {
    return {};
  }
  final firestoreData = mapToFirestore(storyBook.toMap());

  // Add any Firestore field values
  mapToFirestore(storyBook.firestoreUtilData.fieldValues)
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getStoryBookListFirestoreData(
  List<StoryBookStruct>? storyBooks,
) =>
    storyBooks?.map((e) => getStoryBookFirestoreData(e, true)).toList() ?? [];
