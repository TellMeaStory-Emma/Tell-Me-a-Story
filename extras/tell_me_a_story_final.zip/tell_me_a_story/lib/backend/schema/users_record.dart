import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "weekly_points" field.
  int? _weeklyPoints;
  int get weeklyPoints => _weeklyPoints ?? 0;
  bool hasWeeklyPoints() => _weeklyPoints != null;

  // "last_login_date" field.
  DateTime? _lastLoginDate;
  DateTime? get lastLoginDate => _lastLoginDate;
  bool hasLastLoginDate() => _lastLoginDate != null;

  // "last_gift_date" field.
  DateTime? _lastGiftDate;
  DateTime? get lastGiftDate => _lastGiftDate;
  bool hasLastGiftDate() => _lastGiftDate != null;

  // "free_library_expiry" field.
  DateTime? _freeLibraryExpiry;
  DateTime? get freeLibraryExpiry => _freeLibraryExpiry;
  bool hasFreeLibraryExpiry() => _freeLibraryExpiry != null;

  // "next_reward_order" field.
  int? _nextRewardOrder;
  int get nextRewardOrder => _nextRewardOrder ?? 0;
  bool hasNextRewardOrder() => _nextRewardOrder != null;

  // "unlocked_stories" field.
  List<int>? _unlockedStories;
  List<int> get unlockedStories => _unlockedStories ?? const [];
  bool hasUnlockedStories() => _unlockedStories != null;

  // "daily_reads" field.
  List<DocumentReference>? _dailyReads;
  List<DocumentReference> get dailyReads => _dailyReads ?? const [];
  bool hasDailyReads() => _dailyReads != null;

  // "last_read_date" field.
  String? _lastReadDate;
  String get lastReadDate => _lastReadDate ?? '';
  bool hasLastReadDate() => _lastReadDate != null;

  // "daily_reads_count" field.
  int? _dailyReadsCount;
  int get dailyReadsCount => _dailyReadsCount ?? 0;
  bool hasDailyReadsCount() => _dailyReadsCount != null;

  // "today_opened_stories" field.
  List<DocumentReference>? _todayOpenedStories;
  List<DocumentReference> get todayOpenedStories =>
      _todayOpenedStories ?? const [];
  bool hasTodayOpenedStories() => _todayOpenedStories != null;

  // "today_opened_parts" field.
  List<String>? _todayOpenedParts;
  List<String> get todayOpenedParts => _todayOpenedParts ?? const [];
  bool hasTodayOpenedParts() => _todayOpenedParts != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _weeklyPoints = castToType<int>(snapshotData['weekly_points']);
    _lastLoginDate = snapshotData['last_login_date'] as DateTime?;
    _lastGiftDate = snapshotData['last_gift_date'] as DateTime?;
    _freeLibraryExpiry = snapshotData['free_library_expiry'] as DateTime?;
    _nextRewardOrder = castToType<int>(snapshotData['next_reward_order']);
    _unlockedStories = getDataList(snapshotData['unlocked_stories']);
    _dailyReads = getDataList(snapshotData['daily_reads']);
    _lastReadDate = snapshotData['last_read_date'] as String?;
    _dailyReadsCount = castToType<int>(snapshotData['daily_reads_count']);
    _todayOpenedStories = getDataList(snapshotData['today_opened_stories']);
    _todayOpenedParts = getDataList(snapshotData['today_opened_parts']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  int? weeklyPoints,
  DateTime? lastLoginDate,
  DateTime? lastGiftDate,
  DateTime? freeLibraryExpiry,
  int? nextRewardOrder,
  String? lastReadDate,
  int? dailyReadsCount,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'weekly_points': weeklyPoints,
      'last_login_date': lastLoginDate,
      'last_gift_date': lastGiftDate,
      'free_library_expiry': freeLibraryExpiry,
      'next_reward_order': nextRewardOrder,
      'last_read_date': lastReadDate,
      'daily_reads_count': dailyReadsCount,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.weeklyPoints == e2?.weeklyPoints &&
        e1?.lastLoginDate == e2?.lastLoginDate &&
        e1?.lastGiftDate == e2?.lastGiftDate &&
        e1?.freeLibraryExpiry == e2?.freeLibraryExpiry &&
        e1?.nextRewardOrder == e2?.nextRewardOrder &&
        listEquality.equals(e1?.unlockedStories, e2?.unlockedStories) &&
        listEquality.equals(e1?.dailyReads, e2?.dailyReads) &&
        e1?.lastReadDate == e2?.lastReadDate &&
        e1?.dailyReadsCount == e2?.dailyReadsCount &&
        listEquality.equals(e1?.todayOpenedStories, e2?.todayOpenedStories) &&
        listEquality.equals(e1?.todayOpenedParts, e2?.todayOpenedParts);
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.weeklyPoints,
        e?.lastLoginDate,
        e?.lastGiftDate,
        e?.freeLibraryExpiry,
        e?.nextRewardOrder,
        e?.unlockedStories,
        e?.dailyReads,
        e?.lastReadDate,
        e?.dailyReadsCount,
        e?.todayOpenedStories,
        e?.todayOpenedParts
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
