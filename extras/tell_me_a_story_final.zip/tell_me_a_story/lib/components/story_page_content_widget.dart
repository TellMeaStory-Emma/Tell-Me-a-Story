import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_timer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_video_player.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'package:stop_watch_timer/stop_watch_timer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'story_page_content_model.dart';
export 'story_page_content_model.dart';

class StoryPageContentWidget extends StatefulWidget {
  const StoryPageContentWidget({
    super.key,
    required this.pageAudio,
    required this.onTimerEnd,
    required this.onToggleMedia,
    this.isCurrentPage,
    bool? isPlaying,
  }) : this.isPlaying = isPlaying ?? true;

  final StoryPagesRecord? pageAudio;
  final Future Function()? onTimerEnd;
  final Future Function()? onToggleMedia;
  final bool? isCurrentPage;
  final bool isPlaying;

  @override
  State<StoryPageContentWidget> createState() => _StoryPageContentWidgetState();
}

class _StoryPageContentWidgetState extends State<StoryPageContentWidget> {
  late StoryPageContentModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => StoryPageContentModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await Future.delayed(
        Duration(
          milliseconds: 1500,
        ),
      );
      _model.timerController.onStartTimer();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Align(
                alignment: AlignmentDirectional(-1.0, -1.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 20.0, 0.0),
                  child: Text(
                    valueOrDefault<String>(
                      widget!.pageAudio?.ageCategory,
                      'العمر',
                    ),
                    textAlign: TextAlign.end,
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          font: GoogleFonts.inter(
                            fontWeight: FontWeight.w600,
                            fontStyle: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontStyle,
                          ),
                          fontSize: 18.0,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.w600,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
          child: Stack(
            children: [
              Builder(
                builder: (context) {
                  if (widget!.pageAudio?.isLastPage ?? false) {
                    return FlutterFlowVideoPlayer(
                      path: widget!.pageAudio!.pageVideo,
                      videoType: VideoType.network,
                      width: double.infinity,
                      height: 350.0,
                      autoPlay: true,
                      looping: true,
                      showControls: true,
                      allowFullScreen: false,
                      allowPlaybackSpeedMenu: false,
                    );
                  } else {
                    return ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: CachedNetworkImage(
                        fadeInDuration: Duration(milliseconds: 500),
                        fadeOutDuration: Duration(milliseconds: 500),
                        imageUrl: widget!.pageAudio!.pageImage,
                        width: MediaQuery.sizeOf(context).width * 1.0,
                        height: MediaQuery.sizeOf(context).height * 0.45,
                        fit: BoxFit.contain,
                      ),
                    );
                  }
                },
              ),
            ],
          ),
        ),
        Expanded(
          child: Opacity(
            opacity: 0.7,
            child: Align(
              alignment: AlignmentDirectional(0.0, 0.0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(5.0, 10.0, 5.0, 0.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFFFAF2F2),
                    boxShadow: [
                      BoxShadow(
                        blurRadius: 4.0,
                        color: Color(0x33000000),
                        offset: Offset(
                          0.0,
                          2.0,
                        ),
                      )
                    ],
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20.0),
                      topRight: Radius.circular(20.0),
                      bottomLeft: Radius.circular(20.0),
                      bottomRight: Radius.circular(20.0),
                    ),
                  ),
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: ListView(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    children: [
                      Align(
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Text(
                          valueOrDefault<String>(
                            widget!.pageAudio?.pageText,
                            'قصة اليوم',
                          ),
                          textAlign: TextAlign.center,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Tajawal ',
                                    fontSize: 18.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        Opacity(
          opacity: 0.0,
          child: FlutterFlowTimer(
            initialTime: widget!.pageAudio!.audioDuration,
            getDisplayTime: (value) => StopWatchTimer.getDisplayTime(
              value,
              hours: false,
              minute: false,
              milliSecond: false,
            ),
            controller: _model.timerController,
            onChanged: (value, displayTime, shouldUpdate) {
              _model.timerMilliseconds = value;
              _model.timerValue = displayTime;
              if (shouldUpdate) safeSetState(() {});
            },
            onEnded: () async {
              await widget.onTimerEnd?.call();
            },
            textAlign: TextAlign.start,
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  fontFamily: 'Tajawal ',
                  fontSize: 1.0,
                  letterSpacing: 0.0,
                ),
          ),
        ),
        Stack(
          alignment: AlignmentDirectional(-0.0, 0.0),
          children: [
            Opacity(
              opacity: 0.0,
              child: Container(
                width: 50.0,
                height: 50.0,
                child: custom_widgets.StoryVideoPlayer(
                  width: 50.0,
                  height: 50.0,
                  videoUrl: widget!.pageAudio!.pageVideo,
                  isPlaying: FFAppState().isStoryPlaying,
                  isCurrentPage: widget!.isCurrentPage!,
                  onVideoStarted: () async {},
                ),
              ),
            ),
            if (!widget!.pageAudio!.isLastPage)
              Align(
                alignment: AlignmentDirectional(0.0, 1.0),
                child: InkWell(
                  splashColor: Colors.transparent,
                  focusColor: Colors.transparent,
                  hoverColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  onTap: () async {
                    if (FFAppState().isStoryPlaying) {
                      _model.timerController.onStopTimer();
                      FFAppState().isStoryPlaying = false;
                      safeSetState(() {});
                    } else {
                      _model.timerController.onStartTimer();
                      FFAppState().isStoryPlaying = true;
                      safeSetState(() {});
                    }
                  },
                  child: Container(
                    width: 40.0,
                    height: 40.0,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 4.0,
                          color: FlutterFlowTheme.of(context).secondaryText,
                          offset: Offset(
                            0.0,
                            2.0,
                          ),
                        )
                      ],
                      gradient: LinearGradient(
                        colors: [
                          FlutterFlowTheme.of(context).tertiary,
                          Color(0xFFEEE443)
                        ],
                        stops: [0.0, 1.0],
                        begin: AlignmentDirectional(0.0, -1.0),
                        end: AlignmentDirectional(0, 1.0),
                      ),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: FlutterFlowTheme.of(context).warning,
                      ),
                    ),
                    alignment: AlignmentDirectional(0.0, 1.0),
                    child: Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: Builder(
                        builder: (context) {
                          if (FFAppState().isStoryPlaying) {
                            return Icon(
                              Icons.pause_rounded,
                              color: Color(0xFF695127),
                              size: 35.0,
                            );
                          } else {
                            return Icon(
                              Icons.play_arrow,
                              color: Color(0xFF695127),
                              size: 35.0,
                            );
                          }
                        },
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}
