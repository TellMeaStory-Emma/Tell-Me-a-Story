import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'story_timer_model.dart';
export 'story_timer_model.dart';

class StoryTimerWidget extends StatefulWidget {
  const StoryTimerWidget({super.key});

  @override
  State<StoryTimerWidget> createState() => _StoryTimerWidgetState();
}

class _StoryTimerWidgetState extends State<StoryTimerWidget> {
  late StoryTimerModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => StoryTimerModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Opacity(
      opacity: 0.8,
      child: Align(
        alignment: AlignmentDirectional(0.0, 1.0),
        child: Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
          child: Container(
            width: 100.0,
            height: 50.0,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  FlutterFlowTheme.of(context).tertiary,
                  Color(0xFFEEE443)
                ],
                stops: [0.0, 1.0],
                begin: AlignmentDirectional(0.0, -1.0),
                end: AlignmentDirectional(0, 1.0),
              ),
              borderRadius: BorderRadius.circular(10.0),
            ),
            alignment: AlignmentDirectional(0.0, 1.0),
            child: Align(
              alignment: AlignmentDirectional(0.0, 0.0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                child: Container(
                  width: 100.0,
                  height: 40.0,
                  child: custom_widgets.CountdownTimer(
                    width: 100.0,
                    height: 40.0,
                    durationMinutes: 60,
                    startTime: FFAppState().goldenHourStartTime!,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
