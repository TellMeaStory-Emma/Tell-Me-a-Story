import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'thanks_for_rating_model.dart';
export 'thanks_for_rating_model.dart';

class ThanksForRatingWidget extends StatefulWidget {
  const ThanksForRatingWidget({super.key});

  @override
  State<ThanksForRatingWidget> createState() => _ThanksForRatingWidgetState();
}

class _ThanksForRatingWidgetState extends State<ThanksForRatingWidget> {
  late ThanksForRatingModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ThanksForRatingModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Container(
        width: 350.0,
        height: 190.0,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          boxShadow: [
            BoxShadow(
              blurRadius: 4.0,
              color: Color(0x33000000),
              offset: Offset(
                0.0,
                2.0,
              ),
            )
          ],
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20.0),
            topRight: Radius.circular(20.0),
            bottomLeft: Radius.circular(20.0),
            bottomRight: Radius.circular(20.0),
          ),
          border: Border.all(
            color: FlutterFlowTheme.of(context).accent3,
            width: 3.0,
          ),
        ),
        child: Align(
          alignment: AlignmentDirectional(0.0, -1.0),
          child: Stack(
            children: [
              Align(
                alignment: AlignmentDirectional(-1.0, -1.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                  child: Icon(
                    FFIcons.kkstarsFilled,
                    color: Color(0xFF9F5739),
                    size: 40.0,
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, -0.51),
                child: Text(
                  'نُجُومٌ رَائِعَةٌ يَا صَدِيقِي!\n\nوَكَعُرْبُونِ شُكْرٍ، فَتَحْنَا لَكَ قِصَّةَ «التِّمْسَاحِ الْأَنَانِيِّ» فِي الْمَكْتَبَةِ.\n قِرَاءَةً مُمْتِعَةً!\n',
                  textAlign: TextAlign.center,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Tajawal ',
                        fontSize: 18.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 1.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
                  child: FFButtonWidget(
                    onPressed: () async {
                      Navigator.pop(context);

                      await currentUserReference!.update({
                        ...mapToFirestore(
                          {
                            'unlocked_stories': FieldValue.arrayUnion([21]),
                          },
                        ),
                      });

                      context.pushNamed(
                        FreeLibraryDynamicWidget.routeName,
                        extra: <String, dynamic>{
                          '__transition_info__': TransitionInfo(
                            hasTransition: true,
                            transitionType: PageTransitionType.fade,
                          ),
                        },
                      );
                    },
                    text: 'اِنْطَلِقْ إِلَى الْمَكْتَبَةِ!',
                    options: FFButtonOptions(
                      height: 40.0,
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                      iconPadding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      color: Color(0xFFF6C7B7),
                      textStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Tajawal ',
                                color: FlutterFlowTheme.of(context).primaryText,
                                fontSize: 18.0,
                                letterSpacing: 0.0,
                              ),
                      elevation: 0.0,
                      borderSide: BorderSide(
                        color: FlutterFlowTheme.of(context).accent3,
                        width: 3.0,
                      ),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(1.0, -1.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                  child: Icon(
                    FFIcons.kkstarsFilled,
                    color: Color(0xFF9F5739),
                    size: 40.0,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
