import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'weekly_points_counter_widget.dart' show WeeklyPointsCounterWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class WeeklyPointsCounterModel
    extends FlutterFlowModel<WeeklyPointsCounterWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
