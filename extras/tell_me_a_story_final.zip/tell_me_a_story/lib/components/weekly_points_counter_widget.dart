import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'weekly_points_counter_model.dart';
export 'weekly_points_counter_model.dart';

class WeeklyPointsCounterWidget extends StatefulWidget {
  const WeeklyPointsCounterWidget({super.key});

  @override
  State<WeeklyPointsCounterWidget> createState() =>
      _WeeklyPointsCounterWidgetState();
}

class _WeeklyPointsCounterWidgetState extends State<WeeklyPointsCounterWidget> {
  late WeeklyPointsCounterModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => WeeklyPointsCounterModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: 0.8,
      child: Align(
        alignment: AlignmentDirectional(0.0, 1.0),
        child: Container(
          width: 80.0,
          height: 40.0,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                FlutterFlowTheme.of(context).tertiary,
                Color(0xFFEEE443)
              ],
              stops: [0.0, 1.0],
              begin: AlignmentDirectional(0.0, -1.0),
              end: AlignmentDirectional(0, 1.0),
            ),
            borderRadius: BorderRadius.circular(10.0),
          ),
          alignment: AlignmentDirectional(0.0, 1.0),
          child: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: AuthUserStreamWidget(
              builder: (context) => Text(
                valueOrDefault<String>(
                  valueOrDefault(currentUserDocument?.weeklyPoints, 0)
                      .toString(),
                  '0',
                ),
                textAlign: TextAlign.center,
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Tajawal ',
                      fontSize: 18.0,
                      letterSpacing: 0.0,
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
