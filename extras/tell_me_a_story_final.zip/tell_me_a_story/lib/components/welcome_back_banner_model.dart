import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'welcome_back_banner_widget.dart' show WelcomeBackBannerWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class WelcomeBackBannerModel extends FlutterFlowModel<WelcomeBackBannerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
