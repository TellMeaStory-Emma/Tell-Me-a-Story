import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'welcome_back_widget.dart' show WelcomeBackWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class WelcomeBackModel extends FlutterFlowModel<WelcomeBackWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
