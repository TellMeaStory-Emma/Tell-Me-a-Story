import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'welcome_message_widget.dart' show WelcomeMessageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class WelcomeMessageModel extends FlutterFlowModel<WelcomeMessageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
