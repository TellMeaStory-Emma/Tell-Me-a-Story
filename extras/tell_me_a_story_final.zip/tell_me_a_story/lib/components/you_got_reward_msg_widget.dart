import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'you_got_reward_msg_model.dart';
export 'you_got_reward_msg_model.dart';

class YouGotRewardMsgWidget extends StatefulWidget {
  const YouGotRewardMsgWidget({
    super.key,
    required this.passedStory,
  });

  final StoriesRecord? passedStory;

  @override
  State<YouGotRewardMsgWidget> createState() => _YouGotRewardMsgWidgetState();
}

class _YouGotRewardMsgWidgetState extends State<YouGotRewardMsgWidget> {
  late YouGotRewardMsgModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => YouGotRewardMsgModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Container(
        width: 350.0,
        height: 170.0,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          boxShadow: [
            BoxShadow(
              blurRadius: 4.0,
              color: Color(0x33000000),
              offset: Offset(
                0.0,
                2.0,
              ),
            )
          ],
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20.0),
            topRight: Radius.circular(20.0),
            bottomLeft: Radius.circular(20.0),
            bottomRight: Radius.circular(20.0),
          ),
          border: Border.all(
            width: 2.0,
          ),
        ),
        child: Align(
          alignment: AlignmentDirectional(0.0, -1.0),
          child: Stack(
            children: [
              Align(
                alignment: AlignmentDirectional(0.0, -1.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                  child: Text(
                    'عَمَلٌ رَائِعٌ يَا صَدِيقِي!\n لَقَدْ حَصَلْتَ عَلَى قِصَّةٍ جَدِيدَةٍ.\n يُمْكِنُكَ أَنْ تَجِدَهَا دَائِمًا فِي الْمَكْتَبَةِ الْمَجَّانِيَّةِ.',
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Tajawal ',
                          fontSize: 18.0,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 1.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                  child: FFButtonWidget(
                    onPressed: () async {
                      _model.nextStory = await queryStoriesRecordOnce(
                        queryBuilder: (storiesRecord) => storiesRecord.where(
                          'reward_order',
                          isEqualTo: valueOrDefault<int>(
                            valueOrDefault(
                                currentUserDocument?.nextRewardOrder, 0),
                            1,
                          ),
                        ),
                        singleRecord: true,
                      ).then((s) => s.firstOrNull);
                      if (_model.nextStory?.reference != null) {
                        await currentUserReference!.update({
                          ...createUsersRecordData(
                            weeklyPoints: 0,
                          ),
                          ...mapToFirestore(
                            {
                              'unlocked_stories': FieldValue.arrayUnion(
                                  [_model.nextStory?.storyId]),
                              'next_reward_order': FieldValue.increment(1),
                            },
                          ),
                        });

                        context.pushNamed(
                          TestStoryPageWidget.routeName,
                          queryParameters: {
                            'currentStory': serializeParam(
                              _model.nextStory,
                              ParamType.Document,
                            ),
                          }.withoutNulls,
                          extra: <String, dynamic>{
                            'currentStory': _model.nextStory,
                            '__transition_info__': TransitionInfo(
                              hasTransition: true,
                              transitionType: PageTransitionType.fade,
                            ),
                          },
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'عفواً، لا توجد قصص جوائز متاحة حالياً',
                              style: TextStyle(
                                color: FlutterFlowTheme.of(context).primaryText,
                              ),
                            ),
                            duration: Duration(milliseconds: 4000),
                            backgroundColor:
                                FlutterFlowTheme.of(context).secondary,
                          ),
                        );
                      }

                      safeSetState(() {});
                    },
                    text: 'اقـــْرَأْهَا الآنَ!',
                    options: FFButtonOptions(
                      height: 40.0,
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                      iconPadding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      color: Color(0xFFF6C7B7),
                      textStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Tajawal ',
                                color: FlutterFlowTheme.of(context).primaryText,
                                fontSize: 18.0,
                                letterSpacing: 0.0,
                              ),
                      elevation: 0.0,
                      borderSide: BorderSide(
                        color: FlutterFlowTheme.of(context).accent3,
                        width: 3.0,
                      ),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
