// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:async';
import 'package:google_mobile_ads/google_mobile_ads.dart';

Future<bool> showRewardedAd(String adUnitId) async {
  final completer = Completer<bool>();
  bool userEarnedReward = false;

  RewardedAd.load(
    adUnitId: adUnitId,
    request: const AdRequest(),
    rewardedAdLoadCallback: RewardedAdLoadCallback(
      onAdLoaded: (RewardedAd ad) {
        ad.fullScreenContentCallback = FullScreenContentCallback(
          onAdDismissedFullScreenContent: (ad) {
            ad.dispose();
            if (!completer.isCompleted) {
              completer.complete(userEarnedReward);
            }
          },
          onAdFailedToShowFullScreenContent: (ad, error) {
            ad.dispose();
            if (!completer.isCompleted) completer.complete(false);
          },
        );

        ad.show(
          onUserEarnedReward: (AdWithoutView ad, RewardItem reward) {
            userEarnedReward = true;
          },
        );
      },
      onAdFailedToLoad: (LoadAdError error) {
        if (!completer.isCompleted) completer.complete(false);
      },
    ),
  );

  return completer.future.timeout(
    const Duration(seconds: 30),
    onTimeout: () => false,
  );
}
// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the `</>` button on the right!
