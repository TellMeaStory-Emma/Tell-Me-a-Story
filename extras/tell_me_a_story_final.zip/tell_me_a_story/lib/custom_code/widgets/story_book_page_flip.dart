// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Automatic imports for FlutterFlow Custom Widgets

// Import Page Flip Package
import 'package:page_flip/page_flip.dart';

class StoryBookPageFlip extends StatefulWidget {
  const StoryBookPageFlip({
    Key? key,
    this.width,
    this.height,
    this.imageUrls,
    this.videoUrls,
    this.audioUrls,
    this.onPageChanged,
  }) : super(key: key);

  final double? width;
  final double? height;
  final List<String>? imageUrls;
  final List<String>? videoUrls;
  final List<String>? audioUrls;
  final Future Function()? onPageChanged;

  @override
  _StoryBookPageFlipState createState() => _StoryBookPageFlipState();
}

class _StoryBookPageFlipState extends State<StoryBookPageFlip> {
  final _controller = GlobalKey<PageFlipWidgetState>();

  @override
  Widget build(BuildContext context) {
    final images = widget.imageUrls ?? [];

    if (images.isEmpty) {
      return Container(
        width: widget.width,
        height: widget.height,
        color: Colors.grey[200],
        child: const Center(child: CircularProgressIndicator()),
      );
    }

    return Container(
      width: widget.width ?? double.infinity,
      height: widget.height ?? double.infinity,
      child: PageFlipWidget(
        key: _controller,
        cutoffForward: 0.7,
        cutoffPrevious: 0.1,
        backgroundColor: Colors.transparent,
        children: List.generate(images.length, (index) {
          final url = images[index];
          return Container(
            width: double.infinity,
            height: double.infinity,
            child: Image.network(
              url,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(
                color: Colors.grey[300],
                child: const Icon(Icons.broken_image, size: 50),
              ),
            ),
          );
        }),
      ),
    );
  }
}

// Set your widget name, define your parameter, and then add the
// boilerplate code using the `</>` button on the right!
