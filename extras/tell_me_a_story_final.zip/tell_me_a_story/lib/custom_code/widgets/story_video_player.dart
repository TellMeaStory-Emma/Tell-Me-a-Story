// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class StoryVideoPlayer extends StatefulWidget {
  const StoryVideoPlayer({
    Key? key,
    this.width,
    this.height,
    required this.videoUrl,
    required this.isPlaying,
    required this.isCurrentPage,
    this.onVideoStarted,
  }) : super(key: key);

  final double? width;
  final double? height;
  final String videoUrl;
  final bool isPlaying;
  final bool isCurrentPage;
  final Future Function()? onVideoStarted;

  @override
  _StoryVideoPlayerState createState() => _StoryVideoPlayerState();
}

class _StoryVideoPlayerState extends State<StoryVideoPlayer>
    with WidgetsBindingObserver {
  VideoPlayerController? _videoPlayerController;
  ChewieController? _chewieController;
  bool _isInitialized = false;
  bool _hasTriggered = false;

  @override
  void initState() {
    super.initState();
    // 1️⃣ مراقبة حالة التطبيق (تصغير/إغلاق/قفل الشاشة)
    WidgetsBinding.instance.addObserver(this);
    _initPlayer();
  }

  // 2️⃣ إيقاف الصوت فوراً إذا خرج التطبيق إلى الخلفية أو قُفلت الشاشة
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _videoPlayerController?.setVolume(0.0);
      _chewieController?.pause();
      _videoPlayerController?.pause();
    }
  }

  Future<void> _initPlayer() async {
    if (widget.videoUrl.isEmpty) return;

    _stopAndClean();

    final videoController =
        VideoPlayerController.networkUrl(Uri.parse(widget.videoUrl));
    _videoPlayerController = videoController;

    try {
      await videoController.initialize();

      if (!mounted) {
        _stopAndClean();
        return;
      }

      _chewieController = ChewieController(
        videoPlayerController: videoController,
        autoPlay: false,
        looping: false,
        showControls: false,
        allowFullScreen: false,
        allowPlaybackSpeedChanging: false,
      );

      videoController.addListener(_videoListener);

      if (mounted) {
        setState(() => _isInitialized = true);
        _syncPlayState();
      }
    } catch (e) {
      debugPrint('Error initializing Chewie player: $e');
      _stopAndClean();
    }
  }

  void _syncPlayState() {
    if (_videoPlayerController == null ||
        !_isInitialized ||
        _chewieController == null) return;

    final isRouteCurrent = ModalRoute.of(context)?.isCurrent ?? true;
    bool isEnded = _videoPlayerController!.value.position >=
        _videoPlayerController!.value.duration;

    if (widget.isCurrentPage &&
        widget.isPlaying &&
        isRouteCurrent &&
        !isEnded) {
      _videoPlayerController!.setVolume(1.0);
      _chewieController!.play();
    } else {
      _videoPlayerController!.setVolume(0.0);
      _chewieController!.pause();
    }
  }

  void _videoListener() {
    if (!mounted || _videoPlayerController == null) return;

    if (_videoPlayerController!.value.isInitialized &&
        _videoPlayerController!.value.position >=
            _videoPlayerController!.value.duration) {
      _chewieController?.pause();
    }

    if (_videoPlayerController!.value.isInitialized &&
        _videoPlayerController!.value.isPlaying &&
        !_hasTriggered) {
      _hasTriggered = true;
      widget.onVideoStarted?.call();
    }
  }

  void _stopAndClean() {
    try {
      _videoPlayerController?.setVolume(0.0);
      _chewieController?.pause();
      _videoPlayerController?.pause();
    } catch (_) {}

    if (_videoPlayerController != null) {
      _videoPlayerController!.removeListener(_videoListener);
    }

    _chewieController?.dispose();
    _chewieController = null;

    _videoPlayerController?.dispose();
    _videoPlayerController = null;
  }

  @override
  void didUpdateWidget(StoryVideoPlayer oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.videoUrl != widget.videoUrl) {
      _hasTriggered = false;
      _isInitialized = false;
      _initPlayer();
      return;
    }

    if (_isInitialized) {
      _syncPlayState();
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_isInitialized) {
      _syncPlayState();
    }
  }

  // 3️⃣ كتم وخنق المشغّل الأصلي فوراً لحظة بدء الخروج وقبل تدمير الشاشة
  @override
  void deactivate() {
    try {
      _videoPlayerController?.setVolume(0.0);
      _chewieController?.pause();
      _videoPlayerController?.pause();
    } catch (_) {}
    super.deactivate();
  }

  @override
  void dispose() {
    // إلغاء مراقبة التطبيق
    WidgetsBinding.instance.removeObserver(this);
    _stopAndClean();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isRouteCurrent = ModalRoute.of(context)?.isCurrent ?? true;
    if (!isRouteCurrent && _isInitialized) {
      _videoPlayerController?.setVolume(0.0);
      _chewieController?.pause();
    }

    if (!_isInitialized || _chewieController == null) {
      return SizedBox(
        width: widget.width,
        height: widget.height,
        child: const Center(child: CircularProgressIndicator()),
      );
    }
    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: Chewie(controller: _chewieController!),
    );
  }
}
// Set your widget name, define your parameter, and then add the
// boilerplate code using the `</>` button on the right!
