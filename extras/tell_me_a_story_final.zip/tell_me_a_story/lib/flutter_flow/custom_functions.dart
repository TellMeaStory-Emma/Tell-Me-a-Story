import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

bool? isGoldenHourActive(DateTime? startTime) {
  if (startTime == null) {
    return false;
  }
  final now = DateTime.now();
  // حساب الفارق بين الوقت الحالي ووقت البداية بالثواني بطريقة آمنة
  final differenceInSeconds = now.difference(startTime).inSeconds;

  // إرجاع true إذا كان الفارق أقل من ساعة (3600 ثانية)
  return differenceInSeconds < 3600;
}

bool isGiftClaimedToday(DateTime? lastGiftDate) {
// 1. إذا كان التاريخ فارغاً (مستخدم جديد)، فهذا يعني أنه لم يستلم الهدية اليوم
  if (lastGiftDate == null) {
    return false;
  }

  // 2. الحصول على تاريخ الوقت الحالي لجهاز المستخدم (التوقيت المحلي)
  final now = DateTime.now();

  // 3. تحويل تاريخ الفايربيس بدقة إلى التوقيت المحلي لجهاز المستخدم لحل مشكلة فرق التوقيت (Timezones)
  final localLastGiftDate = lastGiftDate.toLocal();

  // 4. مقارنة السنة والشهر واليوم بين التاريخ المخزن بالوقت المحلي وتاريخ اليوم الحالي
  return localLastGiftDate.year == now.year &&
      localLastGiftDate.month == now.month &&
      localLastGiftDate.day == now.day;
}

List<StoriesRecord>? mergeAndSortStories(
  List<StoriesRecord>? list1,
  List<StoriesRecord>? list2,
) {
  List<StoriesRecord> mergeAndSortStories(
    List<StoriesRecord>? list1,
    List<StoriesRecord>? list2,
  ) {
    // 1. التعامل مع القوائم الفارغة لمنع الأخطاء
    final l1 = list1 ?? [];
    final l2 = list2 ?? [];

    // 2. دمج القائمتين معاً
    final combinedList = [...l1, ...l2];

    // 3. إزالة التكرار بناءً على Reference ID الخاص بكل قصة
    final Map<String, StoriesRecord> uniqueStoriesMap = {};
    for (var story in combinedList) {
      uniqueStoriesMap[story.reference.id] = story;
    }

    final uniqueList = uniqueStoriesMap.values.toList();

    // 4. الترتيب تنازلياً حسب publishDate (الأحدث أولاً)
    uniqueList.sort((a, b) {
      final dateA = a.publishDate ?? DateTime.fromMillisecondsSinceEpoch(0);
      final dateB = b.publishDate ?? DateTime.fromMillisecondsSinceEpoch(0);
      return dateB.compareTo(dateA);
    });

    return uniqueList;
  }
}

bool? shouldShowRating(
  DateTime? lastDate,
  bool? isRated,
) {
  bool shouldShowRating(DateTime? lastDate, bool? isRated) {
    // إذا كان قد تقييم بالفعل، لا تظهر النافذة
    if (isRated == true) return false;

    // إذا لم يضغط "لاحقاً" من قبل إطلاقاً، تظهر النافذة
    if (lastDate == null) return true;

    // نفحص هل مرت 24 ساعة أو أكثر على آخر ضغطة "لاحقاً"
    return DateTime.now().difference(lastDate).inHours >= 24;
  }
}

List<StoriesRecord>? combineStoryLists(
  List<StoriesRecord>? list1,
  List<StoriesRecord>? list2,
) {
  final List<StoriesRecord> combined = [];
  final Set<String> seenIds = {};

  void addStories(List<StoriesRecord>? list) {
    if (list != null) {
      for (var story in list) {
        final id = story.reference.id;
        if (!seenIds.contains(id)) {
          seenIds.add(id);
          combined.add(story);
        }
      }
    }
  }

  addStories(list1);
  addStories(list2);

  return combined;
}
