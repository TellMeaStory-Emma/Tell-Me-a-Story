import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';

import '/auth/base_auth_user_provider.dart';

import '/main.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'serialization_util.dart';

import '/index.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  BaseAuthUser? initialUser;
  BaseAuthUser? user;
  bool showSplashImage = true;
  String? _redirectLocation;

  /// Determines whether the app will refresh and build again when a sign
  /// in or sign out happens. This is useful when the app is launched or
  /// on an unexpected logout. However, this must be turned off when we
  /// intend to sign in/out and then navigate or perform any actions after.
  /// Otherwise, this will trigger a refresh and interrupt the action(s).
  bool notifyOnAuthChange = true;

  bool get loading => user == null || showSplashImage;
  bool get loggedIn => user?.loggedIn ?? false;
  bool get initiallyLoggedIn => initialUser?.loggedIn ?? false;
  bool get shouldRedirect => loggedIn && _redirectLocation != null;

  String getRedirectLocation() => _redirectLocation!;
  bool hasRedirect() => _redirectLocation != null;
  void setRedirectLocationIfUnset(String loc) => _redirectLocation ??= loc;
  void clearRedirectLocation() => _redirectLocation = null;

  /// Mark as not needing to notify on a sign in / out when we intend
  /// to perform subsequent actions (such as navigation) afterwards.
  void updateNotifyOnAuthChange(bool notify) => notifyOnAuthChange = notify;

  void update(BaseAuthUser newUser) {
    final shouldUpdate =
        user?.uid == null || newUser.uid == null || user?.uid != newUser.uid;
    initialUser ??= newUser;
    user = newUser;
    // Refresh the app on auth change unless explicitly marked otherwise.
    // No need to update unless the user has changed.
    if (notifyOnAuthChange && shouldUpdate) {
      notifyListeners();
    }
    // Once again mark the notifier as needing to update on auth change
    // (in order to catch sign in / out events).
    updateNotifyOnAuthChange(true);
  }

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      navigatorKey: appNavigatorKey,
      errorBuilder: (context, state) => appStateNotifier.loggedIn
          ? InterfaceDynamicWidget()
          : LoginPageWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) => appStateNotifier.loggedIn
              ? InterfaceDynamicWidget()
              : LoginPageWidget(),
        ),
        FFRoute(
          name: HomePageWidget.routeName,
          path: HomePageWidget.routePath,
          builder: (context, params) => HomePageWidget(),
        ),
        FFRoute(
          name: InterfaceWidget.routeName,
          path: InterfaceWidget.routePath,
          builder: (context, params) => InterfaceWidget(),
        ),
        FFRoute(
          name: FreeLibraryWidget.routeName,
          path: FreeLibraryWidget.routePath,
          builder: (context, params) => FreeLibraryWidget(),
        ),
        FFRoute(
          name: Story2BahiChickWidget.routeName,
          path: Story2BahiChickWidget.routePath,
          builder: (context, params) => Story2BahiChickWidget(),
        ),
        FFRoute(
          name: Story1JoodTheDuckWidget.routeName,
          path: Story1JoodTheDuckWidget.routePath,
          builder: (context, params) => Story1JoodTheDuckWidget(),
        ),
        FFRoute(
          name: Story3LostTurtleWidget.routeName,
          path: Story3LostTurtleWidget.routePath,
          builder: (context, params) => Story3LostTurtleWidget(),
        ),
        FFRoute(
          name: Story4LittleChicksWidget.routeName,
          path: Story4LittleChicksWidget.routePath,
          builder: (context, params) => Story4LittleChicksWidget(),
        ),
        FFRoute(
          name: Story5FaridaWidget.routeName,
          path: Story5FaridaWidget.routePath,
          builder: (context, params) => Story5FaridaWidget(),
        ),
        FFRoute(
          name: Story6DoriWidget.routeName,
          path: Story6DoriWidget.routePath,
          builder: (context, params) => Story6DoriWidget(),
        ),
        FFRoute(
          name: Story7BlueBirdWidget.routeName,
          path: Story7BlueBirdWidget.routePath,
          builder: (context, params) => Story7BlueBirdWidget(),
        ),
        FFRoute(
          name: Story8ComeBackCatWidget.routeName,
          path: Story8ComeBackCatWidget.routePath,
          builder: (context, params) => Story8ComeBackCatWidget(),
        ),
        FFRoute(
          name: Story9BabyWidget.routeName,
          path: Story9BabyWidget.routePath,
          builder: (context, params) => Story9BabyWidget(),
        ),
        FFRoute(
          name: Story10BaraaWidget.routeName,
          path: Story10BaraaWidget.routePath,
          builder: (context, params) => Story10BaraaWidget(),
        ),
        FFRoute(
          name: Story11Part1Widget.routeName,
          path: Story11Part1Widget.routePath,
          builder: (context, params) => Story11Part1Widget(),
        ),
        FFRoute(
          name: Story11Part2Widget.routeName,
          path: Story11Part2Widget.routePath,
          builder: (context, params) => Story11Part2Widget(),
        ),
        FFRoute(
          name: Story11Part3Widget.routeName,
          path: Story11Part3Widget.routePath,
          builder: (context, params) => Story11Part3Widget(),
        ),
        FFRoute(
          name: Story11Part4Widget.routeName,
          path: Story11Part4Widget.routePath,
          builder: (context, params) => Story11Part4Widget(),
        ),
        FFRoute(
          name: Story11Part5Widget.routeName,
          path: Story11Part5Widget.routePath,
          builder: (context, params) => Story11Part5Widget(),
        ),
        FFRoute(
          name: Story12Part1Widget.routeName,
          path: Story12Part1Widget.routePath,
          builder: (context, params) => Story12Part1Widget(),
        ),
        FFRoute(
          name: Story12InterfaceWidget.routeName,
          path: Story12InterfaceWidget.routePath,
          builder: (context, params) => Story12InterfaceWidget(),
        ),
        FFRoute(
          name: Story12Part2Widget.routeName,
          path: Story12Part2Widget.routePath,
          builder: (context, params) => Story12Part2Widget(),
        ),
        FFRoute(
          name: Story12Part3Widget.routeName,
          path: Story12Part3Widget.routePath,
          builder: (context, params) => Story12Part3Widget(),
        ),
        FFRoute(
          name: PremiumUsersWidget.routeName,
          path: PremiumUsersWidget.routePath,
          builder: (context, params) => PremiumUsersWidget(),
        ),
        FFRoute(
          name: Story11InterfaceWidget.routeName,
          path: Story11InterfaceWidget.routePath,
          builder: (context, params) => Story11InterfaceWidget(),
        ),
        FFRoute(
          name: TestStoryPageWidget.routeName,
          path: TestStoryPageWidget.routePath,
          asyncParams: {
            'currentStory': getDoc(['stories'], StoriesRecord.fromSnapshot),
          },
          builder: (context, params) => TestStoryPageWidget(
            currentStory: params.getParam(
              'currentStory',
              ParamType.Document,
            ),
            selectedPartNumber: params.getParam(
              'selectedPartNumber',
              ParamType.int,
            ),
          ),
        ),
        FFRoute(
          name: FreeLibraryDynamicWidget.routeName,
          path: FreeLibraryDynamicWidget.routePath,
          builder: (context, params) => FreeLibraryDynamicWidget(),
        ),
        FFRoute(
          name: InterfaceDynamicWidget.routeName,
          path: InterfaceDynamicWidget.routePath,
          builder: (context, params) => InterfaceDynamicWidget(),
        ),
        FFRoute(
          name: RewardPageWidget.routeName,
          path: RewardPageWidget.routePath,
          builder: (context, params) => RewardPageWidget(),
        ),
        FFRoute(
          name: LongStoryPageWidget.routeName,
          path: LongStoryPageWidget.routePath,
          asyncParams: {
            'currentStory': getDoc(['stories'], StoriesRecord.fromSnapshot),
          },
          builder: (context, params) => LongStoryPageWidget(
            currentStory: params.getParam(
              'currentStory',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: LoginPageWidget.routeName,
          path: LoginPageWidget.routePath,
          builder: (context, params) => LoginPageWidget(),
        ),
        FFRoute(
          name: WaitUsPageWidget.routeName,
          path: WaitUsPageWidget.routePath,
          builder: (context, params) => WaitUsPageWidget(),
        ),
        FFRoute(
          name: VideoTrialWidget.routeName,
          path: VideoTrialWidget.routePath,
          builder: (context, params) => VideoTrialWidget(),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
      observers: ffNavigatorObservers,
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void goNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : goNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void pushNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : pushNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension GoRouterExtensions on GoRouter {
  AppStateNotifier get appState => AppStateNotifier.instance;
  void prepareAuthEvent([bool ignoreRedirect = false]) =>
      appState.hasRedirect() && !ignoreRedirect
          ? null
          : appState.updateNotifyOnAuthChange(false);
  bool shouldRedirect(bool ignoreRedirect) =>
      !ignoreRedirect && appState.hasRedirect();
  void clearRedirectLocation() => appState.clearRedirectLocation();
  void setRedirectLocationIfUnset(String location) =>
      appState.updateNotifyOnAuthChange(false);
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
    List<String>? collectionNamePath,
    StructBuilder<T>? structBuilder,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
      collectionNamePath: collectionNamePath,
      structBuilder: structBuilder,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        redirect: (context, state) {
          if (appStateNotifier.shouldRedirect) {
            final redirectLocation = appStateNotifier.getRedirectLocation();
            appStateNotifier.clearRedirectLocation();
            return redirectLocation;
          }

          if (requireAuth && !appStateNotifier.loggedIn) {
            appStateNotifier.setRedirectLocationIfUnset(state.uri.toString());
            return '/loginPage';
          }
          return null;
        },
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = appStateNotifier.loading
              ? Container(
                  color: Colors.transparent,
                  child: Center(
                    child: Image.asset(
                      'assets/images/splash.png',
                      width: 1080.0,
                      height: 1920.0,
                      fit: BoxFit.cover,
                    ),
                  ),
                )
              : page;

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  name: state.name,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(
                  key: state.pageKey, name: state.name, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
