import '/components/daily_limit_sheet_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:octo_image/octo_image.dart';
import 'package:provider/provider.dart';
import 'story11_interface_model.dart';
export 'story11_interface_model.dart';

class Story11InterfaceWidget extends StatefulWidget {
  const Story11InterfaceWidget({super.key});

  static String routeName = 'Story11_interface';
  static String routePath = '/story11Interface';

  @override
  State<Story11InterfaceWidget> createState() => _Story11InterfaceWidgetState();
}

class _Story11InterfaceWidgetState extends State<Story11InterfaceWidget>
    with TickerProviderStateMixin {
  late Story11InterfaceModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Story11InterfaceModel());

    animationsMap.addAll({
      'iconOnActionTriggerAnimation1': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          RotateEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'iconOnActionTriggerAnimation2': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          RotateEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Container(
            width: MediaQuery.sizeOf(context).width * 1.0,
            height: MediaQuery.sizeOf(context).height * 1.0,
            child: Stack(
              children: [
                Opacity(
                  opacity: 0.6,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8.0),
                    child: Image.asset(
                      'assets/images/Whisk_febbf1c5531ad928b9b4f51b9e852649dr.png',
                      width: MediaQuery.sizeOf(context).width * 1.0,
                      height: MediaQuery.sizeOf(context).height * 1.0,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 0.0),
                      child: Text(
                        'محبو القصص ( +10 سنوات)',
                        textAlign: TextAlign.center,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Tajawal ',
                              color: Color(0xFF0E161C),
                              fontSize: 18.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    ),
                    Flexible(
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8.0),
                          child: CachedNetworkImage(
                            fadeInDuration: Duration(milliseconds: 0),
                            fadeOutDuration: Duration(milliseconds: 0),
                            imageUrl:
                                'https://raw.githubusercontent.com/TellMeaStory-Emma/Tell-Me-a-Story/main/Story11part_1img/01.webp',
                            width: MediaQuery.sizeOf(context).width * 0.598,
                            height: MediaQuery.sizeOf(context).height * 0.3,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 5.0),
                      child: Text(
                        'سَيِّدِي.. لِمَاذَا ظِلُّكَ لَهُ شَكْلُ ثَعْلَبٍ؟! \n\nعِنْدَمَا غَرُبَتِ الشَّمْسُ، لَوَّحَ الرَّجُلُ مِنْ الْبِقالَةِ مُوَدِّعًا سَلْمَى بِابْتِسَامَةٍ وَاسِعَةٍ، وَهُنَا، لَاحَظَتْ سَلْمَى شَيْئًا غَرِيبًا.. \nلِهَذَا الرَّجُلِ ظِلٌّ طَوِيلٌ عَلَى الْأَرْضِ؛ ظَلُّ ثَعْلَبٍ لَهُ سَبْعَةُ ذُيُولٍ!!\n قِصَّةٌ مُسْتَوْحَاةٌ مِنْ الْأَدَبِ الْيَابَانِيِّ- بِتَصَرُّفٍ ',
                        textAlign: TextAlign.center,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Tajawal ',
                              color: FlutterFlowTheme.of(context).primaryText,
                              fontSize: 17.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    ),
                    Expanded(
                      child: ListView(
                        padding: EdgeInsets.zero,
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        children: [
                          Container(
                            width: 100.0,
                            height: 100.0,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFFF4AF9A), Colors.white],
                                stops: [0.0, 1.0],
                                begin: AlignmentDirectional(0.0, -1.0),
                                end: AlignmentDirectional(0, 1.0),
                              ),
                              borderRadius: BorderRadius.circular(2.0),
                              border: Border.all(
                                color: FlutterFlowTheme.of(context).accent3,
                                width: 2.0,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Flexible(
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      _model.soundPlayer1 ??= AudioPlayer();
                                      if (_model.soundPlayer1!.playing) {
                                        await _model.soundPlayer1!.stop();
                                      }
                                      _model.soundPlayer1!.setVolume(1.0);
                                      _model.soundPlayer1!
                                          .setAsset(
                                              'assets/audios/tapSound.mp3')
                                          .then((_) =>
                                              _model.soundPlayer1!.play());

                                      FFAppState().currentStoryID =
                                          FFAppState().IDStory111;
                                      safeSetState(() {});
                                      if (FFAppState().isPremium) {
                                        context.pushNamed(
                                          Story11Part1Widget.routeName,
                                          extra: <String, dynamic>{
                                            '__transition_info__':
                                                TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                            ),
                                          },
                                        );

                                        FFAppState().addToReadStoriesList(
                                            FFAppState().currentStoryID);
                                        safeSetState(() {});
                                        FFAppState().addToReadStoryIDs(
                                            FFAppState().IDStory111.toString());
                                        safeSetState(() {});
                                      } else {
                                        if (FFAppState()
                                            .ReadStoriesList
                                            .contains(
                                                FFAppState().currentStoryID)) {
                                          context.pushNamed(
                                            Story11Part1Widget.routeName,
                                            extra: <String, dynamic>{
                                              '__transition_info__':
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                              ),
                                            },
                                          );

                                          FFAppState().addToReadStoryIDs(
                                              FFAppState()
                                                  .IDStory111
                                                  .toString());
                                          safeSetState(() {});
                                        } else {
                                          if (dateTimeFormat(
                                                "yMd",
                                                FFAppState().lastReadingTime,
                                                locale:
                                                    FFLocalizations.of(context)
                                                        .languageCode,
                                              ) !=
                                              dateTimeFormat(
                                                "yMd",
                                                getCurrentTimestamp,
                                                locale:
                                                    FFLocalizations.of(context)
                                                        .languageCode,
                                              )) {
                                            FFAppState().dailyStoryCount = 1;
                                            FFAppState().lastReadingTime =
                                                getCurrentTimestamp;
                                            FFAppState()
                                                .deleteReadStoriesList();
                                            FFAppState().ReadStoriesList = [];

                                            safeSetState(() {});

                                            context.pushNamed(
                                              Story11Part1Widget.routeName,
                                              extra: <String, dynamic>{
                                                '__transition_info__':
                                                    TransitionInfo(
                                                  hasTransition: true,
                                                  transitionType:
                                                      PageTransitionType.fade,
                                                ),
                                              },
                                            );

                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            safeSetState(() {});
                                            FFAppState().addToReadStoryIDs(
                                                FFAppState()
                                                    .IDStory111
                                                    .toString());
                                            safeSetState(() {});
                                          } else {
                                            if (FFAppState().dailyStoryCount <
                                                2) {
                                              FFAppState().dailyStoryCount =
                                                  FFAppState().dailyStoryCount +
                                                      1;
                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              FFAppState().lastReadingTime =
                                                  getCurrentTimestamp;
                                              safeSetState(() {});

                                              context.pushNamed(
                                                Story11Part1Widget.routeName,
                                                extra: <String, dynamic>{
                                                  '__transition_info__':
                                                      TransitionInfo(
                                                    hasTransition: true,
                                                    transitionType:
                                                        PageTransitionType.fade,
                                                  ),
                                                },
                                              );

                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              safeSetState(() {});
                                              FFAppState().addToReadStoryIDs(
                                                  FFAppState()
                                                      .IDStory111
                                                      .toString());
                                              safeSetState(() {});
                                            } else {
                                              await showModalBottomSheet(
                                                isScrollControlled: true,
                                                backgroundColor:
                                                    Colors.transparent,
                                                enableDrag: false,
                                                context: context,
                                                builder: (context) {
                                                  return GestureDetector(
                                                    onTap: () {
                                                      FocusScope.of(context)
                                                          .unfocus();
                                                      FocusManager
                                                          .instance.primaryFocus
                                                          ?.unfocus();
                                                    },
                                                    child: Padding(
                                                      padding: MediaQuery
                                                          .viewInsetsOf(
                                                              context),
                                                      child: Container(
                                                        height: 300.0,
                                                        child:
                                                            DailyLimitSheetWidget(),
                                                      ),
                                                    ),
                                                  );
                                                },
                                              ).then((value) =>
                                                  safeSetState(() {}));
                                            }
                                          }
                                        }
                                      }
                                    },
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8.0),
                                      child: CachedNetworkImage(
                                        fadeInDuration:
                                            Duration(milliseconds: 0),
                                        fadeOutDuration:
                                            Duration(milliseconds: 0),
                                        imageUrl:
                                            'https://raw.githubusercontent.com/TellMeaStory-Emma/Tell-Me-a-Story/main/Story11part_1img/02.webp',
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                1.0,
                                        height: 200.0,
                                        fit: BoxFit.contain,
                                        alignment: Alignment(0.0, 0.0),
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      10.0, 0.0, 0.0, 0.0),
                                  child: Text(
                                    'الجزء الأول: \n\nسلمى في مكان جديد',
                                    textAlign: TextAlign.center,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Tajawal ',
                                          fontSize: 17.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                ),
                                FFButtonWidget(
                                  onPressed: () async {
                                    _model.soundPlayer2 ??= AudioPlayer();
                                    if (_model.soundPlayer2!.playing) {
                                      await _model.soundPlayer2!.stop();
                                    }
                                    _model.soundPlayer2!.setVolume(1.0);
                                    _model.soundPlayer2!
                                        .setAsset('assets/audios/tapSound.mp3')
                                        .then(
                                            (_) => _model.soundPlayer2!.play());

                                    FFAppState().currentStoryID =
                                        FFAppState().IDStory111;
                                    safeSetState(() {});
                                    if (FFAppState().isPremium) {
                                      context.pushNamed(
                                        Story11Part1Widget.routeName,
                                        extra: <String, dynamic>{
                                          '__transition_info__': TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                          ),
                                        },
                                      );

                                      FFAppState().addToReadStoriesList(
                                          FFAppState().currentStoryID);
                                      safeSetState(() {});
                                      FFAppState().addToReadStoryIDs(
                                          FFAppState().IDStory111.toString());
                                      safeSetState(() {});
                                    } else {
                                      if (FFAppState().ReadStoriesList.contains(
                                          FFAppState().currentStoryID)) {
                                        context.pushNamed(
                                          Story11Part1Widget.routeName,
                                          extra: <String, dynamic>{
                                            '__transition_info__':
                                                TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                            ),
                                          },
                                        );

                                        FFAppState().addToReadStoryIDs(
                                            FFAppState().IDStory111.toString());
                                        safeSetState(() {});
                                      } else {
                                        if (dateTimeFormat(
                                              "yMd",
                                              FFAppState().lastReadingTime,
                                              locale:
                                                  FFLocalizations.of(context)
                                                      .languageCode,
                                            ) !=
                                            dateTimeFormat(
                                              "yMd",
                                              getCurrentTimestamp,
                                              locale:
                                                  FFLocalizations.of(context)
                                                      .languageCode,
                                            )) {
                                          FFAppState().dailyStoryCount = 1;
                                          FFAppState().lastReadingTime =
                                              getCurrentTimestamp;
                                          FFAppState().deleteReadStoriesList();
                                          FFAppState().ReadStoriesList = [];

                                          safeSetState(() {});

                                          context.pushNamed(
                                            Story11Part1Widget.routeName,
                                            extra: <String, dynamic>{
                                              '__transition_info__':
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                              ),
                                            },
                                          );

                                          FFAppState().addToReadStoriesList(
                                              FFAppState().currentStoryID);
                                          safeSetState(() {});
                                          FFAppState().addToReadStoryIDs(
                                              FFAppState()
                                                  .IDStory111
                                                  .toString());
                                          safeSetState(() {});
                                        } else {
                                          if (FFAppState().dailyStoryCount <
                                              2) {
                                            FFAppState().dailyStoryCount =
                                                FFAppState().dailyStoryCount +
                                                    1;
                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            FFAppState().lastReadingTime =
                                                getCurrentTimestamp;
                                            safeSetState(() {});

                                            context.pushNamed(
                                              Story11Part1Widget.routeName,
                                              extra: <String, dynamic>{
                                                '__transition_info__':
                                                    TransitionInfo(
                                                  hasTransition: true,
                                                  transitionType:
                                                      PageTransitionType.fade,
                                                ),
                                              },
                                            );

                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            safeSetState(() {});
                                            FFAppState().addToReadStoryIDs(
                                                FFAppState()
                                                    .IDStory111
                                                    .toString());
                                            safeSetState(() {});
                                          } else {
                                            await showModalBottomSheet(
                                              isScrollControlled: true,
                                              backgroundColor:
                                                  Colors.transparent,
                                              enableDrag: false,
                                              context: context,
                                              builder: (context) {
                                                return GestureDetector(
                                                  onTap: () {
                                                    FocusScope.of(context)
                                                        .unfocus();
                                                    FocusManager
                                                        .instance.primaryFocus
                                                        ?.unfocus();
                                                  },
                                                  child: Padding(
                                                    padding:
                                                        MediaQuery.viewInsetsOf(
                                                            context),
                                                    child: Container(
                                                      height: 300.0,
                                                      child:
                                                          DailyLimitSheetWidget(),
                                                    ),
                                                  ),
                                                );
                                              },
                                            ).then(
                                                (value) => safeSetState(() {}));
                                          }
                                        }
                                      }
                                    }
                                  },
                                  text: 'اقرَأ المزيــد',
                                  options: FFButtonOptions(
                                    height: 31.47,
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        5.0, 0.0, 5.0, 0.0),
                                    iconPadding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 0.0, 0.0),
                                    color: Color(0xFFEEA667),
                                    textStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          fontFamily: 'Tajawal ',
                                          color: Colors.white,
                                          fontSize: 18.0,
                                          letterSpacing: 0.0,
                                        ),
                                    elevation: 0.0,
                                    borderSide: BorderSide(
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 100.0,
                            height: 100.0,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFFF4AF9A), Colors.white],
                                stops: [0.0, 1.0],
                                begin: AlignmentDirectional(0.0, -1.0),
                                end: AlignmentDirectional(0, 1.0),
                              ),
                              borderRadius: BorderRadius.circular(0.0),
                              border: Border.all(
                                color: FlutterFlowTheme.of(context).accent3,
                                width: 2.0,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Flexible(
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      _model.soundPlayer3 ??= AudioPlayer();
                                      if (_model.soundPlayer3!.playing) {
                                        await _model.soundPlayer3!.stop();
                                      }
                                      _model.soundPlayer3!.setVolume(1.0);
                                      _model.soundPlayer3!
                                          .setAsset(
                                              'assets/audios/tapSound.mp3')
                                          .then((_) =>
                                              _model.soundPlayer3!.play());

                                      FFAppState().currentStoryID =
                                          FFAppState().IDStory112;
                                      safeSetState(() {});
                                      if (FFAppState().isPremium) {
                                        context.pushNamed(
                                          Story11Part2Widget.routeName,
                                          extra: <String, dynamic>{
                                            '__transition_info__':
                                                TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                            ),
                                          },
                                        );

                                        FFAppState().addToReadStoriesList(
                                            FFAppState().currentStoryID);
                                        safeSetState(() {});
                                        FFAppState().addToReadStoryIDs(
                                            FFAppState().IDStory112.toString());
                                        safeSetState(() {});
                                      } else {
                                        if (FFAppState()
                                            .ReadStoriesList
                                            .contains(
                                                FFAppState().currentStoryID)) {
                                          context.pushNamed(
                                            Story11Part2Widget.routeName,
                                            extra: <String, dynamic>{
                                              '__transition_info__':
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                              ),
                                            },
                                          );

                                          FFAppState().addToReadStoryIDs(
                                              FFAppState()
                                                  .IDStory112
                                                  .toString());
                                          safeSetState(() {});
                                        } else {
                                          if (dateTimeFormat(
                                                "yMd",
                                                FFAppState().lastReadingTime,
                                                locale:
                                                    FFLocalizations.of(context)
                                                        .languageCode,
                                              ) !=
                                              dateTimeFormat(
                                                "yMd",
                                                getCurrentTimestamp,
                                                locale:
                                                    FFLocalizations.of(context)
                                                        .languageCode,
                                              )) {
                                            FFAppState().dailyStoryCount = 1;
                                            FFAppState().lastReadingTime =
                                                getCurrentTimestamp;
                                            FFAppState()
                                                .deleteReadStoriesList();
                                            FFAppState().ReadStoriesList = [];

                                            safeSetState(() {});

                                            context.pushNamed(
                                              Story11Part2Widget.routeName,
                                              extra: <String, dynamic>{
                                                '__transition_info__':
                                                    TransitionInfo(
                                                  hasTransition: true,
                                                  transitionType:
                                                      PageTransitionType.fade,
                                                ),
                                              },
                                            );

                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            safeSetState(() {});
                                            FFAppState().addToReadStoryIDs(
                                                FFAppState()
                                                    .IDStory112
                                                    .toString());
                                            safeSetState(() {});
                                          } else {
                                            if (FFAppState().dailyStoryCount <
                                                2) {
                                              FFAppState().dailyStoryCount =
                                                  FFAppState().dailyStoryCount +
                                                      1;
                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              FFAppState().lastReadingTime =
                                                  getCurrentTimestamp;
                                              safeSetState(() {});

                                              context.pushNamed(
                                                Story11Part2Widget.routeName,
                                                extra: <String, dynamic>{
                                                  '__transition_info__':
                                                      TransitionInfo(
                                                    hasTransition: true,
                                                    transitionType:
                                                        PageTransitionType.fade,
                                                  ),
                                                },
                                              );

                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              safeSetState(() {});
                                              FFAppState().addToReadStoryIDs(
                                                  FFAppState()
                                                      .IDStory112
                                                      .toString());
                                              safeSetState(() {});
                                            } else {
                                              await showModalBottomSheet(
                                                isScrollControlled: true,
                                                backgroundColor:
                                                    Colors.transparent,
                                                enableDrag: false,
                                                context: context,
                                                builder: (context) {
                                                  return GestureDetector(
                                                    onTap: () {
                                                      FocusScope.of(context)
                                                          .unfocus();
                                                      FocusManager
                                                          .instance.primaryFocus
                                                          ?.unfocus();
                                                    },
                                                    child: Padding(
                                                      padding: MediaQuery
                                                          .viewInsetsOf(
                                                              context),
                                                      child: Container(
                                                        height: 300.0,
                                                        child:
                                                            DailyLimitSheetWidget(),
                                                      ),
                                                    ),
                                                  );
                                                },
                                              ).then((value) =>
                                                  safeSetState(() {}));
                                            }
                                          }
                                        }
                                      }
                                    },
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8.0),
                                      child: CachedNetworkImage(
                                        fadeInDuration:
                                            Duration(milliseconds: 0),
                                        fadeOutDuration:
                                            Duration(milliseconds: 0),
                                        imageUrl:
                                            'https://raw.githubusercontent.com/TellMeaStory-Emma/Tell-Me-a-Story/main/Story11part_2img/03.webp',
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                1.0,
                                        height: 200.0,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      10.0, 0.0, 0.0, 0.0),
                                  child: Text(
                                    'الجزء الثاني: \n\nكيف سأتحدث اليابانية؟',
                                    textAlign: TextAlign.center,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Tajawal ',
                                          fontSize: 17.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                ),
                                FFButtonWidget(
                                  onPressed: () async {
                                    _model.soundPlayer4 ??= AudioPlayer();
                                    if (_model.soundPlayer4!.playing) {
                                      await _model.soundPlayer4!.stop();
                                    }
                                    _model.soundPlayer4!.setVolume(1.0);
                                    _model.soundPlayer4!
                                        .setAsset('assets/audios/tapSound.mp3')
                                        .then(
                                            (_) => _model.soundPlayer4!.play());

                                    FFAppState().currentStoryID =
                                        FFAppState().IDStory112;
                                    safeSetState(() {});
                                    if (FFAppState().isPremium) {
                                      context.pushNamed(
                                        Story11Part2Widget.routeName,
                                        extra: <String, dynamic>{
                                          '__transition_info__': TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                          ),
                                        },
                                      );

                                      FFAppState().addToReadStoriesList(
                                          FFAppState().currentStoryID);
                                      safeSetState(() {});
                                      FFAppState().addToReadStoryIDs(
                                          FFAppState().IDStory112.toString());
                                      safeSetState(() {});
                                    } else {
                                      if (FFAppState().ReadStoriesList.contains(
                                          FFAppState().currentStoryID)) {
                                        context.pushNamed(
                                          Story11Part2Widget.routeName,
                                          extra: <String, dynamic>{
                                            '__transition_info__':
                                                TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                            ),
                                          },
                                        );

                                        FFAppState().addToReadStoryIDs(
                                            FFAppState().IDStory112.toString());
                                        safeSetState(() {});
                                      } else {
                                        if (dateTimeFormat(
                                              "yMd",
                                              FFAppState().lastReadingTime,
                                              locale:
                                                  FFLocalizations.of(context)
                                                      .languageCode,
                                            ) !=
                                            dateTimeFormat(
                                              "yMd",
                                              getCurrentTimestamp,
                                              locale:
                                                  FFLocalizations.of(context)
                                                      .languageCode,
                                            )) {
                                          FFAppState().dailyStoryCount = 1;
                                          FFAppState().lastReadingTime =
                                              getCurrentTimestamp;
                                          FFAppState().deleteReadStoriesList();
                                          FFAppState().ReadStoriesList = [];

                                          safeSetState(() {});

                                          context.pushNamed(
                                            Story11Part2Widget.routeName,
                                            extra: <String, dynamic>{
                                              '__transition_info__':
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                              ),
                                            },
                                          );

                                          FFAppState().addToReadStoriesList(
                                              FFAppState().currentStoryID);
                                          safeSetState(() {});
                                          FFAppState().addToReadStoryIDs(
                                              FFAppState()
                                                  .IDStory112
                                                  .toString());
                                          safeSetState(() {});
                                        } else {
                                          if (FFAppState().dailyStoryCount <
                                              2) {
                                            FFAppState().dailyStoryCount =
                                                FFAppState().dailyStoryCount +
                                                    1;
                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            FFAppState().lastReadingTime =
                                                getCurrentTimestamp;
                                            safeSetState(() {});

                                            context.pushNamed(
                                              Story11Part2Widget.routeName,
                                              extra: <String, dynamic>{
                                                '__transition_info__':
                                                    TransitionInfo(
                                                  hasTransition: true,
                                                  transitionType:
                                                      PageTransitionType.fade,
                                                ),
                                              },
                                            );

                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            safeSetState(() {});
                                            FFAppState().addToReadStoryIDs(
                                                FFAppState()
                                                    .IDStory112
                                                    .toString());
                                            safeSetState(() {});
                                          } else {
                                            await showModalBottomSheet(
                                              isScrollControlled: true,
                                              backgroundColor:
                                                  Colors.transparent,
                                              enableDrag: false,
                                              context: context,
                                              builder: (context) {
                                                return GestureDetector(
                                                  onTap: () {
                                                    FocusScope.of(context)
                                                        .unfocus();
                                                    FocusManager
                                                        .instance.primaryFocus
                                                        ?.unfocus();
                                                  },
                                                  child: Padding(
                                                    padding:
                                                        MediaQuery.viewInsetsOf(
                                                            context),
                                                    child: Container(
                                                      height: 300.0,
                                                      child:
                                                          DailyLimitSheetWidget(),
                                                    ),
                                                  ),
                                                );
                                              },
                                            ).then(
                                                (value) => safeSetState(() {}));
                                          }
                                        }
                                      }
                                    }
                                  },
                                  text: 'اقرَأ المزيــد',
                                  options: FFButtonOptions(
                                    height: 31.47,
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        5.0, 0.0, 5.0, 0.0),
                                    iconPadding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 0.0, 0.0),
                                    color: Color(0xFFEEA667),
                                    textStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          fontFamily: 'Tajawal ',
                                          color: Colors.white,
                                          fontSize: 18.0,
                                          letterSpacing: 0.0,
                                        ),
                                    elevation: 0.0,
                                    borderSide: BorderSide(
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 100.0,
                            height: 100.0,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFFF4AF9A), Colors.white],
                                stops: [0.0, 1.0],
                                begin: AlignmentDirectional(0.0, -1.0),
                                end: AlignmentDirectional(0, 1.0),
                              ),
                              borderRadius: BorderRadius.circular(2.0),
                              border: Border.all(
                                color: FlutterFlowTheme.of(context).accent3,
                                width: 2.0,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Flexible(
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      _model.soundPlayer5 ??= AudioPlayer();
                                      if (_model.soundPlayer5!.playing) {
                                        await _model.soundPlayer5!.stop();
                                      }
                                      _model.soundPlayer5!.setVolume(1.0);
                                      _model.soundPlayer5!
                                          .setAsset(
                                              'assets/audios/tapSound.mp3')
                                          .then((_) =>
                                              _model.soundPlayer5!.play());

                                      FFAppState().currentStoryID =
                                          FFAppState().IDStory113;
                                      safeSetState(() {});
                                      if (FFAppState().isPremium) {
                                        context.pushNamed(
                                          Story11Part3Widget.routeName,
                                          extra: <String, dynamic>{
                                            '__transition_info__':
                                                TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                            ),
                                          },
                                        );

                                        FFAppState().addToReadStoriesList(
                                            FFAppState().currentStoryID);
                                        safeSetState(() {});
                                        FFAppState().addToReadStoryIDs(
                                            FFAppState().IDStory113.toString());
                                        safeSetState(() {});
                                      } else {
                                        if (FFAppState()
                                            .ReadStoriesList
                                            .contains(
                                                FFAppState().currentStoryID)) {
                                          context.pushNamed(
                                            Story11Part3Widget.routeName,
                                            extra: <String, dynamic>{
                                              '__transition_info__':
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                              ),
                                            },
                                          );

                                          FFAppState().addToReadStoryIDs(
                                              FFAppState()
                                                  .IDStory113
                                                  .toString());
                                          safeSetState(() {});
                                        } else {
                                          if (dateTimeFormat(
                                                "yMd",
                                                FFAppState().lastReadingTime,
                                                locale:
                                                    FFLocalizations.of(context)
                                                        .languageCode,
                                              ) !=
                                              dateTimeFormat(
                                                "yMd",
                                                getCurrentTimestamp,
                                                locale:
                                                    FFLocalizations.of(context)
                                                        .languageCode,
                                              )) {
                                            FFAppState().dailyStoryCount = 1;
                                            FFAppState().lastReadingTime =
                                                getCurrentTimestamp;
                                            FFAppState()
                                                .deleteReadStoriesList();
                                            FFAppState().ReadStoriesList = [];

                                            safeSetState(() {});

                                            context.pushNamed(
                                              Story11Part3Widget.routeName,
                                              extra: <String, dynamic>{
                                                '__transition_info__':
                                                    TransitionInfo(
                                                  hasTransition: true,
                                                  transitionType:
                                                      PageTransitionType.fade,
                                                ),
                                              },
                                            );

                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            safeSetState(() {});
                                            FFAppState().addToReadStoryIDs(
                                                FFAppState()
                                                    .IDStory113
                                                    .toString());
                                            safeSetState(() {});
                                          } else {
                                            if (FFAppState().dailyStoryCount <
                                                2) {
                                              FFAppState().dailyStoryCount =
                                                  FFAppState().dailyStoryCount +
                                                      1;
                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              FFAppState().lastReadingTime =
                                                  getCurrentTimestamp;
                                              safeSetState(() {});

                                              context.pushNamed(
                                                Story11Part3Widget.routeName,
                                                extra: <String, dynamic>{
                                                  '__transition_info__':
                                                      TransitionInfo(
                                                    hasTransition: true,
                                                    transitionType:
                                                        PageTransitionType.fade,
                                                  ),
                                                },
                                              );

                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              safeSetState(() {});
                                              FFAppState().addToReadStoryIDs(
                                                  FFAppState()
                                                      .IDStory113
                                                      .toString());
                                              safeSetState(() {});
                                            } else {
                                              await showModalBottomSheet(
                                                isScrollControlled: true,
                                                backgroundColor:
                                                    Colors.transparent,
                                                enableDrag: false,
                                                context: context,
                                                builder: (context) {
                                                  return GestureDetector(
                                                    onTap: () {
                                                      FocusScope.of(context)
                                                          .unfocus();
                                                      FocusManager
                                                          .instance.primaryFocus
                                                          ?.unfocus();
                                                    },
                                                    child: Padding(
                                                      padding: MediaQuery
                                                          .viewInsetsOf(
                                                              context),
                                                      child: Container(
                                                        height: 300.0,
                                                        child:
                                                            DailyLimitSheetWidget(),
                                                      ),
                                                    ),
                                                  );
                                                },
                                              ).then((value) =>
                                                  safeSetState(() {}));
                                            }
                                          }
                                        }
                                      }
                                    },
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8.0),
                                      child: CachedNetworkImage(
                                        fadeInDuration:
                                            Duration(milliseconds: 0),
                                        fadeOutDuration:
                                            Duration(milliseconds: 0),
                                        imageUrl:
                                            'https://raw.githubusercontent.com/TellMeaStory-Emma/Tell-Me-a-Story/main/Story11part_3img/04.webp',
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                1.0,
                                        height: 200.0,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      10.0, 0.0, 0.0, 0.0),
                                  child: Text(
                                    'الجزء الثالث: \n\nنوري... طيف الثعلب',
                                    textAlign: TextAlign.center,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Tajawal ',
                                          fontSize: 17.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                ),
                                FFButtonWidget(
                                  onPressed: () async {
                                    _model.soundPlayer6 ??= AudioPlayer();
                                    if (_model.soundPlayer6!.playing) {
                                      await _model.soundPlayer6!.stop();
                                    }
                                    _model.soundPlayer6!.setVolume(1.0);
                                    _model.soundPlayer6!
                                        .setAsset('assets/audios/tapSound.mp3')
                                        .then(
                                            (_) => _model.soundPlayer6!.play());

                                    FFAppState().currentStoryID =
                                        FFAppState().IDStory113;
                                    safeSetState(() {});
                                    if (FFAppState().isPremium) {
                                      context.pushNamed(
                                        Story11Part3Widget.routeName,
                                        extra: <String, dynamic>{
                                          '__transition_info__': TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                          ),
                                        },
                                      );

                                      FFAppState().addToReadStoriesList(
                                          FFAppState().currentStoryID);
                                      safeSetState(() {});
                                      FFAppState().addToReadStoryIDs(
                                          FFAppState().IDStory113.toString());
                                      safeSetState(() {});
                                    } else {
                                      if (FFAppState().ReadStoriesList.contains(
                                          FFAppState().currentStoryID)) {
                                        context.pushNamed(
                                          Story11Part3Widget.routeName,
                                          extra: <String, dynamic>{
                                            '__transition_info__':
                                                TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                            ),
                                          },
                                        );

                                        FFAppState().addToReadStoryIDs(
                                            FFAppState().IDStory113.toString());
                                        safeSetState(() {});
                                      } else {
                                        if (dateTimeFormat(
                                              "yMd",
                                              FFAppState().lastReadingTime,
                                              locale:
                                                  FFLocalizations.of(context)
                                                      .languageCode,
                                            ) !=
                                            dateTimeFormat(
                                              "yMd",
                                              getCurrentTimestamp,
                                              locale:
                                                  FFLocalizations.of(context)
                                                      .languageCode,
                                            )) {
                                          FFAppState().dailyStoryCount = 1;
                                          FFAppState().lastReadingTime =
                                              getCurrentTimestamp;
                                          FFAppState().deleteReadStoriesList();
                                          FFAppState().ReadStoriesList = [];

                                          safeSetState(() {});

                                          context.pushNamed(
                                            Story11Part3Widget.routeName,
                                            extra: <String, dynamic>{
                                              '__transition_info__':
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                              ),
                                            },
                                          );

                                          FFAppState().addToReadStoriesList(
                                              FFAppState().currentStoryID);
                                          safeSetState(() {});
                                          FFAppState().addToReadStoryIDs(
                                              FFAppState()
                                                  .IDStory113
                                                  .toString());
                                          safeSetState(() {});
                                        } else {
                                          if (FFAppState().dailyStoryCount <
                                              2) {
                                            FFAppState().dailyStoryCount =
                                                FFAppState().dailyStoryCount +
                                                    1;
                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            FFAppState().lastReadingTime =
                                                getCurrentTimestamp;
                                            safeSetState(() {});

                                            context.pushNamed(
                                              Story11Part3Widget.routeName,
                                              extra: <String, dynamic>{
                                                '__transition_info__':
                                                    TransitionInfo(
                                                  hasTransition: true,
                                                  transitionType:
                                                      PageTransitionType.fade,
                                                ),
                                              },
                                            );

                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            safeSetState(() {});
                                            FFAppState().addToReadStoryIDs(
                                                FFAppState()
                                                    .IDStory113
                                                    .toString());
                                            safeSetState(() {});
                                          } else {
                                            await showModalBottomSheet(
                                              isScrollControlled: true,
                                              backgroundColor:
                                                  Colors.transparent,
                                              enableDrag: false,
                                              context: context,
                                              builder: (context) {
                                                return GestureDetector(
                                                  onTap: () {
                                                    FocusScope.of(context)
                                                        .unfocus();
                                                    FocusManager
                                                        .instance.primaryFocus
                                                        ?.unfocus();
                                                  },
                                                  child: Padding(
                                                    padding:
                                                        MediaQuery.viewInsetsOf(
                                                            context),
                                                    child: Container(
                                                      height: 300.0,
                                                      child:
                                                          DailyLimitSheetWidget(),
                                                    ),
                                                  ),
                                                );
                                              },
                                            ).then(
                                                (value) => safeSetState(() {}));
                                          }
                                        }
                                      }
                                    }
                                  },
                                  text: 'اقرَأ المزيــد',
                                  options: FFButtonOptions(
                                    height: 31.47,
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        5.0, 0.0, 5.0, 0.0),
                                    iconPadding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 0.0, 0.0),
                                    color: Color(0xFFEEA667),
                                    textStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          fontFamily: 'Tajawal ',
                                          color: Colors.white,
                                          fontSize: 18.0,
                                          letterSpacing: 0.0,
                                        ),
                                    elevation: 0.0,
                                    borderSide: BorderSide(
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 100.0,
                            height: 100.0,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFFF4AF9A), Colors.white],
                                stops: [0.0, 1.0],
                                begin: AlignmentDirectional(0.0, -1.0),
                                end: AlignmentDirectional(0, 1.0),
                              ),
                              borderRadius: BorderRadius.circular(2.0),
                              border: Border.all(
                                color: FlutterFlowTheme.of(context).accent3,
                                width: 2.0,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Flexible(
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      _model.soundPlayer7 ??= AudioPlayer();
                                      if (_model.soundPlayer7!.playing) {
                                        await _model.soundPlayer7!.stop();
                                      }
                                      _model.soundPlayer7!.setVolume(1.0);
                                      _model.soundPlayer7!
                                          .setAsset(
                                              'assets/audios/tapSound.mp3')
                                          .then((_) =>
                                              _model.soundPlayer7!.play());

                                      FFAppState().currentStoryID =
                                          FFAppState().IDStory114;
                                      safeSetState(() {});
                                      if (FFAppState().isPremium) {
                                        context.pushNamed(
                                          Story11Part4Widget.routeName,
                                          extra: <String, dynamic>{
                                            '__transition_info__':
                                                TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                            ),
                                          },
                                        );

                                        FFAppState().addToReadStoriesList(
                                            FFAppState().currentStoryID);
                                        safeSetState(() {});
                                        FFAppState().addToReadStoryIDs(
                                            FFAppState().IDStory114.toString());
                                        safeSetState(() {});
                                      } else {
                                        if (FFAppState()
                                            .ReadStoriesList
                                            .contains(
                                                FFAppState().currentStoryID)) {
                                          context.pushNamed(
                                            Story11Part4Widget.routeName,
                                            extra: <String, dynamic>{
                                              '__transition_info__':
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                              ),
                                            },
                                          );

                                          FFAppState().addToReadStoryIDs(
                                              FFAppState()
                                                  .IDStory114
                                                  .toString());
                                          safeSetState(() {});
                                        } else {
                                          if (dateTimeFormat(
                                                "yMd",
                                                FFAppState().lastReadingTime,
                                                locale:
                                                    FFLocalizations.of(context)
                                                        .languageCode,
                                              ) !=
                                              dateTimeFormat(
                                                "yMd",
                                                getCurrentTimestamp,
                                                locale:
                                                    FFLocalizations.of(context)
                                                        .languageCode,
                                              )) {
                                            FFAppState().dailyStoryCount = 1;
                                            FFAppState().lastReadingTime =
                                                getCurrentTimestamp;
                                            FFAppState()
                                                .deleteReadStoriesList();
                                            FFAppState().ReadStoriesList = [];

                                            safeSetState(() {});

                                            context.pushNamed(
                                              Story11Part4Widget.routeName,
                                              extra: <String, dynamic>{
                                                '__transition_info__':
                                                    TransitionInfo(
                                                  hasTransition: true,
                                                  transitionType:
                                                      PageTransitionType.fade,
                                                ),
                                              },
                                            );

                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            safeSetState(() {});
                                            FFAppState().addToReadStoryIDs(
                                                FFAppState()
                                                    .IDStory114
                                                    .toString());
                                            safeSetState(() {});
                                          } else {
                                            if (FFAppState().dailyStoryCount <
                                                2) {
                                              FFAppState().dailyStoryCount =
                                                  FFAppState().dailyStoryCount +
                                                      1;
                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              FFAppState().lastReadingTime =
                                                  getCurrentTimestamp;
                                              safeSetState(() {});

                                              context.pushNamed(
                                                Story11Part4Widget.routeName,
                                                extra: <String, dynamic>{
                                                  '__transition_info__':
                                                      TransitionInfo(
                                                    hasTransition: true,
                                                    transitionType:
                                                        PageTransitionType.fade,
                                                  ),
                                                },
                                              );

                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              safeSetState(() {});
                                              FFAppState().addToReadStoryIDs(
                                                  FFAppState()
                                                      .IDStory114
                                                      .toString());
                                              safeSetState(() {});
                                            } else {
                                              await showModalBottomSheet(
                                                isScrollControlled: true,
                                                backgroundColor:
                                                    Colors.transparent,
                                                enableDrag: false,
                                                context: context,
                                                builder: (context) {
                                                  return GestureDetector(
                                                    onTap: () {
                                                      FocusScope.of(context)
                                                          .unfocus();
                                                      FocusManager
                                                          .instance.primaryFocus
                                                          ?.unfocus();
                                                    },
                                                    child: Padding(
                                                      padding: MediaQuery
                                                          .viewInsetsOf(
                                                              context),
                                                      child: Container(
                                                        height: 300.0,
                                                        child:
                                                            DailyLimitSheetWidget(),
                                                      ),
                                                    ),
                                                  );
                                                },
                                              ).then((value) =>
                                                  safeSetState(() {}));
                                            }
                                          }
                                        }
                                      }
                                    },
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8.0),
                                      child: CachedNetworkImage(
                                        fadeInDuration:
                                            Duration(milliseconds: 0),
                                        fadeOutDuration:
                                            Duration(milliseconds: 0),
                                        imageUrl:
                                            'https://raw.githubusercontent.com/TellMeaStory-Emma/Tell-Me-a-Story/main/Story11part_4img/03.webp',
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                1.0,
                                        height: 200.0,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      10.0, 0.0, 0.0, 0.0),
                                  child: Text(
                                    'الجزء الرابع: \n\nأنتِ بحاجة إلى صديق',
                                    textAlign: TextAlign.center,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Tajawal ',
                                          fontSize: 17.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                ),
                                FFButtonWidget(
                                  onPressed: () async {
                                    _model.soundPlayer8 ??= AudioPlayer();
                                    if (_model.soundPlayer8!.playing) {
                                      await _model.soundPlayer8!.stop();
                                    }
                                    _model.soundPlayer8!.setVolume(1.0);
                                    _model.soundPlayer8!
                                        .setAsset('assets/audios/tapSound.mp3')
                                        .then(
                                            (_) => _model.soundPlayer8!.play());

                                    FFAppState().currentStoryID =
                                        FFAppState().IDStory114;
                                    safeSetState(() {});
                                    if (FFAppState().isPremium) {
                                      context.pushNamed(
                                        Story11Part4Widget.routeName,
                                        extra: <String, dynamic>{
                                          '__transition_info__': TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                          ),
                                        },
                                      );

                                      FFAppState().addToReadStoriesList(
                                          FFAppState().currentStoryID);
                                      safeSetState(() {});
                                      FFAppState().addToReadStoryIDs(
                                          FFAppState().IDStory114.toString());
                                      safeSetState(() {});
                                    } else {
                                      if (FFAppState().ReadStoriesList.contains(
                                          FFAppState().currentStoryID)) {
                                        context.pushNamed(
                                          Story11Part4Widget.routeName,
                                          extra: <String, dynamic>{
                                            '__transition_info__':
                                                TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                            ),
                                          },
                                        );

                                        FFAppState().addToReadStoryIDs(
                                            FFAppState().IDStory114.toString());
                                        safeSetState(() {});
                                      } else {
                                        if (dateTimeFormat(
                                              "yMd",
                                              FFAppState().lastReadingTime,
                                              locale:
                                                  FFLocalizations.of(context)
                                                      .languageCode,
                                            ) !=
                                            dateTimeFormat(
                                              "yMd",
                                              getCurrentTimestamp,
                                              locale:
                                                  FFLocalizations.of(context)
                                                      .languageCode,
                                            )) {
                                          FFAppState().dailyStoryCount = 1;
                                          FFAppState().lastReadingTime =
                                              getCurrentTimestamp;
                                          FFAppState().deleteReadStoriesList();
                                          FFAppState().ReadStoriesList = [];

                                          safeSetState(() {});

                                          context.pushNamed(
                                            Story11Part4Widget.routeName,
                                            extra: <String, dynamic>{
                                              '__transition_info__':
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                              ),
                                            },
                                          );

                                          FFAppState().addToReadStoriesList(
                                              FFAppState().currentStoryID);
                                          safeSetState(() {});
                                          FFAppState().addToReadStoryIDs(
                                              FFAppState()
                                                  .IDStory114
                                                  .toString());
                                          safeSetState(() {});
                                        } else {
                                          if (FFAppState().dailyStoryCount <
                                              2) {
                                            FFAppState().dailyStoryCount =
                                                FFAppState().dailyStoryCount +
                                                    1;
                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            FFAppState().lastReadingTime =
                                                getCurrentTimestamp;
                                            safeSetState(() {});

                                            context.pushNamed(
                                              Story11Part4Widget.routeName,
                                              extra: <String, dynamic>{
                                                '__transition_info__':
                                                    TransitionInfo(
                                                  hasTransition: true,
                                                  transitionType:
                                                      PageTransitionType.fade,
                                                ),
                                              },
                                            );

                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            safeSetState(() {});
                                            FFAppState().addToReadStoryIDs(
                                                FFAppState()
                                                    .IDStory114
                                                    .toString());
                                            safeSetState(() {});
                                          } else {
                                            await showModalBottomSheet(
                                              isScrollControlled: true,
                                              backgroundColor:
                                                  Colors.transparent,
                                              enableDrag: false,
                                              context: context,
                                              builder: (context) {
                                                return GestureDetector(
                                                  onTap: () {
                                                    FocusScope.of(context)
                                                        .unfocus();
                                                    FocusManager
                                                        .instance.primaryFocus
                                                        ?.unfocus();
                                                  },
                                                  child: Padding(
                                                    padding:
                                                        MediaQuery.viewInsetsOf(
                                                            context),
                                                    child: Container(
                                                      height: 300.0,
                                                      child:
                                                          DailyLimitSheetWidget(),
                                                    ),
                                                  ),
                                                );
                                              },
                                            ).then(
                                                (value) => safeSetState(() {}));
                                          }
                                        }
                                      }
                                    }
                                  },
                                  text: 'اقرَأ المزيــد',
                                  options: FFButtonOptions(
                                    height: 31.47,
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        5.0, 0.0, 5.0, 0.0),
                                    iconPadding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 0.0, 0.0),
                                    color: Color(0xFFEEA667),
                                    textStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          fontFamily: 'Tajawal ',
                                          color: Colors.white,
                                          fontSize: 18.0,
                                          letterSpacing: 0.0,
                                        ),
                                    elevation: 0.0,
                                    borderSide: BorderSide(
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 160.0),
                            child: Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Color(0xFFF4AF9A), Colors.white],
                                  stops: [0.0, 1.0],
                                  begin: AlignmentDirectional(0.0, -1.0),
                                  end: AlignmentDirectional(0, 1.0),
                                ),
                                borderRadius: BorderRadius.circular(2.0),
                                border: Border.all(
                                  color: FlutterFlowTheme.of(context).accent3,
                                  width: 2.0,
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Flexible(
                                    child: InkWell(
                                      splashColor: Colors.transparent,
                                      focusColor: Colors.transparent,
                                      hoverColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      onTap: () async {
                                        _model.soundPlayer9 ??= AudioPlayer();
                                        if (_model.soundPlayer9!.playing) {
                                          await _model.soundPlayer9!.stop();
                                        }
                                        _model.soundPlayer9!.setVolume(1.0);
                                        _model.soundPlayer9!
                                            .setAsset(
                                                'assets/audios/tapSound.mp3')
                                            .then((_) =>
                                                _model.soundPlayer9!.play());

                                        FFAppState().currentStoryID =
                                            FFAppState().IDStory115;
                                        safeSetState(() {});
                                        if (FFAppState().isPremium) {
                                          context.pushNamed(
                                            Story11Part5Widget.routeName,
                                            extra: <String, dynamic>{
                                              '__transition_info__':
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                              ),
                                            },
                                          );

                                          FFAppState().addToReadStoriesList(
                                              FFAppState().currentStoryID);
                                          safeSetState(() {});
                                          FFAppState().addToReadStoryIDs(
                                              FFAppState()
                                                  .IDStory115
                                                  .toString());
                                          safeSetState(() {});
                                        } else {
                                          if (FFAppState()
                                              .ReadStoriesList
                                              .contains(FFAppState()
                                                  .currentStoryID)) {
                                            context.pushNamed(
                                              Story11Part5Widget.routeName,
                                              extra: <String, dynamic>{
                                                '__transition_info__':
                                                    TransitionInfo(
                                                  hasTransition: true,
                                                  transitionType:
                                                      PageTransitionType.fade,
                                                ),
                                              },
                                            );

                                            FFAppState().addToReadStoryIDs(
                                                FFAppState()
                                                    .IDStory115
                                                    .toString());
                                            safeSetState(() {});
                                          } else {
                                            if (dateTimeFormat(
                                                  "yMd",
                                                  FFAppState().lastReadingTime,
                                                  locale: FFLocalizations.of(
                                                          context)
                                                      .languageCode,
                                                ) !=
                                                dateTimeFormat(
                                                  "yMd",
                                                  getCurrentTimestamp,
                                                  locale: FFLocalizations.of(
                                                          context)
                                                      .languageCode,
                                                )) {
                                              FFAppState().dailyStoryCount = 1;
                                              FFAppState().lastReadingTime =
                                                  getCurrentTimestamp;
                                              FFAppState()
                                                  .deleteReadStoriesList();
                                              FFAppState().ReadStoriesList = [];

                                              safeSetState(() {});

                                              context.pushNamed(
                                                Story11Part5Widget.routeName,
                                                extra: <String, dynamic>{
                                                  '__transition_info__':
                                                      TransitionInfo(
                                                    hasTransition: true,
                                                    transitionType:
                                                        PageTransitionType.fade,
                                                  ),
                                                },
                                              );

                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              safeSetState(() {});
                                              FFAppState().addToReadStoryIDs(
                                                  FFAppState()
                                                      .IDStory115
                                                      .toString());
                                              safeSetState(() {});
                                            } else {
                                              if (FFAppState().dailyStoryCount <
                                                  2) {
                                                FFAppState().dailyStoryCount =
                                                    FFAppState()
                                                            .dailyStoryCount +
                                                        1;
                                                FFAppState()
                                                    .addToReadStoriesList(
                                                        FFAppState()
                                                            .currentStoryID);
                                                FFAppState().lastReadingTime =
                                                    getCurrentTimestamp;
                                                safeSetState(() {});

                                                context.pushNamed(
                                                  Story11Part5Widget.routeName,
                                                  extra: <String, dynamic>{
                                                    '__transition_info__':
                                                        TransitionInfo(
                                                      hasTransition: true,
                                                      transitionType:
                                                          PageTransitionType
                                                              .fade,
                                                    ),
                                                  },
                                                );

                                                FFAppState()
                                                    .addToReadStoriesList(
                                                        FFAppState()
                                                            .currentStoryID);
                                                safeSetState(() {});
                                                FFAppState().addToReadStoryIDs(
                                                    FFAppState()
                                                        .IDStory115
                                                        .toString());
                                                safeSetState(() {});
                                              } else {
                                                await showModalBottomSheet(
                                                  isScrollControlled: true,
                                                  backgroundColor:
                                                      Colors.transparent,
                                                  enableDrag: false,
                                                  context: context,
                                                  builder: (context) {
                                                    return GestureDetector(
                                                      onTap: () {
                                                        FocusScope.of(context)
                                                            .unfocus();
                                                        FocusManager.instance
                                                            .primaryFocus
                                                            ?.unfocus();
                                                      },
                                                      child: Padding(
                                                        padding: MediaQuery
                                                            .viewInsetsOf(
                                                                context),
                                                        child: Container(
                                                          height: 300.0,
                                                          child:
                                                              DailyLimitSheetWidget(),
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                ).then((value) =>
                                                    safeSetState(() {}));
                                              }
                                            }
                                          }
                                        }
                                      },
                                      child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                        child: CachedNetworkImage(
                                          fadeInDuration:
                                              Duration(milliseconds: 0),
                                          fadeOutDuration:
                                              Duration(milliseconds: 0),
                                          imageUrl:
                                              'https://raw.githubusercontent.com/TellMeaStory-Emma/Tell-Me-a-Story/main/Story11part_5img/03.webp',
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  1.0,
                                          height: 200.0,
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        30.0, 0.0, 0.0, 0.0),
                                    child: Text(
                                      'الجزء الخامس: \n\nالخطوة الأولى',
                                      textAlign: TextAlign.center,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Tajawal ',
                                            fontSize: 17.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                  ),
                                  FFButtonWidget(
                                    onPressed: () async {
                                      _model.soundPlayer10 ??= AudioPlayer();
                                      if (_model.soundPlayer10!.playing) {
                                        await _model.soundPlayer10!.stop();
                                      }
                                      _model.soundPlayer10!.setVolume(1.0);
                                      _model.soundPlayer10!
                                          .setAsset(
                                              'assets/audios/tapSound.mp3')
                                          .then((_) =>
                                              _model.soundPlayer10!.play());

                                      FFAppState().currentStoryID =
                                          FFAppState().IDStory115;
                                      safeSetState(() {});
                                      if (FFAppState().isPremium) {
                                        context.pushNamed(
                                          Story11Part5Widget.routeName,
                                          extra: <String, dynamic>{
                                            '__transition_info__':
                                                TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                            ),
                                          },
                                        );

                                        FFAppState().addToReadStoriesList(
                                            FFAppState().currentStoryID);
                                        safeSetState(() {});
                                        FFAppState().addToReadStoryIDs(
                                            FFAppState().IDStory115.toString());
                                        safeSetState(() {});
                                      } else {
                                        if (FFAppState()
                                            .ReadStoriesList
                                            .contains(
                                                FFAppState().currentStoryID)) {
                                          context.pushNamed(
                                            Story11Part5Widget.routeName,
                                            extra: <String, dynamic>{
                                              '__transition_info__':
                                                  TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                              ),
                                            },
                                          );

                                          FFAppState().addToReadStoryIDs(
                                              FFAppState()
                                                  .IDStory115
                                                  .toString());
                                          safeSetState(() {});
                                        } else {
                                          if (dateTimeFormat(
                                                "yMd",
                                                FFAppState().lastReadingTime,
                                                locale:
                                                    FFLocalizations.of(context)
                                                        .languageCode,
                                              ) !=
                                              dateTimeFormat(
                                                "yMd",
                                                getCurrentTimestamp,
                                                locale:
                                                    FFLocalizations.of(context)
                                                        .languageCode,
                                              )) {
                                            FFAppState().dailyStoryCount = 1;
                                            FFAppState().lastReadingTime =
                                                getCurrentTimestamp;
                                            FFAppState()
                                                .deleteReadStoriesList();
                                            FFAppState().ReadStoriesList = [];

                                            safeSetState(() {});

                                            context.pushNamed(
                                              Story11Part5Widget.routeName,
                                              extra: <String, dynamic>{
                                                '__transition_info__':
                                                    TransitionInfo(
                                                  hasTransition: true,
                                                  transitionType:
                                                      PageTransitionType.fade,
                                                ),
                                              },
                                            );

                                            FFAppState().addToReadStoriesList(
                                                FFAppState().currentStoryID);
                                            safeSetState(() {});
                                            FFAppState().addToReadStoryIDs(
                                                FFAppState()
                                                    .IDStory115
                                                    .toString());
                                            safeSetState(() {});
                                          } else {
                                            if (FFAppState().dailyStoryCount <
                                                2) {
                                              FFAppState().dailyStoryCount =
                                                  FFAppState().dailyStoryCount +
                                                      1;
                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              FFAppState().lastReadingTime =
                                                  getCurrentTimestamp;
                                              safeSetState(() {});

                                              context.pushNamed(
                                                Story11Part5Widget.routeName,
                                                extra: <String, dynamic>{
                                                  '__transition_info__':
                                                      TransitionInfo(
                                                    hasTransition: true,
                                                    transitionType:
                                                        PageTransitionType.fade,
                                                  ),
                                                },
                                              );

                                              FFAppState().addToReadStoriesList(
                                                  FFAppState().currentStoryID);
                                              safeSetState(() {});
                                              FFAppState().addToReadStoryIDs(
                                                  FFAppState()
                                                      .IDStory115
                                                      .toString());
                                              safeSetState(() {});
                                            } else {
                                              await showModalBottomSheet(
                                                isScrollControlled: true,
                                                backgroundColor:
                                                    Colors.transparent,
                                                enableDrag: false,
                                                context: context,
                                                builder: (context) {
                                                  return GestureDetector(
                                                    onTap: () {
                                                      FocusScope.of(context)
                                                          .unfocus();
                                                      FocusManager
                                                          .instance.primaryFocus
                                                          ?.unfocus();
                                                    },
                                                    child: Padding(
                                                      padding: MediaQuery
                                                          .viewInsetsOf(
                                                              context),
                                                      child: Container(
                                                        height: 300.0,
                                                        child:
                                                            DailyLimitSheetWidget(),
                                                      ),
                                                    ),
                                                  );
                                                },
                                              ).then((value) =>
                                                  safeSetState(() {}));
                                            }
                                          }
                                        }
                                      }
                                    },
                                    text: 'اقرَأ المزيــد',
                                    options: FFButtonOptions(
                                      height: 31.47,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          5.0, 0.0, 5.0, 0.0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0.0, 0.0, 0.0, 0.0),
                                      color: Color(0xFFEEA667),
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Tajawal ',
                                            color: Colors.white,
                                            fontSize: 18.0,
                                            letterSpacing: 0.0,
                                          ),
                                      elevation: 0.0,
                                      borderSide: BorderSide(
                                        width: 1.0,
                                      ),
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ].divide(SizedBox(height: 20.0)),
                      ),
                    ),
                  ],
                ),
                Align(
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: Opacity(
                            opacity: 0.8,
                            child: Align(
                              alignment: AlignmentDirectional(0.0, 1.0),
                              child: Container(
                                width: 70.0,
                                height: 70.0,
                                decoration: BoxDecoration(
                                  boxShadow: [
                                    BoxShadow(
                                      blurRadius: 4.0,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      offset: Offset(
                                        0.0,
                                        2.0,
                                      ),
                                    )
                                  ],
                                  gradient: LinearGradient(
                                    colors: [
                                      FlutterFlowTheme.of(context).tertiary,
                                      Color(0xFFEEE443)
                                    ],
                                    stops: [0.0, 1.0],
                                    begin: AlignmentDirectional(0.0, -1.0),
                                    end: AlignmentDirectional(0, 1.0),
                                  ),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: FlutterFlowTheme.of(context).warning,
                                  ),
                                ),
                                alignment: AlignmentDirectional(0.0, 0.0),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    _model.soundPlayer11 ??= AudioPlayer();
                                    if (_model.soundPlayer11!.playing) {
                                      await _model.soundPlayer11!.stop();
                                    }
                                    _model.soundPlayer11!.setVolume(1.0);
                                    _model.soundPlayer11!
                                        .setAsset('assets/audios/tapSound.mp3')
                                        .then((_) =>
                                            _model.soundPlayer11!.play());

                                    context.pushNamed(
                                      FreeLibraryWidget.routeName,
                                      extra: <String, dynamic>{
                                        '__transition_info__': TransitionInfo(
                                          hasTransition: true,
                                          transitionType:
                                              PageTransitionType.fade,
                                        ),
                                      },
                                    );
                                  },
                                  child: Icon(
                                    FFIcons.kkbooks,
                                    color: Color(0xFF695127),
                                    size: 50.0,
                                  ),
                                ).animateOnActionTrigger(
                                  animationsMap[
                                      'iconOnActionTriggerAnimation1']!,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: Opacity(
                            opacity: 0.8,
                            child: Align(
                              alignment: AlignmentDirectional(0.0, 1.0),
                              child: Container(
                                width: 70.0,
                                height: 70.0,
                                decoration: BoxDecoration(
                                  boxShadow: [
                                    BoxShadow(
                                      blurRadius: 4.0,
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      offset: Offset(
                                        0.0,
                                        2.0,
                                      ),
                                    )
                                  ],
                                  gradient: LinearGradient(
                                    colors: [
                                      FlutterFlowTheme.of(context).tertiary,
                                      Color(0xFFEEE443)
                                    ],
                                    stops: [0.0, 1.0],
                                    begin: AlignmentDirectional(0.0, -1.0),
                                    end: AlignmentDirectional(0, 1.0),
                                  ),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: FlutterFlowTheme.of(context).warning,
                                  ),
                                ),
                                alignment: AlignmentDirectional(0.0, 0.0),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    _model.soundPlayer12 ??= AudioPlayer();
                                    if (_model.soundPlayer12!.playing) {
                                      await _model.soundPlayer12!.stop();
                                    }
                                    _model.soundPlayer12!.setVolume(1.0);
                                    _model.soundPlayer12!
                                        .setAsset('assets/audios/tapSound.mp3')
                                        .then((_) =>
                                            _model.soundPlayer12!.play());

                                    context.pushNamed(
                                      PremiumUsersWidget.routeName,
                                      extra: <String, dynamic>{
                                        '__transition_info__': TransitionInfo(
                                          hasTransition: true,
                                          transitionType:
                                              PageTransitionType.fade,
                                        ),
                                      },
                                    );
                                  },
                                  child: Icon(
                                    Icons.shopping_cart_sharp,
                                    color: Color(0xFF695127),
                                    size: 50.0,
                                  ),
                                ).animateOnActionTrigger(
                                  animationsMap[
                                      'iconOnActionTriggerAnimation2']!,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
