import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'free_library_dynamic_widget.dart' show FreeLibraryDynamicWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';

class FreeLibraryDynamicModel
    extends FlutterFlowModel<FreeLibraryDynamicWidget> {
  ///  Local state fields for this page.

  List<StoriesRecord> combinedStories = [];
  void addToCombinedStories(StoriesRecord item) => combinedStories.add(item);
  void removeFromCombinedStories(StoriesRecord item) =>
      combinedStories.remove(item);
  void removeAtIndexFromCombinedStories(int index) =>
      combinedStories.removeAt(index);
  void insertAtIndexInCombinedStories(int index, StoriesRecord item) =>
      combinedStories.insert(index, item);
  void updateCombinedStoriesAtIndex(
          int index, Function(StoriesRecord) updateFn) =>
      combinedStories[index] = updateFn(combinedStories[index]);

  bool isAdLoading = true;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Firestore Query - Query a collection] action in Free_Library_Dynamic widget.
  List<StoriesRecord>? libraryResult;
  // Stores action output result for [Firestore Query - Query a collection] action in Free_Library_Dynamic widget.
  List<StoriesRecord>? filteredStories;
  // Stores action output result for [Custom Action - showRewardedAd] action in Container widget.
  bool? isEarned;
  AudioPlayer? soundPlayer1;
  AudioPlayer? soundPlayer2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
