import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/daily_limit_sheet_widget.dart';
import '/components/rating_bottom_sheet_widget.dart';
import '/components/welcome_back_banner_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_timer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'interface_dynamic_widget.dart' show InterfaceDynamicWidget;
import 'package:stop_watch_timer/stop_watch_timer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InterfaceDynamicModel extends FlutterFlowModel<InterfaceDynamicWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;
  int get tabBarPreviousIndex =>
      tabBarController != null ? tabBarController!.previousIndex : 0;

  // Model for WelcomeBackBanner component.
  late WelcomeBackBannerModel welcomeBackBannerModel;
  // State field(s) for Timer widget.
  final timerInitialTimeMs = 300000;
  int timerMilliseconds = 300000;
  String timerValue = StopWatchTimer.getDisplayTime(
    300000,
    hours: false,
    milliSecond: false,
  );
  FlutterFlowTimerController timerController =
      FlutterFlowTimerController(StopWatchTimer(mode: StopWatchMode.countDown));

  @override
  void initState(BuildContext context) {
    welcomeBackBannerModel =
        createModel(context, () => WelcomeBackBannerModel());
  }

  @override
  void dispose() {
    tabBarController?.dispose();
    welcomeBackBannerModel.dispose();
    timerController.dispose();
  }
}
