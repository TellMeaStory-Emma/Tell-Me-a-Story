import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/daily_limit_sheet_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'long_story_page_widget.dart' show LongStoryPageWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LongStoryPageModel extends FlutterFlowModel<LongStoryPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
