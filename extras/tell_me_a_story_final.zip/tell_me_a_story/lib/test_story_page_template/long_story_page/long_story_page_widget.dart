import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/daily_limit_sheet_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'long_story_page_model.dart';
export 'long_story_page_model.dart';

class LongStoryPageWidget extends StatefulWidget {
  const LongStoryPageWidget({
    super.key,
    required this.currentStory,
  });

  final StoriesRecord? currentStory;

  static String routeName = 'Long_Story_page';
  static String routePath = '/longStoryPage';

  @override
  State<LongStoryPageWidget> createState() => _LongStoryPageWidgetState();
}

class _LongStoryPageWidgetState extends State<LongStoryPageWidget> {
  late LongStoryPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LongStoryPageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Container(
            width: double.infinity,
            height: double.infinity,
            child: Stack(
              children: [
                Opacity(
                  opacity: 0.6,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8.0),
                    child: Image.asset(
                      'assets/images/Whisk_febbf1c5531ad928b9b4f51b9e852649dr.png',
                      width: double.infinity,
                      height: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(
                        child: Align(
                          alignment: AlignmentDirectional(1.0, -1.0),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                5.0, 0.0, 0.0, 0.0),
                            child: Container(
                              width: 40.0,
                              height: 40.0,
                              decoration: BoxDecoration(
                                boxShadow: [
                                  BoxShadow(
                                    blurRadius: 4.0,
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    offset: Offset(
                                      0.0,
                                      2.0,
                                    ),
                                  )
                                ],
                                gradient: LinearGradient(
                                  colors: [
                                    FlutterFlowTheme.of(context).tertiary,
                                    Color(0xFFEEE443)
                                  ],
                                  stops: [0.0, 1.0],
                                  begin: AlignmentDirectional(0.0, -1.0),
                                  end: AlignmentDirectional(0, 1.0),
                                ),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: FlutterFlowTheme.of(context).warning,
                                ),
                              ),
                              alignment: AlignmentDirectional(0.0, 0.0),
                              child: Align(
                                alignment: AlignmentDirectional(0.0, 0.0),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    context.pushNamed(
                                      InterfaceDynamicWidget.routeName,
                                      extra: <String, dynamic>{
                                        '__transition_info__': TransitionInfo(
                                          hasTransition: true,
                                          transitionType:
                                              PageTransitionType.leftToRight,
                                          duration: Duration(milliseconds: 350),
                                        ),
                                      },
                                    );
                                  },
                                  child: Icon(
                                    FFIcons.kkarrowBigLeft,
                                    color: Color(0xFF695127),
                                    size: 35.0,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(0.0, -1.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                        child: Text(
                          'محبو القصص ( +10 سنوات)',
                          textAlign: TextAlign.center,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Tajawal ',
                                    fontSize: 22.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8.0),
                          child: CachedNetworkImage(
                            fadeInDuration: Duration(milliseconds: 500),
                            fadeOutDuration: Duration(milliseconds: 500),
                            imageUrl: widget!.currentStory!.coverImage,
                            width: MediaQuery.sizeOf(context).width * 0.6,
                            height: MediaQuery.sizeOf(context).height * 0.3,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 10.0, 0.0, 10.0),
                        child: Text(
                          valueOrDefault<String>(
                            widget!.currentStory?.longIntroduction,
                            'مقدمة',
                          ),
                          textAlign: TextAlign.center,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Tajawal ',
                                    fontSize: 18.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ),
                      Expanded(
                        child: StreamBuilder<List<PartsRecord>>(
                          stream: queryPartsRecord(
                            parent: widget!.currentStory?.reference,
                            queryBuilder: (partsRecord) =>
                                partsRecord.orderBy('part_number'),
                          ),
                          builder: (context, snapshot) {
                            // Customize what your widget looks like when it's loading.
                            if (!snapshot.hasData) {
                              return Center(
                                child: SizedBox(
                                  width: 50.0,
                                  height: 50.0,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      FlutterFlowTheme.of(context).primary,
                                    ),
                                  ),
                                ),
                              );
                            }
                            List<PartsRecord> listViewPartsRecordList =
                                snapshot.data!;

                            return ListView.builder(
                              padding: EdgeInsets.zero,
                              scrollDirection: Axis.vertical,
                              itemCount: listViewPartsRecordList.length,
                              itemBuilder: (context, listViewIndex) {
                                final listViewPartsRecord =
                                    listViewPartsRecordList[listViewIndex];
                                return Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 25.0),
                                  child: Container(
                                    width: 100.0,
                                    height: 100.0,
                                    decoration: BoxDecoration(
                                      boxShadow: [
                                        BoxShadow(
                                          blurRadius: 4.0,
                                          color: Color(0x33000000),
                                          offset: Offset(
                                            0.0,
                                            2.0,
                                          ),
                                        )
                                      ],
                                      gradient: LinearGradient(
                                        colors: [
                                          Color(0xFFF4AF9A),
                                          Colors.white
                                        ],
                                        stops: [0.0, 1.0],
                                        begin: AlignmentDirectional(0.0, -1.0),
                                        end: AlignmentDirectional(0, 1.0),
                                      ),
                                      border: Border.all(
                                        color: FlutterFlowTheme.of(context)
                                            .accent3,
                                        width: 2.0,
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Expanded(
                                          child: Align(
                                            alignment:
                                                AlignmentDirectional(-1.0, 0.0),
                                            child: Container(
                                              width: 100.0,
                                              height: 200.0,
                                              decoration: BoxDecoration(),
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                                child: CachedNetworkImage(
                                                  fadeInDuration: Duration(
                                                      milliseconds: 500),
                                                  fadeOutDuration: Duration(
                                                      milliseconds: 500),
                                                  imageUrl: listViewPartsRecord
                                                      .partImage,
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  fit: BoxFit.cover,
                                                  alignment:
                                                      Alignment(0.0, 0.0),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, 0.0),
                                          child: Text(
                                            listViewPartsRecord.partTitle,
                                            textAlign: TextAlign.center,
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Tajawal ',
                                                  fontSize: 18.0,
                                                  letterSpacing: 0.0,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              AlignmentDirectional(1.0, 0.0),
                                          child: Builder(
                                            builder: (context) =>
                                                FFButtonWidget(
                                              onPressed: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if ((currentUserDocument
                                                              ?.todayOpenedParts
                                                              ?.toList() ??
                                                          [])
                                                      .contains(
                                                          '${listViewPartsRecord.partNumber.toString()}_${widget!.currentStory?.storyId?.toString()}')) {
                                                    context.pushNamed(
                                                      TestStoryPageWidget
                                                          .routeName,
                                                      queryParameters: {
                                                        'currentStory':
                                                            serializeParam(
                                                          widget!.currentStory,
                                                          ParamType.Document,
                                                        ),
                                                        'selectedPartNumber':
                                                            serializeParam(
                                                          listViewPartsRecord
                                                              .partNumber,
                                                          ParamType.int,
                                                        ),
                                                      }.withoutNulls,
                                                      extra: <String, dynamic>{
                                                        'currentStory': widget!
                                                            .currentStory,
                                                        '__transition_info__':
                                                            TransitionInfo(
                                                          hasTransition: true,
                                                          transitionType:
                                                              PageTransitionType
                                                                  .fade,
                                                        ),
                                                      },
                                                    );
                                                  } else {
                                                    if (valueOrDefault(
                                                            currentUserDocument
                                                                ?.lastReadDate,
                                                            '') !=
                                                        valueOrDefault<String>(
                                                          dateTimeFormat(
                                                            "d/M/y",
                                                            getCurrentTimestamp,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          ),
                                                          '01/01/2000',
                                                        )) {
                                                      firestoreBatch.update(
                                                          currentUserReference!,
                                                          {
                                                            ...createUsersRecordData(
                                                              lastReadDate:
                                                                  dateTimeFormat(
                                                                "d/M/y",
                                                                getCurrentTimestamp,
                                                                locale: FFLocalizations.of(
                                                                        context)
                                                                    .languageCode,
                                                              ),
                                                              dailyReadsCount:
                                                                  1,
                                                            ),
                                                            ...mapToFirestore(
                                                              {
                                                                'daily_reads':
                                                                    FieldValue
                                                                        .delete(),
                                                                'today_opened_stories':
                                                                    FieldValue
                                                                        .delete(),
                                                                'today_opened_parts':
                                                                    FieldValue
                                                                        .delete(),
                                                              },
                                                            ),
                                                          });
                                                      if (listViewPartsRecord
                                                              .partNumber >
                                                          0) {
                                                        firestoreBatch.update(
                                                            currentUserReference!,
                                                            {
                                                              ...mapToFirestore(
                                                                {
                                                                  'today_opened_stories':
                                                                      FieldValue
                                                                          .arrayUnion([
                                                                    listViewPartsRecord
                                                                        .parentReference
                                                                  ]),
                                                                  'today_opened_parts':
                                                                      FieldValue
                                                                          .arrayUnion([
                                                                    ''
                                                                  ]),
                                                                },
                                                              ),
                                                            });

                                                        firestoreBatch.update(
                                                            currentUserReference!,
                                                            {
                                                              ...mapToFirestore(
                                                                {
                                                                  'daily_reads':
                                                                      FieldValue
                                                                          .arrayUnion([
                                                                    listViewPartsRecord
                                                                        .parentReference
                                                                  ]),
                                                                },
                                                              ),
                                                            });

                                                        context.pushNamed(
                                                          TestStoryPageWidget
                                                              .routeName,
                                                          queryParameters: {
                                                            'currentStory':
                                                                serializeParam(
                                                              widget!
                                                                  .currentStory,
                                                              ParamType
                                                                  .Document,
                                                            ),
                                                            'selectedPartNumber':
                                                                serializeParam(
                                                              listViewPartsRecord
                                                                  .partNumber,
                                                              ParamType.int,
                                                            ),
                                                          }.withoutNulls,
                                                          extra: <String,
                                                              dynamic>{
                                                            'currentStory':
                                                                widget!
                                                                    .currentStory,
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );
                                                      }
                                                    } else {
                                                      if (valueOrDefault(
                                                              currentUserDocument
                                                                  ?.dailyReadsCount,
                                                              0) >=
                                                          2) {
                                                        await showDialog(
                                                          context: context,
                                                          builder:
                                                              (dialogContext) {
                                                            return Dialog(
                                                              elevation: 0,
                                                              insetPadding:
                                                                  EdgeInsets
                                                                      .zero,
                                                              backgroundColor:
                                                                  Colors
                                                                      .transparent,
                                                              alignment: AlignmentDirectional(
                                                                      0.0, 0.0)
                                                                  .resolve(
                                                                      Directionality.of(
                                                                          context)),
                                                              child:
                                                                  GestureDetector(
                                                                onTap: () {
                                                                  FocusScope.of(
                                                                          dialogContext)
                                                                      .unfocus();
                                                                  FocusManager
                                                                      .instance
                                                                      .primaryFocus
                                                                      ?.unfocus();
                                                                },
                                                                child:
                                                                    DailyLimitSheetWidget(),
                                                              ),
                                                            );
                                                          },
                                                        );
                                                      } else {
                                                        firestoreBatch.update(
                                                            currentUserReference!,
                                                            {
                                                              ...mapToFirestore(
                                                                {
                                                                  'daily_reads':
                                                                      FieldValue
                                                                          .arrayUnion([
                                                                    listViewPartsRecord
                                                                        .parentReference
                                                                  ]),
                                                                  'daily_reads_count':
                                                                      FieldValue
                                                                          .increment(
                                                                              1),
                                                                  'today_opened_stories':
                                                                      FieldValue
                                                                          .arrayUnion([
                                                                    listViewPartsRecord
                                                                        .parentReference
                                                                  ]),
                                                                  'today_opened_parts':
                                                                      FieldValue
                                                                          .arrayUnion([
                                                                    '${listViewPartsRecord.partNumber.toString()}_${widget!.currentStory?.storyId?.toString()}'
                                                                  ]),
                                                                },
                                                              ),
                                                            });

                                                        context.pushNamed(
                                                          TestStoryPageWidget
                                                              .routeName,
                                                          queryParameters: {
                                                            'currentStory':
                                                                serializeParam(
                                                              widget!
                                                                  .currentStory,
                                                              ParamType
                                                                  .Document,
                                                            ),
                                                            'selectedPartNumber':
                                                                serializeParam(
                                                              listViewPartsRecord
                                                                  .partNumber,
                                                              ParamType.int,
                                                            ),
                                                          }.withoutNulls,
                                                          extra: <String,
                                                              dynamic>{
                                                            'currentStory':
                                                                widget!
                                                                    .currentStory,
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );
                                                      }
                                                    }
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              text: 'اقرَأ المزيد',
                                              options: FFButtonOptions(
                                                height: 40.0,
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        16.0, 0.0, 16.0, 0.0),
                                                iconPadding:
                                                    EdgeInsetsDirectional
                                                        .fromSTEB(
                                                            0.0, 0.0, 0.0, 0.0),
                                                color: Color(0xFFEEA667),
                                                textStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .override(
                                                          fontFamily:
                                                              'Tajawal ',
                                                          color: Colors.white,
                                                          fontSize: 16.0,
                                                          letterSpacing: 0.0,
                                                        ),
                                                elevation: 0.0,
                                                borderSide: BorderSide(
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .accent3,
                                                  width: 2.0,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
