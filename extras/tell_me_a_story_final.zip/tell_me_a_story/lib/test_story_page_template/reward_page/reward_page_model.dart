import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/weekly_points_counter_widget.dart';
import '/components/welcome_back_widget.dart';
import '/components/you_got_reward_msg_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'reward_page_widget.dart' show RewardPageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';

class RewardPageModel extends FlutterFlowModel<RewardPageWidget> {
  ///  State fields for stateful widgets in this page.

  AudioPlayer? soundPlayer1;
  // Model for weeklyPointsCounter component.
  late WeeklyPointsCounterModel weeklyPointsCounterModel;
  AudioPlayer? soundPlayer2;

  @override
  void initState(BuildContext context) {
    weeklyPointsCounterModel =
        createModel(context, () => WeeklyPointsCounterModel());
  }

  @override
  void dispose() {
    weeklyPointsCounterModel.dispose();
  }
}
