import '/backend/backend.dart';
import '/components/story_page_content_widget.dart';
import '/flutter_flow/flutter_flow_ad_banner.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'test_story_page_widget.dart' show TestStoryPageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TestStoryPageModel extends FlutterFlowModel<TestStoryPageWidget> {
  ///  Local state fields for this page.

  bool isPlaying = true;

  ///  State fields for stateful widgets in this page.

  // State field(s) for StoryPageView widget.
  PageController? storyPageViewController;

  int get storyPageViewCurrentIndex => storyPageViewController != null &&
          storyPageViewController!.hasClients &&
          storyPageViewController!.page != null
      ? storyPageViewController!.page!.round()
      : 0;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
