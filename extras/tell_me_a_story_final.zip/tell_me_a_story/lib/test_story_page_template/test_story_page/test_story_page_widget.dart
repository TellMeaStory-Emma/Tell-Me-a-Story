import '/backend/backend.dart';
import '/components/story_page_content_widget.dart';
import '/flutter_flow/flutter_flow_ad_banner.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'test_story_page_model.dart';
export 'test_story_page_model.dart';

class TestStoryPageWidget extends StatefulWidget {
  const TestStoryPageWidget({
    super.key,
    required this.currentStory,
    this.selectedPartNumber,
  });

  final StoriesRecord? currentStory;
  final int? selectedPartNumber;

  static String routeName = 'Test_Story_Page';
  static String routePath = '/testStoryPage';

  @override
  State<TestStoryPageWidget> createState() => _TestStoryPageWidgetState();
}

class _TestStoryPageWidgetState extends State<TestStoryPageWidget>
    with TickerProviderStateMixin {
  late TestStoryPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TestStoryPageModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await actions.keepScreenOn();
    });

    animationsMap.addAll({
      'storyPageContentOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 1.ms),
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 400.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: Container(
          width: double.infinity,
          height: double.infinity,
          child: Stack(
            children: [
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8.0),
                  child: Image.asset(
                    'assets/images/ChatGPT_Image_Jun_1,_2026,_05_39_24_PM.webp',
                    width: double.infinity,
                    height: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: StreamBuilder<List<StoryPagesRecord>>(
                      stream: queryStoryPagesRecord(
                        parent: widget!.currentStory?.reference,
                        queryBuilder: (storyPagesRecord) => storyPagesRecord
                            .where(
                              'part_number',
                              isEqualTo: widget!.selectedPartNumber,
                            )
                            .orderBy('page_number'),
                      ),
                      builder: (context, snapshot) {
                        // Customize what your widget looks like when it's loading.
                        if (!snapshot.hasData) {
                          return Center(
                            child: SizedBox(
                              width: 50.0,
                              height: 50.0,
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  FlutterFlowTheme.of(context).primary,
                                ),
                              ),
                            ),
                          );
                        }
                        List<StoryPagesRecord>
                            storyPageViewStoryPagesRecordList = snapshot.data!;

                        return Container(
                          width: double.infinity,
                          height: 500.0,
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 40.0),
                            child: PageView.builder(
                              controller: _model.storyPageViewController ??=
                                  PageController(
                                      initialPage: max(
                                          0,
                                          min(
                                              0,
                                              storyPageViewStoryPagesRecordList
                                                      .length -
                                                  1))),
                              onPageChanged: (_) => safeSetState(() {}),
                              scrollDirection: Axis.horizontal,
                              itemCount:
                                  storyPageViewStoryPagesRecordList.length,
                              itemBuilder: (context, storyPageViewIndex) {
                                final storyPageViewStoryPagesRecord =
                                    storyPageViewStoryPagesRecordList[
                                        storyPageViewIndex];
                                return StoryPageContentWidget(
                                  key: Key(
                                      'Keyxib_${storyPageViewIndex}_of_${storyPageViewStoryPagesRecordList.length}'),
                                  pageAudio: storyPageViewStoryPagesRecord,
                                  isCurrentPage:
                                      _model.storyPageViewCurrentIndex ==
                                          storyPageViewIndex,
                                  isPlaying: _model.isPlaying,
                                  onTimerEnd: () async {
                                    await _model.storyPageViewController
                                        ?.nextPage(
                                      duration: Duration(milliseconds: 300),
                                      curve: Curves.ease,
                                    );
                                  },
                                  onToggleMedia: () async {},
                                ).animateOnPageLoad(animationsMap[
                                    'storyPageContentOnPageLoadAnimation']!);
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  if (FFAppState().isPremium == false)
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
                      child: FlutterFlowAdBanner(
                        width: MediaQuery.sizeOf(context).width * 1.0,
                        height: 50.0,
                        showsTestAd: false,
                        androidAdUnitID:
                            'ca-app-pub-1352206550586007/2236819122',
                      ),
                    ),
                ],
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: Align(
                        alignment: AlignmentDirectional(1.0, -1.0),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              25.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: 40.0,
                            height: 40.0,
                            decoration: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                  blurRadius: 4.0,
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryText,
                                  offset: Offset(
                                    0.0,
                                    2.0,
                                  ),
                                )
                              ],
                              gradient: LinearGradient(
                                colors: [
                                  FlutterFlowTheme.of(context).tertiary,
                                  Color(0xFFEEE443)
                                ],
                                stops: [0.0, 1.0],
                                begin: AlignmentDirectional(0.0, -1.0),
                                end: AlignmentDirectional(0, 1.0),
                              ),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: FlutterFlowTheme.of(context).warning,
                              ),
                            ),
                            alignment: AlignmentDirectional(0.0, 0.0),
                            child: Align(
                              alignment: AlignmentDirectional(1.0, -1.0),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  _model.isPlaying = false;
                                  safeSetState(() {});
                                  if (dateTimeFormat(
                                        "yMd",
                                        FFAppState().lastReadingTime,
                                        locale: FFLocalizations.of(context)
                                            .languageCode,
                                      ) ==
                                      dateTimeFormat(
                                        "yMd",
                                        getCurrentTimestamp,
                                        locale: FFLocalizations.of(context)
                                            .languageCode,
                                      )) {
                                    FFAppState().dailyStoryCount =
                                        FFAppState().dailyStoryCount + 1;
                                    safeSetState(() {});
                                  } else {
                                    FFAppState().dailyStoryCount =
                                        FFAppState().dailyStoryCount + 1;
                                    FFAppState().lastReadingTime =
                                        getCurrentTimestamp;
                                    safeSetState(() {});
                                  }

                                  context.pushNamed(
                                    InterfaceDynamicWidget.routeName,
                                    extra: <String, dynamic>{
                                      '__transition_info__': TransitionInfo(
                                        hasTransition: true,
                                        transitionType: PageTransitionType.fade,
                                        duration: Duration(milliseconds: 400),
                                      ),
                                    },
                                  );
                                },
                                child: Icon(
                                  FFIcons.kkarrowBigLeft,
                                  color: Color(0xFF695127),
                                  size: 35.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
