// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:async';

class CountdownTimer extends StatefulWidget {
  const CountdownTimer({
    super.key,
    this.width,
    this.height,
    required this.startTime,
    this.durationMinutes = 60,
    this.onTimerEnd,
  });

  final double? width;
  final double? height;
  final DateTime startTime;
  final int durationMinutes;
  final Future<void> Function()? onTimerEnd;

  @override
  State<CountdownTimer> createState() => _CountdownTimerState();
}

class _CountdownTimerState extends State<CountdownTimer> {
  late Timer _timer;
  Duration _remaining = Duration.zero;
  bool _ended = false;

  @override
  void initState() {
    super.initState();
    _update();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _update());
    });
  }

  void _update() {
    final end = widget.startTime.add(
      Duration(minutes: widget.durationMinutes),
    );
    final diff = end.difference(DateTime.now());
    _remaining = diff.isNegative ? Duration.zero : diff;

    if (_remaining == Duration.zero && !_ended) {
      _ended = true;
      FFAppState().isGoldenHour = false;
    }
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final m = _remaining.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = _remaining.inSeconds.remainder(60).toString().padLeft(2, '0');
    return Text(
      '⏱️ $m:$s',
      style: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: Colors.black,
      ),
    );
  }
}

/// MODIFY CODE ONLY ABOVE THIS LINE
