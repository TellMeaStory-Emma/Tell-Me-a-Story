import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';

bool? isGoldenHourActive(DateTime? startTime) {
  if (startTime == null) return false;
  final now = DateTime.now();
  final differenceInSeconds = now.millisecondsSinceEpoch ~/ 1000 -
      startTime!.millisecondsSinceEpoch ~/ 1000;
  return differenceInSeconds < 3600;
}
