import '/components/daily_limit_sheet_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import 'interface_model.dart';
export 'interface_model.dart';

class InterfaceWidget extends StatefulWidget {
  const InterfaceWidget({super.key});

  static String routeName = 'Interface';
  static String routePath = '/interface';

  @override
  State<InterfaceWidget> createState() => _InterfaceWidgetState();
}

class _InterfaceWidgetState extends State<InterfaceWidget>
    with TickerProviderStateMixin {
  late InterfaceModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InterfaceModel());

    _model.tabBarController = TabController(
      vsync: this,
      length: 3,
      initialIndex: 0,
    )..addListener(() => safeSetState(() {}));

    animationsMap.addAll({
      'tabOnActionTriggerAnimation1': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          RotateEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'tabOnActionTriggerAnimation2': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          RotateEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'tabOnActionTriggerAnimation3': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          RotateEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'iconOnActionTriggerAnimation1': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          RotateEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'iconOnActionTriggerAnimation2': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          RotateEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        resizeToAvoidBottomInset: false,
        backgroundColor: Color(0xFFF1F4F8),
        body: SafeArea(
          top: true,
          child: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Container(
              width: MediaQuery.sizeOf(context).width * 1.0,
              height: MediaQuery.sizeOf(context).height * 1.0,
              child: Stack(
                children: [
                  Opacity(
                    opacity: 0.6,
                    child: Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8.0),
                        child: Image.asset(
                          'assets/images/Whisk_febbf1c5531ad928b9b4f51b9e852649dr.png',
                          width: double.infinity,
                          height: double.infinity,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  ),
                  Column(
                    children: [
                      Align(
                        alignment: Alignment(0.0, 0),
                        child: TabBar(
                          labelColor: FlutterFlowTheme.of(context).primaryText,
                          unselectedLabelColor:
                              FlutterFlowTheme.of(context).secondaryText,
                          labelPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 15.0, 0.0, 0.0),
                          labelStyle:
                              FlutterFlowTheme.of(context).titleMedium.override(
                            fontFamily: 'Tajawal ',
                            fontSize: 17.0,
                            letterSpacing: 0.0,
                            shadows: [
                              Shadow(
                                color:
                                    FlutterFlowTheme.of(context).secondaryText,
                                offset: Offset(2.0, 2.0),
                                blurRadius: 2.0,
                              )
                            ],
                          ),
                          unselectedLabelStyle:
                              FlutterFlowTheme.of(context).titleMedium.override(
                                    fontFamily: 'Tajawal ',
                                    fontSize: 17.0,
                                    letterSpacing: 0.0,
                                  ),
                          indicatorColor: Color(0xFF363103),
                          tabs: [
                            Tab(
                              icon: Icon(
                                FFIcons.kkmoodBoy,
                                color: Color(0xFF6B3B24),
                                size: 50.0,
                              ),
                            ).animateOnActionTrigger(
                              animationsMap['tabOnActionTriggerAnimation1']!,
                            ),
                            Tab(
                              icon: Icon(
                                FFIcons.kkmoodKidFilled,
                                color: Color(0xFF6B3B24),
                                size: 50.0,
                              ),
                            ).animateOnActionTrigger(
                              animationsMap['tabOnActionTriggerAnimation2']!,
                            ),
                            Tab(
                              icon: Icon(
                                FFIcons.kkmoodNerd,
                                color: Color(0xFF6B3B24),
                                size: 50.0,
                              ),
                            ).animateOnActionTrigger(
                              animationsMap['tabOnActionTriggerAnimation3']!,
                            ),
                          ],
                          controller: _model.tabBarController,
                          onTap: (i) async {
                            [
                              () async {
                                _model.soundPlayer1 ??= AudioPlayer();
                                if (_model.soundPlayer1!.playing) {
                                  await _model.soundPlayer1!.stop();
                                }
                                _model.soundPlayer1!.setVolume(1.0);
                                _model.soundPlayer1!
                                    .setAsset('assets/audios/tapSound.mp3')
                                    .then((_) => _model.soundPlayer1!.play());

                                if (animationsMap[
                                        'tabOnActionTriggerAnimation1'] !=
                                    null) {
                                  await animationsMap[
                                          'tabOnActionTriggerAnimation1']!
                                      .controller
                                      .forward(from: 0.0);
                                }
                              },
                              () async {
                                _model.soundPlayer10 ??= AudioPlayer();
                                if (_model.soundPlayer10!.playing) {
                                  await _model.soundPlayer10!.stop();
                                }
                                _model.soundPlayer10!.setVolume(1.0);
                                _model.soundPlayer10!
                                    .setAsset('assets/audios/tapSound.mp3')
                                    .then((_) => _model.soundPlayer10!.play());

                                if (animationsMap[
                                        'tabOnActionTriggerAnimation2'] !=
                                    null) {
                                  await animationsMap[
                                          'tabOnActionTriggerAnimation2']!
                                      .controller
                                      .forward(from: 0.0);
                                }
                              },
                              () async {
                                _model.soundPlayer15 ??= AudioPlayer();
                                if (_model.soundPlayer15!.playing) {
                                  await _model.soundPlayer15!.stop();
                                }
                                _model.soundPlayer15!.setVolume(1.0);
                                _model.soundPlayer15!
                                    .setAsset('assets/audios/tapSound.mp3')
                                    .then((_) => _model.soundPlayer15!.play());

                                if (animationsMap[
                                        'tabOnActionTriggerAnimation3'] !=
                                    null) {
                                  await animationsMap[
                                          'tabOnActionTriggerAnimation3']!
                                      .controller
                                      .forward(from: 0.0);
                                }
                              }
                            ][i]();
                          },
                        ),
                      ),
                      Expanded(
                        child: TabBarView(
                          controller: _model.tabBarController,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  30.0, 0.0, 30.0, 0.0),
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Align(
                                      alignment:
                                          AlignmentDirectional(0.0, -1.0),
                                      child: Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 30.0, 0.0, 0.0),
                                        child: Text(
                                          'الأبطال الصغار (2 - 4 سنوات)',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Tajawal ',
                                                color: Color(0xFF0E161C),
                                                fontSize: 18.0,
                                                letterSpacing: 1.0,
                                                fontWeight: FontWeight.bold,
                                              ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Align(
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 40.0, 0.0, 0.0),
                                          child: Card(
                                            clipBehavior:
                                                Clip.antiAliasWithSaveLayer,
                                            color: Color(0xFFFFF1E9),
                                            elevation: 0.0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, -1.0),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        40.0, 0.0, 30.0, 0.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Expanded(
                                                      child: InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        focusColor:
                                                            Colors.transparent,
                                                        hoverColor:
                                                            Colors.transparent,
                                                        highlightColor:
                                                            Colors.transparent,
                                                        onTap: () async {
                                                          _model.soundPlayer2 ??=
                                                              AudioPlayer();
                                                          if (_model
                                                              .soundPlayer2!
                                                              .playing) {
                                                            await _model
                                                                .soundPlayer2!
                                                                .stop();
                                                          }
                                                          _model.soundPlayer2!
                                                              .setVolume(1.0);
                                                          _model.soundPlayer2!
                                                              .setAsset(
                                                                  'assets/audios/tapSound.mp3')
                                                              .then((_) => _model
                                                                  .soundPlayer2!
                                                                  .play());

                                                          FFAppState()
                                                                  .currentStoryID =
                                                              FFAppState()
                                                                  .IDStory9;
                                                          safeSetState(() {});
                                                          if (FFAppState()
                                                              .isPremium) {
                                                            context.pushNamed(
                                                              Story9BabyWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                            safeSetState(() {});
                                                          } else {
                                                            if (FFAppState()
                                                                .ReadStoriesList
                                                                .contains(
                                                                    FFAppState()
                                                                        .currentStoryID)) {
                                                              context.pushNamed(
                                                                Story9BabyWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );
                                                            } else {
                                                              if (dateTimeFormat(
                                                                    "yMd",
                                                                    FFAppState()
                                                                        .lastReadingTime,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ) !=
                                                                  dateTimeFormat(
                                                                    "yMd",
                                                                    getCurrentTimestamp,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  )) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState()
                                                                        .lastReadingTime =
                                                                    getCurrentTimestamp;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story9BabyWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                if (FFAppState()
                                                                        .dailyStoryCount <
                                                                    2) {
                                                                  FFAppState()
                                                                          .dailyStoryCount =
                                                                      FFAppState()
                                                                              .dailyStoryCount +
                                                                          1;
                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});

                                                                  context
                                                                      .pushNamed(
                                                                    Story9BabyWidget
                                                                        .routeName,
                                                                    extra: <String,
                                                                        dynamic>{
                                                                      '__transition_info__':
                                                                          TransitionInfo(
                                                                        hasTransition:
                                                                            true,
                                                                        transitionType:
                                                                            PageTransitionType.fade,
                                                                      ),
                                                                    },
                                                                  );

                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});
                                                                } else {
                                                                  await showModalBottomSheet(
                                                                    isScrollControlled:
                                                                        true,
                                                                    backgroundColor:
                                                                        Colors
                                                                            .transparent,
                                                                    enableDrag:
                                                                        false,
                                                                    context:
                                                                        context,
                                                                    builder:
                                                                        (context) {
                                                                      return GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          FocusScope.of(context)
                                                                              .unfocus();
                                                                          FocusManager
                                                                              .instance
                                                                              .primaryFocus
                                                                              ?.unfocus();
                                                                        },
                                                                        child:
                                                                            Padding(
                                                                          padding:
                                                                              MediaQuery.viewInsetsOf(context),
                                                                          child:
                                                                              Container(
                                                                            height:
                                                                                300.0,
                                                                            child:
                                                                                DailyLimitSheetWidget(),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    },
                                                                  ).then((value) =>
                                                                      safeSetState(
                                                                          () {}));
                                                                }
                                                              }
                                                            }
                                                          }
                                                        },
                                                        child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                          child:
                                                              CachedNetworkImage(
                                                            fadeInDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            fadeOutDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            imageUrl:
                                                                'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1770240521/01_uj4qof.png',
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                0.8,
                                                            height: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .height *
                                                                0.45,
                                                            fit: BoxFit.contain,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      '\nهَشْشَشَشُ! \nمَا كُلُّ هَذِهِ الْأَصْوَاتِ؟ \nكُلُّ شَيْءٍ مُزْعِجٌ عِنْدَمَا يُرِيدُ الطِّفْلُ أَنْ يَنَامَ!! ',
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .bodyLarge
                                                          .override(
                                                            fontFamily:
                                                                'Tajawal ',
                                                            color: Color(
                                                                0xFF080101),
                                                            fontSize: 18.0,
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                    FFButtonWidget(
                                                      onPressed: () async {
                                                        _model.soundPlayer3 ??=
                                                            AudioPlayer();
                                                        if (_model.soundPlayer3!
                                                            .playing) {
                                                          await _model
                                                              .soundPlayer3!
                                                              .stop();
                                                        }
                                                        _model.soundPlayer3!
                                                            .setVolume(1.0);
                                                        _model.soundPlayer3!
                                                            .setAsset(
                                                                'assets/audios/tapSound.mp3')
                                                            .then((_) => _model
                                                                .soundPlayer3!
                                                                .play());

                                                        FFAppState()
                                                                .currentStoryID =
                                                            FFAppState()
                                                                .IDStory9;
                                                        safeSetState(() {});
                                                        if (FFAppState()
                                                            .isPremium) {
                                                          context.pushNamed(
                                                            Story9BabyWidget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                          FFAppState()
                                                              .addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory1
                                                                      .toString());
                                                          safeSetState(() {});
                                                        } else {
                                                          if (FFAppState()
                                                              .ReadStoriesList
                                                              .contains(FFAppState()
                                                                  .currentStoryID)) {
                                                            context.pushNamed(
                                                              Story9BabyWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory1
                                                                        .toString());
                                                            safeSetState(() {});
                                                          } else {
                                                            if (dateTimeFormat(
                                                                  "yMd",
                                                                  FFAppState()
                                                                      .lastReadingTime,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                ) !=
                                                                dateTimeFormat(
                                                                  "yMd",
                                                                  getCurrentTimestamp,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                )) {
                                                              FFAppState()
                                                                      .dailyStoryCount =
                                                                  FFAppState()
                                                                          .dailyStoryCount +
                                                                      1;
                                                              FFAppState()
                                                                      .lastReadingTime =
                                                                  getCurrentTimestamp;
                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});

                                                              context.pushNamed(
                                                                Story9BabyWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );

                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});
                                                              FFAppState().addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory1
                                                                      .toString());
                                                              safeSetState(
                                                                  () {});
                                                            } else {
                                                              if (FFAppState()
                                                                      .dailyStoryCount <
                                                                  2) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story9BabyWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                                FFAppState().addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory1
                                                                        .toString());
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                await showModalBottomSheet(
                                                                  isScrollControlled:
                                                                      true,
                                                                  backgroundColor:
                                                                      Colors
                                                                          .transparent,
                                                                  enableDrag:
                                                                      false,
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (context) {
                                                                    return GestureDetector(
                                                                      onTap:
                                                                          () {
                                                                        FocusScope.of(context)
                                                                            .unfocus();
                                                                        FocusManager
                                                                            .instance
                                                                            .primaryFocus
                                                                            ?.unfocus();
                                                                      },
                                                                      child:
                                                                          Padding(
                                                                        padding:
                                                                            MediaQuery.viewInsetsOf(context),
                                                                        child:
                                                                            Container(
                                                                          height:
                                                                              300.0,
                                                                          child:
                                                                              DailyLimitSheetWidget(),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  },
                                                                ).then((value) =>
                                                                    safeSetState(
                                                                        () {}));
                                                              }
                                                            }
                                                          }
                                                        }
                                                      },
                                                      text: 'اقرَأ المزيــد',
                                                      options: FFButtonOptions(
                                                        height: 40.0,
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    16.0,
                                                                    0.0,
                                                                    16.0,
                                                                    0.0),
                                                        iconPadding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        color: FFAppState()
                                                                .readStoryIDs
                                                                .contains(
                                                                    FFAppState()
                                                                        .IDStory9
                                                                        .toString())
                                                            ? FlutterFlowTheme
                                                                    .of(context)
                                                                .secondaryText
                                                            : Color(0xFFEEA667),
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .override(
                                                                  fontFamily:
                                                                      'Tajawal ',
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      18.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                        elevation: 0.0,
                                                        borderSide: BorderSide(
                                                          width: 1.0,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                      ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Align(
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 40.0, 0.0, 0.0),
                                          child: Card(
                                            clipBehavior:
                                                Clip.antiAliasWithSaveLayer,
                                            color: Color(0xFFFFF1E9),
                                            elevation: 0.0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        40.0, 0.0, 30.0, 0.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Expanded(
                                                      child: InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        focusColor:
                                                            Colors.transparent,
                                                        hoverColor:
                                                            Colors.transparent,
                                                        highlightColor:
                                                            Colors.transparent,
                                                        onTap: () async {
                                                          _model.soundPlayer4 ??=
                                                              AudioPlayer();
                                                          if (_model
                                                              .soundPlayer4!
                                                              .playing) {
                                                            await _model
                                                                .soundPlayer4!
                                                                .stop();
                                                          }
                                                          _model.soundPlayer4!
                                                              .setVolume(1.0);
                                                          _model.soundPlayer4!
                                                              .setAsset(
                                                                  'assets/audios/tapSound.mp3')
                                                              .then((_) => _model
                                                                  .soundPlayer4!
                                                                  .play());

                                                          FFAppState()
                                                                  .currentStoryID =
                                                              FFAppState()
                                                                  .IDStory1;
                                                          safeSetState(() {});
                                                          if (FFAppState()
                                                              .isPremium) {
                                                            context.pushNamed(
                                                              Story1JoodTheDuckWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                            safeSetState(() {});
                                                            FFAppState()
                                                                .addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory1
                                                                        .toString());
                                                            safeSetState(() {});
                                                          } else {
                                                            if (FFAppState()
                                                                .ReadStoriesList
                                                                .contains(
                                                                    FFAppState()
                                                                        .currentStoryID)) {
                                                              context.pushNamed(
                                                                Story1JoodTheDuckWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );

                                                              FFAppState().addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory1
                                                                      .toString());
                                                              safeSetState(
                                                                  () {});
                                                            } else {
                                                              if (dateTimeFormat(
                                                                    "yMd",
                                                                    FFAppState()
                                                                        .lastReadingTime,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ) !=
                                                                  dateTimeFormat(
                                                                    "yMd",
                                                                    getCurrentTimestamp,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  )) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState()
                                                                        .lastReadingTime =
                                                                    getCurrentTimestamp;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story1JoodTheDuckWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                                FFAppState().addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory1
                                                                        .toString());
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                if (FFAppState()
                                                                        .dailyStoryCount <
                                                                    2) {
                                                                  FFAppState()
                                                                          .dailyStoryCount =
                                                                      FFAppState()
                                                                              .dailyStoryCount +
                                                                          1;
                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});

                                                                  context
                                                                      .pushNamed(
                                                                    Story1JoodTheDuckWidget
                                                                        .routeName,
                                                                    extra: <String,
                                                                        dynamic>{
                                                                      '__transition_info__':
                                                                          TransitionInfo(
                                                                        hasTransition:
                                                                            true,
                                                                        transitionType:
                                                                            PageTransitionType.fade,
                                                                      ),
                                                                    },
                                                                  );

                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});
                                                                  FFAppState().addToReadStoryIDs(
                                                                      FFAppState()
                                                                          .IDStory1
                                                                          .toString());
                                                                  safeSetState(
                                                                      () {});
                                                                } else {
                                                                  await showModalBottomSheet(
                                                                    isScrollControlled:
                                                                        true,
                                                                    backgroundColor:
                                                                        Colors
                                                                            .transparent,
                                                                    enableDrag:
                                                                        false,
                                                                    context:
                                                                        context,
                                                                    builder:
                                                                        (context) {
                                                                      return GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          FocusScope.of(context)
                                                                              .unfocus();
                                                                          FocusManager
                                                                              .instance
                                                                              .primaryFocus
                                                                              ?.unfocus();
                                                                        },
                                                                        child:
                                                                            Padding(
                                                                          padding:
                                                                              MediaQuery.viewInsetsOf(context),
                                                                          child:
                                                                              Container(
                                                                            height:
                                                                                300.0,
                                                                            child:
                                                                                DailyLimitSheetWidget(),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    },
                                                                  ).then((value) =>
                                                                      safeSetState(
                                                                          () {}));
                                                                }
                                                              }
                                                            }
                                                          }
                                                        },
                                                        child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                          child:
                                                              CachedNetworkImage(
                                                            fadeInDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            fadeOutDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            imageUrl:
                                                                'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1768406890/01_dcsxsi.png',
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                0.8,
                                                            height: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .height *
                                                                0.45,
                                                            fit: BoxFit.contain,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      '\n الْبَطَّةُ (جُودْ) تَشُمُّ رَائِحَةً زَكِيَّةً \nلَكِنْ، مِنْ أَيْنَ تَأْتِي الرَّائِحَةُ؟',
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .bodyLarge
                                                          .override(
                                                            fontFamily:
                                                                'Tajawal ',
                                                            color: Color(
                                                                0xFF080101),
                                                            fontSize: 18.0,
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                    FFButtonWidget(
                                                      onPressed: () async {
                                                        _model.soundPlayer5 ??=
                                                            AudioPlayer();
                                                        if (_model.soundPlayer5!
                                                            .playing) {
                                                          await _model
                                                              .soundPlayer5!
                                                              .stop();
                                                        }
                                                        _model.soundPlayer5!
                                                            .setVolume(1.0);
                                                        _model.soundPlayer5!
                                                            .setAsset(
                                                                'assets/audios/tapSound.mp3')
                                                            .then((_) => _model
                                                                .soundPlayer5!
                                                                .play());

                                                        FFAppState()
                                                                .currentStoryID =
                                                            FFAppState()
                                                                .IDStory1;
                                                        safeSetState(() {});
                                                        if (FFAppState()
                                                            .isPremium) {
                                                          context.pushNamed(
                                                            Story1JoodTheDuckWidget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                          FFAppState()
                                                              .addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory1
                                                                      .toString());
                                                          safeSetState(() {});
                                                        } else {
                                                          if (FFAppState()
                                                              .ReadStoriesList
                                                              .contains(FFAppState()
                                                                  .currentStoryID)) {
                                                            context.pushNamed(
                                                              Story1JoodTheDuckWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory1
                                                                        .toString());
                                                            safeSetState(() {});
                                                          } else {
                                                            if (dateTimeFormat(
                                                                  "yMd",
                                                                  FFAppState()
                                                                      .lastReadingTime,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                ) !=
                                                                dateTimeFormat(
                                                                  "yMd",
                                                                  getCurrentTimestamp,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                )) {
                                                              FFAppState()
                                                                      .dailyStoryCount =
                                                                  FFAppState()
                                                                          .dailyStoryCount +
                                                                      1;
                                                              FFAppState()
                                                                      .lastReadingTime =
                                                                  getCurrentTimestamp;
                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});

                                                              context.pushNamed(
                                                                Story1JoodTheDuckWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );

                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});
                                                              FFAppState().addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory1
                                                                      .toString());
                                                              safeSetState(
                                                                  () {});
                                                            } else {
                                                              if (FFAppState()
                                                                      .dailyStoryCount <
                                                                  2) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story1JoodTheDuckWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                                FFAppState().addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory1
                                                                        .toString());
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                await showModalBottomSheet(
                                                                  isScrollControlled:
                                                                      true,
                                                                  backgroundColor:
                                                                      Colors
                                                                          .transparent,
                                                                  enableDrag:
                                                                      false,
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (context) {
                                                                    return GestureDetector(
                                                                      onTap:
                                                                          () {
                                                                        FocusScope.of(context)
                                                                            .unfocus();
                                                                        FocusManager
                                                                            .instance
                                                                            .primaryFocus
                                                                            ?.unfocus();
                                                                      },
                                                                      child:
                                                                          Padding(
                                                                        padding:
                                                                            MediaQuery.viewInsetsOf(context),
                                                                        child:
                                                                            Container(
                                                                          height:
                                                                              300.0,
                                                                          child:
                                                                              DailyLimitSheetWidget(),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  },
                                                                ).then((value) =>
                                                                    safeSetState(
                                                                        () {}));
                                                              }
                                                            }
                                                          }
                                                        }
                                                      },
                                                      text: 'اقرَأ المزيــد',
                                                      options: FFButtonOptions(
                                                        height: 40.0,
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    16.0,
                                                                    0.0,
                                                                    16.0,
                                                                    0.0),
                                                        iconPadding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        color:
                                                            Color(0xFFEEA667),
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .override(
                                                                  fontFamily:
                                                                      'Tajawal ',
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      18.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                        elevation: 0.0,
                                                        borderSide: BorderSide(
                                                          width: 1.0,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                      ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Align(
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 40.0, 0.0, 0.0),
                                          child: Card(
                                            clipBehavior:
                                                Clip.antiAliasWithSaveLayer,
                                            color: Color(0xFFFFF1E9),
                                            elevation: 0.0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, -1.0),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        40.0, 0.0, 30.0, 0.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Expanded(
                                                      child: InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        focusColor:
                                                            Colors.transparent,
                                                        hoverColor:
                                                            Colors.transparent,
                                                        highlightColor:
                                                            Colors.transparent,
                                                        onTap: () async {
                                                          _model.soundPlayer6 ??=
                                                              AudioPlayer();
                                                          if (_model
                                                              .soundPlayer6!
                                                              .playing) {
                                                            await _model
                                                                .soundPlayer6!
                                                                .stop();
                                                          }
                                                          _model.soundPlayer6!
                                                              .setVolume(1.0);
                                                          _model.soundPlayer6!
                                                              .setAsset(
                                                                  'assets/audios/tapSound.mp3')
                                                              .then((_) => _model
                                                                  .soundPlayer6!
                                                                  .play());

                                                          FFAppState()
                                                                  .currentStoryID =
                                                              FFAppState()
                                                                  .IDStory3;
                                                          safeSetState(() {});
                                                          if (FFAppState()
                                                              .isPremium) {
                                                            context.pushNamed(
                                                              Story3LostTurtleWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                            safeSetState(() {});
                                                          } else {
                                                            if (FFAppState()
                                                                .ReadStoriesList
                                                                .contains(
                                                                    FFAppState()
                                                                        .currentStoryID)) {
                                                              context.pushNamed(
                                                                Story3LostTurtleWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );
                                                            } else {
                                                              if (dateTimeFormat(
                                                                    "yMd",
                                                                    FFAppState()
                                                                        .lastReadingTime,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ) !=
                                                                  dateTimeFormat(
                                                                    "yMd",
                                                                    getCurrentTimestamp,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  )) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState()
                                                                        .lastReadingTime =
                                                                    getCurrentTimestamp;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story3LostTurtleWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                if (FFAppState()
                                                                        .dailyStoryCount <
                                                                    2) {
                                                                  FFAppState()
                                                                          .dailyStoryCount =
                                                                      FFAppState()
                                                                              .dailyStoryCount +
                                                                          1;
                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});

                                                                  context
                                                                      .pushNamed(
                                                                    Story3LostTurtleWidget
                                                                        .routeName,
                                                                    extra: <String,
                                                                        dynamic>{
                                                                      '__transition_info__':
                                                                          TransitionInfo(
                                                                        hasTransition:
                                                                            true,
                                                                        transitionType:
                                                                            PageTransitionType.fade,
                                                                      ),
                                                                    },
                                                                  );

                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});
                                                                } else {
                                                                  await showModalBottomSheet(
                                                                    isScrollControlled:
                                                                        true,
                                                                    backgroundColor:
                                                                        Colors
                                                                            .transparent,
                                                                    enableDrag:
                                                                        false,
                                                                    context:
                                                                        context,
                                                                    builder:
                                                                        (context) {
                                                                      return GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          FocusScope.of(context)
                                                                              .unfocus();
                                                                          FocusManager
                                                                              .instance
                                                                              .primaryFocus
                                                                              ?.unfocus();
                                                                        },
                                                                        child:
                                                                            Padding(
                                                                          padding:
                                                                              MediaQuery.viewInsetsOf(context),
                                                                          child:
                                                                              Container(
                                                                            height:
                                                                                300.0,
                                                                            child:
                                                                                DailyLimitSheetWidget(),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    },
                                                                  ).then((value) =>
                                                                      safeSetState(
                                                                          () {}));
                                                                }
                                                              }
                                                            }
                                                          }
                                                        },
                                                        child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                          child:
                                                              CachedNetworkImage(
                                                            fadeInDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            fadeOutDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            imageUrl:
                                                                'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1769008709/01_mywkpy.png',
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                0.8,
                                                            height: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .height *
                                                                0.45,
                                                            fit: BoxFit.contain,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Text(
                                                        'لَا تَسْتَطِيعُ السُّلَحْفَاةُ الصَّغِيرَةُ أَنْ تَجِدَ مَنْزِلَهَا! \nهَلْ يُمْكِنُ أَنْ يُسَاعِدَهَا أَصْدِقَاؤُهَا فِي إِيجَادِهِ؟',
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: FlutterFlowTheme
                                                                .of(context)
                                                            .bodyLarge
                                                            .override(
                                                              fontFamily:
                                                                  'Tajawal ',
                                                              color: Color(
                                                                  0xFF080101),
                                                              fontSize: 18.0,
                                                              letterSpacing:
                                                                  0.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                            ),
                                                      ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                    FFButtonWidget(
                                                      onPressed: () async {
                                                        _model.soundPlayer7 ??=
                                                            AudioPlayer();
                                                        if (_model.soundPlayer7!
                                                            .playing) {
                                                          await _model
                                                              .soundPlayer7!
                                                              .stop();
                                                        }
                                                        _model.soundPlayer7!
                                                            .setVolume(1.0);
                                                        _model.soundPlayer7!
                                                            .setAsset(
                                                                'assets/audios/tapSound.mp3')
                                                            .then((_) => _model
                                                                .soundPlayer7!
                                                                .play());

                                                        FFAppState()
                                                                .currentStoryID =
                                                            FFAppState()
                                                                .IDStory3;
                                                        safeSetState(() {});
                                                        if (FFAppState()
                                                            .isPremium) {
                                                          context.pushNamed(
                                                            Story3LostTurtleWidget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                          FFAppState()
                                                              .addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory3
                                                                      .toString());
                                                          safeSetState(() {});
                                                        } else {
                                                          if (FFAppState()
                                                              .ReadStoriesList
                                                              .contains(FFAppState()
                                                                  .currentStoryID)) {
                                                            context.pushNamed(
                                                              Story3LostTurtleWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory3
                                                                        .toString());
                                                            safeSetState(() {});
                                                          } else {
                                                            if (dateTimeFormat(
                                                                  "yMd",
                                                                  FFAppState()
                                                                      .lastReadingTime,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                ) !=
                                                                dateTimeFormat(
                                                                  "yMd",
                                                                  getCurrentTimestamp,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                )) {
                                                              FFAppState()
                                                                      .dailyStoryCount =
                                                                  FFAppState()
                                                                          .dailyStoryCount +
                                                                      1;
                                                              FFAppState()
                                                                      .lastReadingTime =
                                                                  getCurrentTimestamp;
                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});

                                                              context.pushNamed(
                                                                Story3LostTurtleWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );

                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});
                                                              FFAppState().addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory3
                                                                      .toString());
                                                              safeSetState(
                                                                  () {});
                                                            } else {
                                                              if (FFAppState()
                                                                      .dailyStoryCount <
                                                                  2) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story3LostTurtleWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                                FFAppState().addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory3
                                                                        .toString());
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                await showModalBottomSheet(
                                                                  isScrollControlled:
                                                                      true,
                                                                  backgroundColor:
                                                                      Colors
                                                                          .transparent,
                                                                  enableDrag:
                                                                      false,
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (context) {
                                                                    return GestureDetector(
                                                                      onTap:
                                                                          () {
                                                                        FocusScope.of(context)
                                                                            .unfocus();
                                                                        FocusManager
                                                                            .instance
                                                                            .primaryFocus
                                                                            ?.unfocus();
                                                                      },
                                                                      child:
                                                                          Padding(
                                                                        padding:
                                                                            MediaQuery.viewInsetsOf(context),
                                                                        child:
                                                                            Container(
                                                                          height:
                                                                              300.0,
                                                                          child:
                                                                              DailyLimitSheetWidget(),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  },
                                                                ).then((value) =>
                                                                    safeSetState(
                                                                        () {}));
                                                              }
                                                            }
                                                          }
                                                        }
                                                      },
                                                      text: 'اقرَأ المزيــد',
                                                      options: FFButtonOptions(
                                                        height: 40.0,
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    16.0,
                                                                    0.0,
                                                                    16.0,
                                                                    0.0),
                                                        iconPadding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        color:
                                                            Color(0xFFEEA667),
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .override(
                                                                  fontFamily:
                                                                      'Tajawal ',
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      18.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                        elevation: 0.0,
                                                        borderSide: BorderSide(
                                                          width: 1.0,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                      ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Align(
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 40.0, 0.0, 100.0),
                                          child: Card(
                                            clipBehavior:
                                                Clip.antiAliasWithSaveLayer,
                                            color: Color(0xFFFFF1E9),
                                            elevation: 0.0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, -1.0),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        40.0, 0.0, 30.0, 0.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Expanded(
                                                      child: InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        focusColor:
                                                            Colors.transparent,
                                                        hoverColor:
                                                            Colors.transparent,
                                                        highlightColor:
                                                            Colors.transparent,
                                                        onTap: () async {
                                                          _model.soundPlayer8 ??=
                                                              AudioPlayer();
                                                          if (_model
                                                              .soundPlayer8!
                                                              .playing) {
                                                            await _model
                                                                .soundPlayer8!
                                                                .stop();
                                                          }
                                                          _model.soundPlayer8!
                                                              .setVolume(1.0);
                                                          _model.soundPlayer8!
                                                              .setAsset(
                                                                  'assets/audios/tapSound.mp3')
                                                              .then((_) => _model
                                                                  .soundPlayer8!
                                                                  .play());

                                                          FFAppState()
                                                                  .currentStoryID =
                                                              FFAppState()
                                                                  .IDStory4;
                                                          safeSetState(() {});
                                                          if (FFAppState()
                                                              .isPremium) {
                                                            context.pushNamed(
                                                              Story4LittleChicksWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                            safeSetState(() {});
                                                          } else {
                                                            if (FFAppState()
                                                                .ReadStoriesList
                                                                .contains(
                                                                    FFAppState()
                                                                        .currentStoryID)) {
                                                              context.pushNamed(
                                                                Story4LittleChicksWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );
                                                            } else {
                                                              if (dateTimeFormat(
                                                                    "yMd",
                                                                    FFAppState()
                                                                        .lastReadingTime,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ) !=
                                                                  dateTimeFormat(
                                                                    "yMd",
                                                                    getCurrentTimestamp,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  )) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState()
                                                                        .lastReadingTime =
                                                                    getCurrentTimestamp;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story4LittleChicksWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                if (FFAppState()
                                                                        .dailyStoryCount <
                                                                    2) {
                                                                  FFAppState()
                                                                          .dailyStoryCount =
                                                                      FFAppState()
                                                                              .dailyStoryCount +
                                                                          1;
                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});

                                                                  context
                                                                      .pushNamed(
                                                                    Story4LittleChicksWidget
                                                                        .routeName,
                                                                    extra: <String,
                                                                        dynamic>{
                                                                      '__transition_info__':
                                                                          TransitionInfo(
                                                                        hasTransition:
                                                                            true,
                                                                        transitionType:
                                                                            PageTransitionType.fade,
                                                                      ),
                                                                    },
                                                                  );

                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});
                                                                } else {
                                                                  await showModalBottomSheet(
                                                                    isScrollControlled:
                                                                        true,
                                                                    backgroundColor:
                                                                        Colors
                                                                            .transparent,
                                                                    enableDrag:
                                                                        false,
                                                                    context:
                                                                        context,
                                                                    builder:
                                                                        (context) {
                                                                      return GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          FocusScope.of(context)
                                                                              .unfocus();
                                                                          FocusManager
                                                                              .instance
                                                                              .primaryFocus
                                                                              ?.unfocus();
                                                                        },
                                                                        child:
                                                                            Padding(
                                                                          padding:
                                                                              MediaQuery.viewInsetsOf(context),
                                                                          child:
                                                                              Container(
                                                                            height:
                                                                                300.0,
                                                                            child:
                                                                                DailyLimitSheetWidget(),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    },
                                                                  ).then((value) =>
                                                                      safeSetState(
                                                                          () {}));
                                                                }
                                                              }
                                                            }
                                                          }
                                                        },
                                                        child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                          child:
                                                              CachedNetworkImage(
                                                            fadeInDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            fadeOutDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            imageUrl:
                                                                'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1769106815/01_armyez.png',
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                0.8,
                                                            height: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .height *
                                                                0.45,
                                                            fit: BoxFit.contain,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Text(
                                                        'الدِّجَّاجَةُ الْأُمِّ تَنْتَظِرُ صِيصَانَهَا حَتَّى تَفْقُسَ.. \nهَلْ سَيُفَوِّتُهَا الِاحْتِفَالُ مَعَ أَصْدِقَائِهَا فِي الْمَزْرَعَةِ؟',
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: FlutterFlowTheme
                                                                .of(context)
                                                            .bodyLarge
                                                            .override(
                                                              fontFamily:
                                                                  'Tajawal ',
                                                              color: Color(
                                                                  0xFF080101),
                                                              fontSize: 18.0,
                                                              letterSpacing:
                                                                  0.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                            ),
                                                      ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                    FFButtonWidget(
                                                      onPressed: () async {
                                                        _model.soundPlayer9 ??=
                                                            AudioPlayer();
                                                        if (_model.soundPlayer9!
                                                            .playing) {
                                                          await _model
                                                              .soundPlayer9!
                                                              .stop();
                                                        }
                                                        _model.soundPlayer9!
                                                            .setVolume(1.0);
                                                        _model.soundPlayer9!
                                                            .setAsset(
                                                                'assets/audios/tapSound.mp3')
                                                            .then((_) => _model
                                                                .soundPlayer9!
                                                                .play());

                                                        FFAppState()
                                                                .currentStoryID =
                                                            FFAppState()
                                                                .IDStory4;
                                                        safeSetState(() {});
                                                        if (FFAppState()
                                                            .isPremium) {
                                                          context.pushNamed(
                                                            Story4LittleChicksWidget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                          FFAppState()
                                                              .addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory4
                                                                      .toString());
                                                          safeSetState(() {});
                                                        } else {
                                                          if (FFAppState()
                                                              .ReadStoriesList
                                                              .contains(FFAppState()
                                                                  .currentStoryID)) {
                                                            context.pushNamed(
                                                              Story4LittleChicksWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory4
                                                                        .toString());
                                                            safeSetState(() {});
                                                          } else {
                                                            if (dateTimeFormat(
                                                                  "yMd",
                                                                  FFAppState()
                                                                      .lastReadingTime,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                ) !=
                                                                dateTimeFormat(
                                                                  "yMd",
                                                                  getCurrentTimestamp,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                )) {
                                                              FFAppState()
                                                                      .dailyStoryCount =
                                                                  FFAppState()
                                                                          .dailyStoryCount +
                                                                      1;
                                                              FFAppState()
                                                                      .lastReadingTime =
                                                                  getCurrentTimestamp;
                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});

                                                              context.pushNamed(
                                                                Story4LittleChicksWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );

                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});
                                                              FFAppState().addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory4
                                                                      .toString());
                                                              safeSetState(
                                                                  () {});
                                                            } else {
                                                              if (FFAppState()
                                                                      .dailyStoryCount <
                                                                  2) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story4LittleChicksWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                                FFAppState().addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory4
                                                                        .toString());
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                await showModalBottomSheet(
                                                                  isScrollControlled:
                                                                      true,
                                                                  backgroundColor:
                                                                      Colors
                                                                          .transparent,
                                                                  enableDrag:
                                                                      false,
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (context) {
                                                                    return GestureDetector(
                                                                      onTap:
                                                                          () {
                                                                        FocusScope.of(context)
                                                                            .unfocus();
                                                                        FocusManager
                                                                            .instance
                                                                            .primaryFocus
                                                                            ?.unfocus();
                                                                      },
                                                                      child:
                                                                          Padding(
                                                                        padding:
                                                                            MediaQuery.viewInsetsOf(context),
                                                                        child:
                                                                            Container(
                                                                          height:
                                                                              300.0,
                                                                          child:
                                                                              DailyLimitSheetWidget(),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  },
                                                                ).then((value) =>
                                                                    safeSetState(
                                                                        () {}));
                                                              }
                                                            }
                                                          }
                                                        }
                                                      },
                                                      text: 'اقرَأ المزيــد',
                                                      options: FFButtonOptions(
                                                        height: 40.0,
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    16.0,
                                                                    0.0,
                                                                    16.0,
                                                                    0.0),
                                                        iconPadding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        color:
                                                            Color(0xFFEEA667),
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .override(
                                                                  fontFamily:
                                                                      'Tajawal ',
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      18.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                        elevation: 0.0,
                                                        borderSide: BorderSide(
                                                          width: 1.0,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                      ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  30.0, 0.0, 30.0, 0.0),
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Align(
                                      alignment:
                                          AlignmentDirectional(0.0, -1.0),
                                      child: Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 10.0, 0.0, 10.0),
                                        child: Text(
                                          'المستكشفون الشجعان (5 - 9 سنوات)',
                                          textAlign: TextAlign.center,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Tajawal ',
                                                color: Color(0xFF0E161C),
                                                fontSize: 18.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.bold,
                                              ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Align(
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 40.0, 0.0, 0.0),
                                          child: Card(
                                            clipBehavior:
                                                Clip.antiAliasWithSaveLayer,
                                            color: Color(0xFFFFF1E9),
                                            elevation: 0.0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, -1.0),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        10.0, 0.0, 10.0, 0.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Expanded(
                                                      child: InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        focusColor:
                                                            Colors.transparent,
                                                        hoverColor:
                                                            Colors.transparent,
                                                        highlightColor:
                                                            Colors.transparent,
                                                        onTap: () async {
                                                          _model.soundPlayer11 ??=
                                                              AudioPlayer();
                                                          if (_model
                                                              .soundPlayer11!
                                                              .playing) {
                                                            await _model
                                                                .soundPlayer11!
                                                                .stop();
                                                          }
                                                          _model.soundPlayer11!
                                                              .setVolume(1.0);
                                                          _model.soundPlayer11!
                                                              .setAsset(
                                                                  'assets/audios/tapSound.mp3')
                                                              .then((_) => _model
                                                                  .soundPlayer11!
                                                                  .play());

                                                          FFAppState()
                                                                  .currentStoryID =
                                                              FFAppState()
                                                                  .IDStory5;
                                                          safeSetState(() {});
                                                          if (FFAppState()
                                                              .isPremium) {
                                                            context.pushNamed(
                                                              Story5FaridaWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                            safeSetState(() {});
                                                          } else {
                                                            if (FFAppState()
                                                                .ReadStoriesList
                                                                .contains(
                                                                    FFAppState()
                                                                        .currentStoryID)) {
                                                              context.pushNamed(
                                                                Story5FaridaWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );
                                                            } else {
                                                              if (dateTimeFormat(
                                                                    "yMd",
                                                                    FFAppState()
                                                                        .lastReadingTime,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ) !=
                                                                  dateTimeFormat(
                                                                    "yMd",
                                                                    getCurrentTimestamp,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  )) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState()
                                                                        .lastReadingTime =
                                                                    getCurrentTimestamp;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story5FaridaWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                if (FFAppState()
                                                                        .dailyStoryCount <
                                                                    2) {
                                                                  FFAppState()
                                                                          .dailyStoryCount =
                                                                      FFAppState()
                                                                              .dailyStoryCount +
                                                                          1;
                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});

                                                                  context
                                                                      .pushNamed(
                                                                    Story5FaridaWidget
                                                                        .routeName,
                                                                    extra: <String,
                                                                        dynamic>{
                                                                      '__transition_info__':
                                                                          TransitionInfo(
                                                                        hasTransition:
                                                                            true,
                                                                        transitionType:
                                                                            PageTransitionType.fade,
                                                                      ),
                                                                    },
                                                                  );

                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});
                                                                } else {
                                                                  await showModalBottomSheet(
                                                                    isScrollControlled:
                                                                        true,
                                                                    backgroundColor:
                                                                        Colors
                                                                            .transparent,
                                                                    enableDrag:
                                                                        false,
                                                                    context:
                                                                        context,
                                                                    builder:
                                                                        (context) {
                                                                      return GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          FocusScope.of(context)
                                                                              .unfocus();
                                                                          FocusManager
                                                                              .instance
                                                                              .primaryFocus
                                                                              ?.unfocus();
                                                                        },
                                                                        child:
                                                                            Padding(
                                                                          padding:
                                                                              MediaQuery.viewInsetsOf(context),
                                                                          child:
                                                                              Container(
                                                                            height:
                                                                                300.0,
                                                                            child:
                                                                                DailyLimitSheetWidget(),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    },
                                                                  ).then((value) =>
                                                                      safeSetState(
                                                                          () {}));
                                                                }
                                                              }
                                                            }
                                                          }
                                                        },
                                                        child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                          child:
                                                              CachedNetworkImage(
                                                            fadeInDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            fadeOutDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            imageUrl:
                                                                'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1769360171/01_rdeivu.png',
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                0.8,
                                                            height: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .height *
                                                                0.45,
                                                            fit: BoxFit.contain,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Text(
                                                        'الدِّجَاجَةُ فَرِيدَةُ حَزِينَةٌ لِلْغَايَةِ؛ لَمْ يَعُدْ بِاسْتِطَاعَتِهَا وَضْعُ الْبَيْضِ..\n لَكِنَّهَا لَيْسَتْ وَحِيدَةً؛ فَأَصْدِقَاؤُهَا هُنَاكَ لِلْمُسَاعَدَةِ!. \n\n\nعَنْ قِصَّةِ (دِيفِيدْ مِيلْلَرْ)- بِتَصَرُّفٍ',
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: FlutterFlowTheme
                                                                .of(context)
                                                            .bodyLarge
                                                            .override(
                                                              fontFamily:
                                                                  'Tajawal ',
                                                              color: Color(
                                                                  0xFF080101),
                                                              fontSize: 18.0,
                                                              letterSpacing:
                                                                  0.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                            ),
                                                      ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                    FFButtonWidget(
                                                      onPressed: () async {
                                                        _model.soundPlayer12 ??=
                                                            AudioPlayer();
                                                        if (_model
                                                            .soundPlayer12!
                                                            .playing) {
                                                          await _model
                                                              .soundPlayer12!
                                                              .stop();
                                                        }
                                                        _model.soundPlayer12!
                                                            .setVolume(1.0);
                                                        _model.soundPlayer12!
                                                            .setAsset(
                                                                'assets/audios/tapSound.mp3')
                                                            .then((_) => _model
                                                                .soundPlayer12!
                                                                .play());

                                                        FFAppState()
                                                                .currentStoryID =
                                                            FFAppState()
                                                                .IDStory5;
                                                        safeSetState(() {});
                                                        if (FFAppState()
                                                            .isPremium) {
                                                          context.pushNamed(
                                                            Story5FaridaWidget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                          FFAppState()
                                                              .addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory5
                                                                      .toString());
                                                          safeSetState(() {});
                                                        } else {
                                                          if (FFAppState()
                                                              .ReadStoriesList
                                                              .contains(FFAppState()
                                                                  .currentStoryID)) {
                                                            context.pushNamed(
                                                              Story5FaridaWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory5
                                                                        .toString());
                                                            safeSetState(() {});
                                                          } else {
                                                            if (dateTimeFormat(
                                                                  "yMd",
                                                                  FFAppState()
                                                                      .lastReadingTime,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                ) !=
                                                                dateTimeFormat(
                                                                  "yMd",
                                                                  getCurrentTimestamp,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                )) {
                                                              FFAppState()
                                                                      .dailyStoryCount =
                                                                  FFAppState()
                                                                          .dailyStoryCount +
                                                                      1;
                                                              FFAppState()
                                                                      .lastReadingTime =
                                                                  getCurrentTimestamp;
                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});

                                                              context.pushNamed(
                                                                Story5FaridaWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );

                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});
                                                              FFAppState().addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory5
                                                                      .toString());
                                                              safeSetState(
                                                                  () {});
                                                            } else {
                                                              if (FFAppState()
                                                                      .dailyStoryCount <
                                                                  2) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story5FaridaWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                                FFAppState().addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory5
                                                                        .toString());
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                await showModalBottomSheet(
                                                                  isScrollControlled:
                                                                      true,
                                                                  backgroundColor:
                                                                      Colors
                                                                          .transparent,
                                                                  enableDrag:
                                                                      false,
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (context) {
                                                                    return GestureDetector(
                                                                      onTap:
                                                                          () {
                                                                        FocusScope.of(context)
                                                                            .unfocus();
                                                                        FocusManager
                                                                            .instance
                                                                            .primaryFocus
                                                                            ?.unfocus();
                                                                      },
                                                                      child:
                                                                          Padding(
                                                                        padding:
                                                                            MediaQuery.viewInsetsOf(context),
                                                                        child:
                                                                            Container(
                                                                          height:
                                                                              300.0,
                                                                          child:
                                                                              DailyLimitSheetWidget(),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  },
                                                                ).then((value) =>
                                                                    safeSetState(
                                                                        () {}));
                                                              }
                                                            }
                                                          }
                                                        }
                                                      },
                                                      text: 'اقرَأ المزيــد',
                                                      options: FFButtonOptions(
                                                        height: 40.0,
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    16.0,
                                                                    0.0,
                                                                    16.0,
                                                                    0.0),
                                                        iconPadding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        color:
                                                            Color(0xFFEEA667),
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .override(
                                                                  fontFamily:
                                                                      'Tajawal ',
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      18.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                        elevation: 0.0,
                                                        borderSide: BorderSide(
                                                          width: 1.0,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                      ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Align(
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 40.0, 0.0, 100.0),
                                          child: Card(
                                            clipBehavior:
                                                Clip.antiAliasWithSaveLayer,
                                            color: Color(0xFFFFF1E9),
                                            elevation: 0.0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, -1.0),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        10.0, 0.0, 10.0, 0.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Expanded(
                                                      child: InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        focusColor:
                                                            Colors.transparent,
                                                        hoverColor:
                                                            Colors.transparent,
                                                        highlightColor:
                                                            Colors.transparent,
                                                        onTap: () async {
                                                          _model.soundPlayer13 ??=
                                                              AudioPlayer();
                                                          if (_model
                                                              .soundPlayer13!
                                                              .playing) {
                                                            await _model
                                                                .soundPlayer13!
                                                                .stop();
                                                          }
                                                          _model.soundPlayer13!
                                                              .setVolume(1.0);
                                                          _model.soundPlayer13!
                                                              .setAsset(
                                                                  'assets/audios/tapSound.mp3')
                                                              .then((_) => _model
                                                                  .soundPlayer13!
                                                                  .play());

                                                          FFAppState()
                                                                  .currentStoryID =
                                                              FFAppState()
                                                                  .IDStory6;
                                                          safeSetState(() {});
                                                          if (FFAppState()
                                                              .isPremium) {
                                                            context.pushNamed(
                                                              Story6DoriWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                            safeSetState(() {});
                                                          } else {
                                                            if (FFAppState()
                                                                .ReadStoriesList
                                                                .contains(
                                                                    FFAppState()
                                                                        .currentStoryID)) {
                                                              context.pushNamed(
                                                                Story6DoriWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );
                                                            } else {
                                                              if (dateTimeFormat(
                                                                    "yMd",
                                                                    FFAppState()
                                                                        .lastReadingTime,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ) !=
                                                                  dateTimeFormat(
                                                                    "yMd",
                                                                    getCurrentTimestamp,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  )) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState()
                                                                        .lastReadingTime =
                                                                    getCurrentTimestamp;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story6DoriWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                if (FFAppState()
                                                                        .dailyStoryCount <
                                                                    2) {
                                                                  FFAppState()
                                                                          .dailyStoryCount =
                                                                      FFAppState()
                                                                              .dailyStoryCount +
                                                                          1;
                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});

                                                                  context
                                                                      .pushNamed(
                                                                    Story6DoriWidget
                                                                        .routeName,
                                                                    extra: <String,
                                                                        dynamic>{
                                                                      '__transition_info__':
                                                                          TransitionInfo(
                                                                        hasTransition:
                                                                            true,
                                                                        transitionType:
                                                                            PageTransitionType.fade,
                                                                      ),
                                                                    },
                                                                  );

                                                                  FFAppState().addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                                  safeSetState(
                                                                      () {});
                                                                } else {
                                                                  await showModalBottomSheet(
                                                                    isScrollControlled:
                                                                        true,
                                                                    backgroundColor:
                                                                        Colors
                                                                            .transparent,
                                                                    enableDrag:
                                                                        false,
                                                                    context:
                                                                        context,
                                                                    builder:
                                                                        (context) {
                                                                      return GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          FocusScope.of(context)
                                                                              .unfocus();
                                                                          FocusManager
                                                                              .instance
                                                                              .primaryFocus
                                                                              ?.unfocus();
                                                                        },
                                                                        child:
                                                                            Padding(
                                                                          padding:
                                                                              MediaQuery.viewInsetsOf(context),
                                                                          child:
                                                                              Container(
                                                                            height:
                                                                                300.0,
                                                                            child:
                                                                                DailyLimitSheetWidget(),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    },
                                                                  ).then((value) =>
                                                                      safeSetState(
                                                                          () {}));
                                                                }
                                                              }
                                                            }
                                                          }
                                                        },
                                                        child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                          child:
                                                              CachedNetworkImage(
                                                            fadeInDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            fadeOutDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            imageUrl:
                                                                'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1769448560/01_xvvxar.png',
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                0.8,
                                                            height: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .height *
                                                                0.45,
                                                            fit: BoxFit.contain,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Text(
                                                        'يَعِيشُ عُصْفُورُ الدُّورِيِّ الصَّغِيرُ فِي شَجَرَةٍ طَوِيلَةٍ عَالِيَةٍ.. \n\nلَقَدْ كَبُرَ، وَعَلَيْهِ أَنْ يَطِيرَ.. \nلَكِنَّهُ خَائِفٌ مِمَّا قَدْ يَصِيرُ! \n\nعَنْ قِصَّةِ (بِرَارْثَانَا كُورَارَاجْ)- بِتَصَرُّفٍ',
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: FlutterFlowTheme
                                                                .of(context)
                                                            .bodyLarge
                                                            .override(
                                                              fontFamily:
                                                                  'Tajawal ',
                                                              color: Color(
                                                                  0xFF080101),
                                                              fontSize: 18.0,
                                                              letterSpacing:
                                                                  0.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                            ),
                                                      ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                    FFButtonWidget(
                                                      onPressed: () async {
                                                        _model.soundPlayer14 ??=
                                                            AudioPlayer();
                                                        if (_model
                                                            .soundPlayer14!
                                                            .playing) {
                                                          await _model
                                                              .soundPlayer14!
                                                              .stop();
                                                        }
                                                        _model.soundPlayer14!
                                                            .setVolume(1.0);
                                                        _model.soundPlayer14!
                                                            .setAsset(
                                                                'assets/audios/tapSound.mp3')
                                                            .then((_) => _model
                                                                .soundPlayer14!
                                                                .play());

                                                        FFAppState()
                                                                .currentStoryID =
                                                            FFAppState()
                                                                .IDStory6;
                                                        safeSetState(() {});
                                                        if (FFAppState()
                                                            .isPremium) {
                                                          context.pushNamed(
                                                            Story6DoriWidget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                          FFAppState()
                                                              .addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory6
                                                                      .toString());
                                                          safeSetState(() {});
                                                        } else {
                                                          if (FFAppState()
                                                              .ReadStoriesList
                                                              .contains(FFAppState()
                                                                  .currentStoryID)) {
                                                            context.pushNamed(
                                                              Story6DoriWidget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory6
                                                                        .toString());
                                                            safeSetState(() {});
                                                          } else {
                                                            if (dateTimeFormat(
                                                                  "yMd",
                                                                  FFAppState()
                                                                      .lastReadingTime,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                ) !=
                                                                dateTimeFormat(
                                                                  "yMd",
                                                                  getCurrentTimestamp,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                )) {
                                                              FFAppState()
                                                                      .dailyStoryCount =
                                                                  FFAppState()
                                                                          .dailyStoryCount +
                                                                      1;
                                                              FFAppState()
                                                                      .lastReadingTime =
                                                                  getCurrentTimestamp;
                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});

                                                              context.pushNamed(
                                                                Story6DoriWidget
                                                                    .routeName,
                                                                extra: <String,
                                                                    dynamic>{
                                                                  '__transition_info__':
                                                                      TransitionInfo(
                                                                    hasTransition:
                                                                        true,
                                                                    transitionType:
                                                                        PageTransitionType
                                                                            .fade,
                                                                  ),
                                                                },
                                                              );

                                                              FFAppState()
                                                                  .addToReadStoriesList(
                                                                      FFAppState()
                                                                          .currentStoryID);
                                                              safeSetState(
                                                                  () {});
                                                              FFAppState().addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory6
                                                                      .toString());
                                                              safeSetState(
                                                                  () {});
                                                            } else {
                                                              if (FFAppState()
                                                                      .dailyStoryCount <
                                                                  2) {
                                                                FFAppState()
                                                                        .dailyStoryCount =
                                                                    FFAppState()
                                                                            .dailyStoryCount +
                                                                        1;
                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});

                                                                context
                                                                    .pushNamed(
                                                                  Story6DoriWidget
                                                                      .routeName,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    '__transition_info__':
                                                                        TransitionInfo(
                                                                      hasTransition:
                                                                          true,
                                                                      transitionType:
                                                                          PageTransitionType
                                                                              .fade,
                                                                    ),
                                                                  },
                                                                );

                                                                FFAppState().addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                                safeSetState(
                                                                    () {});
                                                                FFAppState().addToReadStoryIDs(
                                                                    FFAppState()
                                                                        .IDStory6
                                                                        .toString());
                                                                safeSetState(
                                                                    () {});
                                                              } else {
                                                                await showModalBottomSheet(
                                                                  isScrollControlled:
                                                                      true,
                                                                  backgroundColor:
                                                                      Colors
                                                                          .transparent,
                                                                  enableDrag:
                                                                      false,
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (context) {
                                                                    return GestureDetector(
                                                                      onTap:
                                                                          () {
                                                                        FocusScope.of(context)
                                                                            .unfocus();
                                                                        FocusManager
                                                                            .instance
                                                                            .primaryFocus
                                                                            ?.unfocus();
                                                                      },
                                                                      child:
                                                                          Padding(
                                                                        padding:
                                                                            MediaQuery.viewInsetsOf(context),
                                                                        child:
                                                                            Container(
                                                                          height:
                                                                              300.0,
                                                                          child:
                                                                              DailyLimitSheetWidget(),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  },
                                                                ).then((value) =>
                                                                    safeSetState(
                                                                        () {}));
                                                              }
                                                            }
                                                          }
                                                        }
                                                      },
                                                      text: 'اقرَأ المزيــد',
                                                      options: FFButtonOptions(
                                                        height: 40.0,
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    16.0,
                                                                    0.0,
                                                                    16.0,
                                                                    0.0),
                                                        iconPadding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        color:
                                                            Color(0xFFEEA667),
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .override(
                                                                  fontFamily:
                                                                      'Tajawal ',
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      18.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                        elevation: 0.0,
                                                        borderSide: BorderSide(
                                                          width: 1.0,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                      ),
                                                    ),
                                                    Divider(
                                                      thickness: 2.0,
                                                      color: Color(0xFF010509),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 5.0, 0.0, 0.0),
                                  child: Text(
                                    'محبو القصص ( +10 سنوات)',
                                    textAlign: TextAlign.center,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Tajawal ',
                                          color: Color(0xFF0E161C),
                                          fontSize: 18.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                ),
                                Flexible(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 5.0, 0.0, 0.0),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8.0),
                                      child: CachedNetworkImage(
                                        fadeInDuration:
                                            Duration(milliseconds: 500),
                                        fadeOutDuration:
                                            Duration(milliseconds: 500),
                                        imageUrl:
                                            'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1771197889/01_vls7vo.png',
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                0.598,
                                        height:
                                            MediaQuery.sizeOf(context).height *
                                                0.3,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 5.0, 0.0, 5.0),
                                  child: Text(
                                    'سَيِّدِي.. لِمَاذَا ظِلُّكَ لَهُ شَكْلُ ثَعْلَبٍ؟! \n\nعِنْدَمَا غَرُبَتِ الشَّمْسُ، لَوَّحَ الرَّجُلُ مِنْ الْبِقالَةِ مُوَدِّعًا سَلْمَى بِابْتِسَامَةٍ وَاسِعَةٍ، وَهُنَا، لَاحَظَتْ سَلْمَى شَيْئًا غَرِيبًا.. \nلِهَذَا الرَّجُلِ ظِلٌّ طَوِيلٌ عَلَى الْأَرْضِ؛ ظَلُّ ثَعْلَبٍ لَهُ سَبْعَةُ ذُيُولٍ!!\n قِصَّةٌ مُسْتَوْحَاةٌ مِنْ الْأَدَبِ الْيَابَانِيِّ- بِتَصَرُّفٍ ',
                                    textAlign: TextAlign.center,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Tajawal ',
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                          fontSize: 17.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                ),
                                Expanded(
                                  child: ListView(
                                    padding: EdgeInsets.zero,
                                    shrinkWrap: true,
                                    scrollDirection: Axis.vertical,
                                    children: [
                                      Container(
                                        width: 100.0,
                                        height: 100.0,
                                        decoration: BoxDecoration(
                                          gradient: LinearGradient(
                                            colors: [
                                              Color(0xFFF4AF9A),
                                              Colors.white
                                            ],
                                            stops: [0.0, 1.0],
                                            begin:
                                                AlignmentDirectional(0.0, -1.0),
                                            end: AlignmentDirectional(0, 1.0),
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(2.0),
                                          border: Border.all(
                                            color: FlutterFlowTheme.of(context)
                                                .accent3,
                                            width: 2.0,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Flexible(
                                              child: InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  _model.soundPlayer16 ??=
                                                      AudioPlayer();
                                                  if (_model
                                                      .soundPlayer16!.playing) {
                                                    await _model.soundPlayer16!
                                                        .stop();
                                                  }
                                                  _model.soundPlayer16!
                                                      .setVolume(1.0);
                                                  _model.soundPlayer16!
                                                      .setAsset(
                                                          'assets/audios/tapSound.mp3')
                                                      .then((_) => _model
                                                          .soundPlayer16!
                                                          .play());

                                                  FFAppState().currentStoryID =
                                                      FFAppState().IDStory111;
                                                  safeSetState(() {});
                                                  if (FFAppState().isPremium) {
                                                    context.pushNamed(
                                                      Story11Part1Widget
                                                          .routeName,
                                                      extra: <String, dynamic>{
                                                        '__transition_info__':
                                                            TransitionInfo(
                                                          hasTransition: true,
                                                          transitionType:
                                                              PageTransitionType
                                                                  .fade,
                                                        ),
                                                      },
                                                    );

                                                    FFAppState()
                                                        .addToReadStoriesList(
                                                            FFAppState()
                                                                .currentStoryID);
                                                    safeSetState(() {});
                                                  } else {
                                                    if (FFAppState()
                                                        .ReadStoriesList
                                                        .contains(FFAppState()
                                                            .currentStoryID)) {
                                                      context.pushNamed(
                                                        Story11Part1Widget
                                                            .routeName,
                                                        extra: <String,
                                                            dynamic>{
                                                          '__transition_info__':
                                                              TransitionInfo(
                                                            hasTransition: true,
                                                            transitionType:
                                                                PageTransitionType
                                                                    .fade,
                                                          ),
                                                        },
                                                      );
                                                    } else {
                                                      if (dateTimeFormat(
                                                            "yMd",
                                                            FFAppState()
                                                                .lastReadingTime,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          ) !=
                                                          dateTimeFormat(
                                                            "yMd",
                                                            getCurrentTimestamp,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          )) {
                                                        FFAppState()
                                                                .dailyStoryCount =
                                                            FFAppState()
                                                                    .dailyStoryCount +
                                                                1;
                                                        FFAppState()
                                                                .lastReadingTime =
                                                            getCurrentTimestamp;
                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});

                                                        context.pushNamed(
                                                          Story11Part1Widget
                                                              .routeName,
                                                          extra: <String,
                                                              dynamic>{
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );

                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});
                                                      } else {
                                                        if (FFAppState()
                                                                .dailyStoryCount <
                                                            2) {
                                                          FFAppState()
                                                                  .dailyStoryCount =
                                                              FFAppState()
                                                                      .dailyStoryCount +
                                                                  1;
                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});

                                                          context.pushNamed(
                                                            Story11Part1Widget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                        } else {
                                                          await showModalBottomSheet(
                                                            isScrollControlled:
                                                                true,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            enableDrag: false,
                                                            context: context,
                                                            builder: (context) {
                                                              return GestureDetector(
                                                                onTap: () {
                                                                  FocusScope.of(
                                                                          context)
                                                                      .unfocus();
                                                                  FocusManager
                                                                      .instance
                                                                      .primaryFocus
                                                                      ?.unfocus();
                                                                },
                                                                child: Padding(
                                                                  padding: MediaQuery
                                                                      .viewInsetsOf(
                                                                          context),
                                                                  child:
                                                                      Container(
                                                                    height:
                                                                        300.0,
                                                                    child:
                                                                        DailyLimitSheetWidget(),
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          ).then((value) =>
                                                              safeSetState(
                                                                  () {}));
                                                        }
                                                      }
                                                    }
                                                  }
                                                },
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                  child: CachedNetworkImage(
                                                    fadeInDuration: Duration(
                                                        milliseconds: 500),
                                                    fadeOutDuration: Duration(
                                                        milliseconds: 500),
                                                    imageUrl:
                                                        'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1771197897/02_dged6w.png',
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        1.0,
                                                    height: 200.0,
                                                    fit: BoxFit.contain,
                                                    alignment:
                                                        Alignment(0.0, 0.0),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      10.0, 0.0, 0.0, 0.0),
                                              child: Text(
                                                'الجزء الأول: \n\nسلمى في مكان جديد',
                                                textAlign: TextAlign.center,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Tajawal ',
                                                          fontSize: 17.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                              ),
                                            ),
                                            FFButtonWidget(
                                              onPressed: () async {
                                                _model.soundPlayer17 ??=
                                                    AudioPlayer();
                                                if (_model
                                                    .soundPlayer17!.playing) {
                                                  await _model.soundPlayer17!
                                                      .stop();
                                                }
                                                _model.soundPlayer17!
                                                    .setVolume(1.0);
                                                _model.soundPlayer17!
                                                    .setAsset(
                                                        'assets/audios/tapSound.mp3')
                                                    .then((_) => _model
                                                        .soundPlayer17!
                                                        .play());

                                                FFAppState().currentStoryID =
                                                    FFAppState().IDStory111;
                                                safeSetState(() {});
                                                if (FFAppState().isPremium) {
                                                  context.pushNamed(
                                                    Story11Part1Widget
                                                        .routeName,
                                                    extra: <String, dynamic>{
                                                      '__transition_info__':
                                                          TransitionInfo(
                                                        hasTransition: true,
                                                        transitionType:
                                                            PageTransitionType
                                                                .fade,
                                                      ),
                                                    },
                                                  );

                                                  FFAppState()
                                                      .addToReadStoriesList(
                                                          FFAppState()
                                                              .currentStoryID);
                                                  safeSetState(() {});
                                                  FFAppState()
                                                      .addToReadStoryIDs(
                                                          FFAppState()
                                                              .IDStory111
                                                              .toString());
                                                  safeSetState(() {});
                                                } else {
                                                  if (FFAppState()
                                                      .ReadStoriesList
                                                      .contains(FFAppState()
                                                          .currentStoryID)) {
                                                    context.pushNamed(
                                                      Story11Part1Widget
                                                          .routeName,
                                                      extra: <String, dynamic>{
                                                        '__transition_info__':
                                                            TransitionInfo(
                                                          hasTransition: true,
                                                          transitionType:
                                                              PageTransitionType
                                                                  .fade,
                                                        ),
                                                      },
                                                    );

                                                    FFAppState()
                                                        .addToReadStoryIDs(
                                                            FFAppState()
                                                                .IDStory111
                                                                .toString());
                                                    safeSetState(() {});
                                                  } else {
                                                    if (dateTimeFormat(
                                                          "yMd",
                                                          FFAppState()
                                                              .lastReadingTime,
                                                          locale:
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .languageCode,
                                                        ) !=
                                                        dateTimeFormat(
                                                          "yMd",
                                                          getCurrentTimestamp,
                                                          locale:
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .languageCode,
                                                        )) {
                                                      FFAppState()
                                                              .dailyStoryCount =
                                                          FFAppState()
                                                                  .dailyStoryCount +
                                                              1;
                                                      FFAppState()
                                                              .lastReadingTime =
                                                          getCurrentTimestamp;
                                                      FFAppState()
                                                          .addToReadStoriesList(
                                                              FFAppState()
                                                                  .currentStoryID);
                                                      safeSetState(() {});

                                                      context.pushNamed(
                                                        Story11Part1Widget
                                                            .routeName,
                                                        extra: <String,
                                                            dynamic>{
                                                          '__transition_info__':
                                                              TransitionInfo(
                                                            hasTransition: true,
                                                            transitionType:
                                                                PageTransitionType
                                                                    .fade,
                                                          ),
                                                        },
                                                      );

                                                      FFAppState()
                                                          .addToReadStoriesList(
                                                              FFAppState()
                                                                  .currentStoryID);
                                                      safeSetState(() {});
                                                      FFAppState()
                                                          .addToReadStoryIDs(
                                                              FFAppState()
                                                                  .IDStory111
                                                                  .toString());
                                                      safeSetState(() {});
                                                    } else {
                                                      if (FFAppState()
                                                              .dailyStoryCount <
                                                          2) {
                                                        FFAppState()
                                                                .dailyStoryCount =
                                                            FFAppState()
                                                                    .dailyStoryCount +
                                                                1;
                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});

                                                        context.pushNamed(
                                                          Story11Part1Widget
                                                              .routeName,
                                                          extra: <String,
                                                              dynamic>{
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );

                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});
                                                        FFAppState()
                                                            .addToReadStoryIDs(
                                                                FFAppState()
                                                                    .IDStory111
                                                                    .toString());
                                                        safeSetState(() {});
                                                      } else {
                                                        await showModalBottomSheet(
                                                          isScrollControlled:
                                                              true,
                                                          backgroundColor:
                                                              Colors
                                                                  .transparent,
                                                          enableDrag: false,
                                                          context: context,
                                                          builder: (context) {
                                                            return GestureDetector(
                                                              onTap: () {
                                                                FocusScope.of(
                                                                        context)
                                                                    .unfocus();
                                                                FocusManager
                                                                    .instance
                                                                    .primaryFocus
                                                                    ?.unfocus();
                                                              },
                                                              child: Padding(
                                                                padding: MediaQuery
                                                                    .viewInsetsOf(
                                                                        context),
                                                                child:
                                                                    Container(
                                                                  height: 300.0,
                                                                  child:
                                                                      DailyLimitSheetWidget(),
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                        ).then((value) =>
                                                            safeSetState(
                                                                () {}));
                                                      }
                                                    }
                                                  }
                                                }
                                              },
                                              text: 'اقرَأ المزيــد',
                                              options: FFButtonOptions(
                                                height: 31.47,
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        5.0, 0.0, 5.0, 0.0),
                                                iconPadding:
                                                    EdgeInsetsDirectional
                                                        .fromSTEB(
                                                            0.0, 0.0, 0.0, 0.0),
                                                color: Color(0xFFEEA667),
                                                textStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .override(
                                                          fontFamily:
                                                              'Tajawal ',
                                                          color: Colors.white,
                                                          fontSize: 18.0,
                                                          letterSpacing: 0.0,
                                                        ),
                                                elevation: 0.0,
                                                borderSide: BorderSide(
                                                  width: 1.0,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        width: 100.0,
                                        height: 100.0,
                                        decoration: BoxDecoration(
                                          gradient: LinearGradient(
                                            colors: [
                                              Color(0xFFF4AF9A),
                                              Colors.white
                                            ],
                                            stops: [0.0, 1.0],
                                            begin:
                                                AlignmentDirectional(0.0, -1.0),
                                            end: AlignmentDirectional(0, 1.0),
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(0.0),
                                          border: Border.all(
                                            color: FlutterFlowTheme.of(context)
                                                .accent3,
                                            width: 2.0,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Flexible(
                                              child: InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  _model.soundPlayer18 ??=
                                                      AudioPlayer();
                                                  if (_model
                                                      .soundPlayer18!.playing) {
                                                    await _model.soundPlayer18!
                                                        .stop();
                                                  }
                                                  _model.soundPlayer18!
                                                      .setVolume(1.0);
                                                  _model.soundPlayer18!
                                                      .setAsset(
                                                          'assets/audios/tapSound.mp3')
                                                      .then((_) => _model
                                                          .soundPlayer18!
                                                          .play());

                                                  FFAppState().currentStoryID =
                                                      FFAppState().IDStory112;
                                                  safeSetState(() {});
                                                  if (FFAppState().isPremium) {
                                                    context.pushNamed(
                                                      Story11Part2Widget
                                                          .routeName,
                                                      extra: <String, dynamic>{
                                                        '__transition_info__':
                                                            TransitionInfo(
                                                          hasTransition: true,
                                                          transitionType:
                                                              PageTransitionType
                                                                  .fade,
                                                        ),
                                                      },
                                                    );

                                                    FFAppState()
                                                        .addToReadStoriesList(
                                                            FFAppState()
                                                                .currentStoryID);
                                                    safeSetState(() {});
                                                  } else {
                                                    if (FFAppState()
                                                        .ReadStoriesList
                                                        .contains(FFAppState()
                                                            .currentStoryID)) {
                                                      context.pushNamed(
                                                        Story11Part2Widget
                                                            .routeName,
                                                        extra: <String,
                                                            dynamic>{
                                                          '__transition_info__':
                                                              TransitionInfo(
                                                            hasTransition: true,
                                                            transitionType:
                                                                PageTransitionType
                                                                    .fade,
                                                          ),
                                                        },
                                                      );
                                                    } else {
                                                      if (dateTimeFormat(
                                                            "yMd",
                                                            FFAppState()
                                                                .lastReadingTime,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          ) !=
                                                          dateTimeFormat(
                                                            "yMd",
                                                            getCurrentTimestamp,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          )) {
                                                        FFAppState()
                                                                .dailyStoryCount =
                                                            FFAppState()
                                                                    .dailyStoryCount +
                                                                1;
                                                        FFAppState()
                                                                .lastReadingTime =
                                                            getCurrentTimestamp;
                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});

                                                        context.pushNamed(
                                                          Story11Part2Widget
                                                              .routeName,
                                                          extra: <String,
                                                              dynamic>{
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );

                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});
                                                      } else {
                                                        if (FFAppState()
                                                                .dailyStoryCount <
                                                            2) {
                                                          FFAppState()
                                                                  .dailyStoryCount =
                                                              FFAppState()
                                                                      .dailyStoryCount +
                                                                  1;
                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});

                                                          context.pushNamed(
                                                            Story11Part2Widget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                        } else {
                                                          await showModalBottomSheet(
                                                            isScrollControlled:
                                                                true,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            enableDrag: false,
                                                            context: context,
                                                            builder: (context) {
                                                              return GestureDetector(
                                                                onTap: () {
                                                                  FocusScope.of(
                                                                          context)
                                                                      .unfocus();
                                                                  FocusManager
                                                                      .instance
                                                                      .primaryFocus
                                                                      ?.unfocus();
                                                                },
                                                                child: Padding(
                                                                  padding: MediaQuery
                                                                      .viewInsetsOf(
                                                                          context),
                                                                  child:
                                                                      Container(
                                                                    height:
                                                                        300.0,
                                                                    child:
                                                                        DailyLimitSheetWidget(),
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          ).then((value) =>
                                                              safeSetState(
                                                                  () {}));
                                                        }
                                                      }
                                                    }
                                                  }
                                                },
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                  child: CachedNetworkImage(
                                                    fadeInDuration: Duration(
                                                        milliseconds: 500),
                                                    fadeOutDuration: Duration(
                                                        milliseconds: 500),
                                                    imageUrl:
                                                        'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1771197900/03_z7urko.png',
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        1.0,
                                                    height: 200.0,
                                                    fit: BoxFit.contain,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      10.0, 0.0, 0.0, 0.0),
                                              child: Text(
                                                'الجزء الثاني: \n\nكيف سأتحدث اليابانية؟',
                                                textAlign: TextAlign.center,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Tajawal ',
                                                          fontSize: 17.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                              ),
                                            ),
                                            FFButtonWidget(
                                              onPressed: () async {
                                                _model.soundPlayer19 ??=
                                                    AudioPlayer();
                                                if (_model
                                                    .soundPlayer19!.playing) {
                                                  await _model.soundPlayer19!
                                                      .stop();
                                                }
                                                _model.soundPlayer19!
                                                    .setVolume(1.0);
                                                _model.soundPlayer19!
                                                    .setAsset(
                                                        'assets/audios/tapSound.mp3')
                                                    .then((_) => _model
                                                        .soundPlayer19!
                                                        .play());

                                                FFAppState().currentStoryID =
                                                    FFAppState().IDStory112;
                                                safeSetState(() {});
                                                if (FFAppState().isPremium) {
                                                  context.pushNamed(
                                                    Story11Part2Widget
                                                        .routeName,
                                                    extra: <String, dynamic>{
                                                      '__transition_info__':
                                                          TransitionInfo(
                                                        hasTransition: true,
                                                        transitionType:
                                                            PageTransitionType
                                                                .fade,
                                                      ),
                                                    },
                                                  );

                                                  FFAppState()
                                                      .addToReadStoriesList(
                                                          FFAppState()
                                                              .currentStoryID);
                                                  safeSetState(() {});
                                                  FFAppState()
                                                      .addToReadStoryIDs(
                                                          FFAppState()
                                                              .IDStory112
                                                              .toString());
                                                  safeSetState(() {});
                                                } else {
                                                  if (FFAppState()
                                                      .ReadStoriesList
                                                      .contains(FFAppState()
                                                          .currentStoryID)) {
                                                    context.pushNamed(
                                                      Story11Part2Widget
                                                          .routeName,
                                                      extra: <String, dynamic>{
                                                        '__transition_info__':
                                                            TransitionInfo(
                                                          hasTransition: true,
                                                          transitionType:
                                                              PageTransitionType
                                                                  .fade,
                                                        ),
                                                      },
                                                    );

                                                    FFAppState()
                                                        .addToReadStoryIDs(
                                                            FFAppState()
                                                                .IDStory112
                                                                .toString());
                                                    safeSetState(() {});
                                                  } else {
                                                    if (dateTimeFormat(
                                                          "yMd",
                                                          FFAppState()
                                                              .lastReadingTime,
                                                          locale:
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .languageCode,
                                                        ) !=
                                                        dateTimeFormat(
                                                          "yMd",
                                                          getCurrentTimestamp,
                                                          locale:
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .languageCode,
                                                        )) {
                                                      FFAppState()
                                                              .dailyStoryCount =
                                                          FFAppState()
                                                                  .dailyStoryCount +
                                                              1;
                                                      FFAppState()
                                                              .lastReadingTime =
                                                          getCurrentTimestamp;
                                                      FFAppState()
                                                          .addToReadStoriesList(
                                                              FFAppState()
                                                                  .currentStoryID);
                                                      safeSetState(() {});

                                                      context.pushNamed(
                                                        Story11Part2Widget
                                                            .routeName,
                                                        extra: <String,
                                                            dynamic>{
                                                          '__transition_info__':
                                                              TransitionInfo(
                                                            hasTransition: true,
                                                            transitionType:
                                                                PageTransitionType
                                                                    .fade,
                                                          ),
                                                        },
                                                      );

                                                      FFAppState()
                                                          .addToReadStoriesList(
                                                              FFAppState()
                                                                  .currentStoryID);
                                                      safeSetState(() {});
                                                      FFAppState()
                                                          .addToReadStoryIDs(
                                                              FFAppState()
                                                                  .IDStory112
                                                                  .toString());
                                                      safeSetState(() {});
                                                    } else {
                                                      if (FFAppState()
                                                              .dailyStoryCount <
                                                          2) {
                                                        FFAppState()
                                                                .dailyStoryCount =
                                                            FFAppState()
                                                                    .dailyStoryCount +
                                                                1;
                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});

                                                        context.pushNamed(
                                                          Story11Part2Widget
                                                              .routeName,
                                                          extra: <String,
                                                              dynamic>{
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );

                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});
                                                        FFAppState()
                                                            .addToReadStoryIDs(
                                                                FFAppState()
                                                                    .IDStory112
                                                                    .toString());
                                                        safeSetState(() {});
                                                      } else {
                                                        await showModalBottomSheet(
                                                          isScrollControlled:
                                                              true,
                                                          backgroundColor:
                                                              Colors
                                                                  .transparent,
                                                          enableDrag: false,
                                                          context: context,
                                                          builder: (context) {
                                                            return GestureDetector(
                                                              onTap: () {
                                                                FocusScope.of(
                                                                        context)
                                                                    .unfocus();
                                                                FocusManager
                                                                    .instance
                                                                    .primaryFocus
                                                                    ?.unfocus();
                                                              },
                                                              child: Padding(
                                                                padding: MediaQuery
                                                                    .viewInsetsOf(
                                                                        context),
                                                                child:
                                                                    Container(
                                                                  height: 300.0,
                                                                  child:
                                                                      DailyLimitSheetWidget(),
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                        ).then((value) =>
                                                            safeSetState(
                                                                () {}));
                                                      }
                                                    }
                                                  }
                                                }
                                              },
                                              text: 'اقرَأ المزيــد',
                                              options: FFButtonOptions(
                                                height: 31.47,
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        5.0, 0.0, 5.0, 0.0),
                                                iconPadding:
                                                    EdgeInsetsDirectional
                                                        .fromSTEB(
                                                            0.0, 0.0, 0.0, 0.0),
                                                color: Color(0xFFEEA667),
                                                textStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .override(
                                                          fontFamily:
                                                              'Tajawal ',
                                                          color: Colors.white,
                                                          fontSize: 18.0,
                                                          letterSpacing: 0.0,
                                                        ),
                                                elevation: 0.0,
                                                borderSide: BorderSide(
                                                  width: 1.0,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        width: 100.0,
                                        height: 100.0,
                                        decoration: BoxDecoration(
                                          gradient: LinearGradient(
                                            colors: [
                                              Color(0xFFF4AF9A),
                                              Colors.white
                                            ],
                                            stops: [0.0, 1.0],
                                            begin:
                                                AlignmentDirectional(0.0, -1.0),
                                            end: AlignmentDirectional(0, 1.0),
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(2.0),
                                          border: Border.all(
                                            color: FlutterFlowTheme.of(context)
                                                .accent3,
                                            width: 2.0,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Flexible(
                                              child: InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  _model.soundPlayer20 ??=
                                                      AudioPlayer();
                                                  if (_model
                                                      .soundPlayer20!.playing) {
                                                    await _model.soundPlayer20!
                                                        .stop();
                                                  }
                                                  _model.soundPlayer20!
                                                      .setVolume(1.0);
                                                  _model.soundPlayer20!
                                                      .setAsset(
                                                          'assets/audios/tapSound.mp3')
                                                      .then((_) => _model
                                                          .soundPlayer20!
                                                          .play());

                                                  FFAppState().currentStoryID =
                                                      FFAppState().IDStory113;
                                                  safeSetState(() {});
                                                  if (FFAppState().isPremium) {
                                                    context.pushNamed(
                                                      Story11Part3Widget
                                                          .routeName,
                                                      extra: <String, dynamic>{
                                                        '__transition_info__':
                                                            TransitionInfo(
                                                          hasTransition: true,
                                                          transitionType:
                                                              PageTransitionType
                                                                  .fade,
                                                        ),
                                                      },
                                                    );

                                                    FFAppState()
                                                        .addToReadStoriesList(
                                                            FFAppState()
                                                                .currentStoryID);
                                                    safeSetState(() {});
                                                  } else {
                                                    if (FFAppState()
                                                        .ReadStoriesList
                                                        .contains(FFAppState()
                                                            .currentStoryID)) {
                                                      context.pushNamed(
                                                        Story11Part3Widget
                                                            .routeName,
                                                        extra: <String,
                                                            dynamic>{
                                                          '__transition_info__':
                                                              TransitionInfo(
                                                            hasTransition: true,
                                                            transitionType:
                                                                PageTransitionType
                                                                    .fade,
                                                          ),
                                                        },
                                                      );
                                                    } else {
                                                      if (dateTimeFormat(
                                                            "yMd",
                                                            FFAppState()
                                                                .lastReadingTime,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          ) !=
                                                          dateTimeFormat(
                                                            "yMd",
                                                            getCurrentTimestamp,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          )) {
                                                        FFAppState()
                                                                .dailyStoryCount =
                                                            FFAppState()
                                                                    .dailyStoryCount +
                                                                1;
                                                        FFAppState()
                                                                .lastReadingTime =
                                                            getCurrentTimestamp;
                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});

                                                        context.pushNamed(
                                                          Story11Part3Widget
                                                              .routeName,
                                                          extra: <String,
                                                              dynamic>{
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );

                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});
                                                      } else {
                                                        if (FFAppState()
                                                                .dailyStoryCount <
                                                            2) {
                                                          FFAppState()
                                                                  .dailyStoryCount =
                                                              FFAppState()
                                                                      .dailyStoryCount +
                                                                  1;
                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});

                                                          context.pushNamed(
                                                            Story11Part3Widget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                        } else {
                                                          await showModalBottomSheet(
                                                            isScrollControlled:
                                                                true,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            enableDrag: false,
                                                            context: context,
                                                            builder: (context) {
                                                              return GestureDetector(
                                                                onTap: () {
                                                                  FocusScope.of(
                                                                          context)
                                                                      .unfocus();
                                                                  FocusManager
                                                                      .instance
                                                                      .primaryFocus
                                                                      ?.unfocus();
                                                                },
                                                                child: Padding(
                                                                  padding: MediaQuery
                                                                      .viewInsetsOf(
                                                                          context),
                                                                  child:
                                                                      Container(
                                                                    height:
                                                                        300.0,
                                                                    child:
                                                                        DailyLimitSheetWidget(),
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          ).then((value) =>
                                                              safeSetState(
                                                                  () {}));
                                                        }
                                                      }
                                                    }
                                                  }
                                                },
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                  child: CachedNetworkImage(
                                                    fadeInDuration: Duration(
                                                        milliseconds: 500),
                                                    fadeOutDuration: Duration(
                                                        milliseconds: 500),
                                                    imageUrl:
                                                        'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1771197893/04_ibqgvl.png',
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        1.0,
                                                    height: 200.0,
                                                    fit: BoxFit.contain,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      10.0, 0.0, 0.0, 0.0),
                                              child: Text(
                                                'الجزء الثالث: \n\nنوري... طيف الثعلب',
                                                textAlign: TextAlign.center,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Tajawal ',
                                                          fontSize: 17.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                              ),
                                            ),
                                            FFButtonWidget(
                                              onPressed: () async {
                                                _model.soundPlayer21 ??=
                                                    AudioPlayer();
                                                if (_model
                                                    .soundPlayer21!.playing) {
                                                  await _model.soundPlayer21!
                                                      .stop();
                                                }
                                                _model.soundPlayer21!
                                                    .setVolume(1.0);
                                                _model.soundPlayer21!
                                                    .setAsset(
                                                        'assets/audios/tapSound.mp3')
                                                    .then((_) => _model
                                                        .soundPlayer21!
                                                        .play());

                                                FFAppState().currentStoryID =
                                                    FFAppState().IDStory113;
                                                safeSetState(() {});
                                                if (FFAppState().isPremium) {
                                                  context.pushNamed(
                                                    Story11Part3Widget
                                                        .routeName,
                                                    extra: <String, dynamic>{
                                                      '__transition_info__':
                                                          TransitionInfo(
                                                        hasTransition: true,
                                                        transitionType:
                                                            PageTransitionType
                                                                .fade,
                                                      ),
                                                    },
                                                  );

                                                  FFAppState()
                                                      .addToReadStoriesList(
                                                          FFAppState()
                                                              .currentStoryID);
                                                  safeSetState(() {});
                                                  FFAppState()
                                                      .addToReadStoryIDs(
                                                          FFAppState()
                                                              .IDStory113
                                                              .toString());
                                                  safeSetState(() {});
                                                } else {
                                                  if (FFAppState()
                                                      .ReadStoriesList
                                                      .contains(FFAppState()
                                                          .currentStoryID)) {
                                                    context.pushNamed(
                                                      Story11Part3Widget
                                                          .routeName,
                                                      extra: <String, dynamic>{
                                                        '__transition_info__':
                                                            TransitionInfo(
                                                          hasTransition: true,
                                                          transitionType:
                                                              PageTransitionType
                                                                  .fade,
                                                        ),
                                                      },
                                                    );

                                                    FFAppState()
                                                        .addToReadStoryIDs(
                                                            FFAppState()
                                                                .IDStory113
                                                                .toString());
                                                    safeSetState(() {});
                                                  } else {
                                                    if (dateTimeFormat(
                                                          "yMd",
                                                          FFAppState()
                                                              .lastReadingTime,
                                                          locale:
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .languageCode,
                                                        ) !=
                                                        dateTimeFormat(
                                                          "yMd",
                                                          getCurrentTimestamp,
                                                          locale:
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .languageCode,
                                                        )) {
                                                      FFAppState()
                                                              .dailyStoryCount =
                                                          FFAppState()
                                                                  .dailyStoryCount +
                                                              1;
                                                      FFAppState()
                                                              .lastReadingTime =
                                                          getCurrentTimestamp;
                                                      FFAppState()
                                                          .addToReadStoriesList(
                                                              FFAppState()
                                                                  .currentStoryID);
                                                      safeSetState(() {});

                                                      context.pushNamed(
                                                        Story11Part3Widget
                                                            .routeName,
                                                        extra: <String,
                                                            dynamic>{
                                                          '__transition_info__':
                                                              TransitionInfo(
                                                            hasTransition: true,
                                                            transitionType:
                                                                PageTransitionType
                                                                    .fade,
                                                          ),
                                                        },
                                                      );

                                                      FFAppState()
                                                          .addToReadStoriesList(
                                                              FFAppState()
                                                                  .currentStoryID);
                                                      safeSetState(() {});
                                                      FFAppState()
                                                          .addToReadStoryIDs(
                                                              FFAppState()
                                                                  .IDStory113
                                                                  .toString());
                                                      safeSetState(() {});
                                                    } else {
                                                      if (FFAppState()
                                                              .dailyStoryCount <
                                                          2) {
                                                        FFAppState()
                                                                .dailyStoryCount =
                                                            FFAppState()
                                                                    .dailyStoryCount +
                                                                1;
                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});

                                                        context.pushNamed(
                                                          Story11Part3Widget
                                                              .routeName,
                                                          extra: <String,
                                                              dynamic>{
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );

                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});
                                                        FFAppState()
                                                            .addToReadStoryIDs(
                                                                FFAppState()
                                                                    .IDStory113
                                                                    .toString());
                                                        safeSetState(() {});
                                                      } else {
                                                        await showModalBottomSheet(
                                                          isScrollControlled:
                                                              true,
                                                          backgroundColor:
                                                              Colors
                                                                  .transparent,
                                                          enableDrag: false,
                                                          context: context,
                                                          builder: (context) {
                                                            return GestureDetector(
                                                              onTap: () {
                                                                FocusScope.of(
                                                                        context)
                                                                    .unfocus();
                                                                FocusManager
                                                                    .instance
                                                                    .primaryFocus
                                                                    ?.unfocus();
                                                              },
                                                              child: Padding(
                                                                padding: MediaQuery
                                                                    .viewInsetsOf(
                                                                        context),
                                                                child:
                                                                    Container(
                                                                  height: 300.0,
                                                                  child:
                                                                      DailyLimitSheetWidget(),
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                        ).then((value) =>
                                                            safeSetState(
                                                                () {}));
                                                      }
                                                    }
                                                  }
                                                }
                                              },
                                              text: 'اقرَأ المزيــد',
                                              options: FFButtonOptions(
                                                height: 31.47,
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        5.0, 0.0, 5.0, 0.0),
                                                iconPadding:
                                                    EdgeInsetsDirectional
                                                        .fromSTEB(
                                                            0.0, 0.0, 0.0, 0.0),
                                                color: Color(0xFFEEA667),
                                                textStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .override(
                                                          fontFamily:
                                                              'Tajawal ',
                                                          color: Colors.white,
                                                          fontSize: 18.0,
                                                          letterSpacing: 0.0,
                                                        ),
                                                elevation: 0.0,
                                                borderSide: BorderSide(
                                                  width: 1.0,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        width: 100.0,
                                        height: 100.0,
                                        decoration: BoxDecoration(
                                          gradient: LinearGradient(
                                            colors: [
                                              Color(0xFFF4AF9A),
                                              Colors.white
                                            ],
                                            stops: [0.0, 1.0],
                                            begin:
                                                AlignmentDirectional(0.0, -1.0),
                                            end: AlignmentDirectional(0, 1.0),
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(2.0),
                                          border: Border.all(
                                            color: FlutterFlowTheme.of(context)
                                                .accent3,
                                            width: 2.0,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Flexible(
                                              child: InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  _model.soundPlayer22 ??=
                                                      AudioPlayer();
                                                  if (_model
                                                      .soundPlayer22!.playing) {
                                                    await _model.soundPlayer22!
                                                        .stop();
                                                  }
                                                  _model.soundPlayer22!
                                                      .setVolume(1.0);
                                                  _model.soundPlayer22!
                                                      .setAsset(
                                                          'assets/audios/tapSound.mp3')
                                                      .then((_) => _model
                                                          .soundPlayer22!
                                                          .play());

                                                  FFAppState().currentStoryID =
                                                      FFAppState().IDStory114;
                                                  safeSetState(() {});
                                                  if (FFAppState().isPremium) {
                                                    context.pushNamed(
                                                      Story11Part4Widget
                                                          .routeName,
                                                      extra: <String, dynamic>{
                                                        '__transition_info__':
                                                            TransitionInfo(
                                                          hasTransition: true,
                                                          transitionType:
                                                              PageTransitionType
                                                                  .fade,
                                                        ),
                                                      },
                                                    );

                                                    FFAppState()
                                                        .addToReadStoriesList(
                                                            FFAppState()
                                                                .currentStoryID);
                                                    safeSetState(() {});
                                                  } else {
                                                    if (FFAppState()
                                                        .ReadStoriesList
                                                        .contains(FFAppState()
                                                            .currentStoryID)) {
                                                      context.pushNamed(
                                                        Story11Part4Widget
                                                            .routeName,
                                                        extra: <String,
                                                            dynamic>{
                                                          '__transition_info__':
                                                              TransitionInfo(
                                                            hasTransition: true,
                                                            transitionType:
                                                                PageTransitionType
                                                                    .fade,
                                                          ),
                                                        },
                                                      );
                                                    } else {
                                                      if (dateTimeFormat(
                                                            "yMd",
                                                            FFAppState()
                                                                .lastReadingTime,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          ) !=
                                                          dateTimeFormat(
                                                            "yMd",
                                                            getCurrentTimestamp,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          )) {
                                                        FFAppState()
                                                                .dailyStoryCount =
                                                            FFAppState()
                                                                    .dailyStoryCount +
                                                                1;
                                                        FFAppState()
                                                                .lastReadingTime =
                                                            getCurrentTimestamp;
                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});

                                                        context.pushNamed(
                                                          Story11Part4Widget
                                                              .routeName,
                                                          extra: <String,
                                                              dynamic>{
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );

                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});
                                                      } else {
                                                        if (FFAppState()
                                                                .dailyStoryCount <
                                                            2) {
                                                          FFAppState()
                                                                  .dailyStoryCount =
                                                              FFAppState()
                                                                      .dailyStoryCount +
                                                                  1;
                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});

                                                          context.pushNamed(
                                                            Story11Part4Widget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                        } else {
                                                          await showModalBottomSheet(
                                                            isScrollControlled:
                                                                true,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            enableDrag: false,
                                                            context: context,
                                                            builder: (context) {
                                                              return GestureDetector(
                                                                onTap: () {
                                                                  FocusScope.of(
                                                                          context)
                                                                      .unfocus();
                                                                  FocusManager
                                                                      .instance
                                                                      .primaryFocus
                                                                      ?.unfocus();
                                                                },
                                                                child: Padding(
                                                                  padding: MediaQuery
                                                                      .viewInsetsOf(
                                                                          context),
                                                                  child:
                                                                      Container(
                                                                    height:
                                                                        300.0,
                                                                    child:
                                                                        DailyLimitSheetWidget(),
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          ).then((value) =>
                                                              safeSetState(
                                                                  () {}));
                                                        }
                                                      }
                                                    }
                                                  }
                                                },
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                  child: CachedNetworkImage(
                                                    fadeInDuration: Duration(
                                                        milliseconds: 500),
                                                    fadeOutDuration: Duration(
                                                        milliseconds: 500),
                                                    imageUrl:
                                                        'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1771197893/03_pqsp7q.png',
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        1.0,
                                                    height: 200.0,
                                                    fit: BoxFit.contain,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      10.0, 0.0, 0.0, 0.0),
                                              child: Text(
                                                'الجزء الرابع: \n\nأنتِ بحاجة إلى صديق',
                                                textAlign: TextAlign.center,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Tajawal ',
                                                          fontSize: 17.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                              ),
                                            ),
                                            FFButtonWidget(
                                              onPressed: () async {
                                                _model.soundPlayer23 ??=
                                                    AudioPlayer();
                                                if (_model
                                                    .soundPlayer23!.playing) {
                                                  await _model.soundPlayer23!
                                                      .stop();
                                                }
                                                _model.soundPlayer23!
                                                    .setVolume(1.0);
                                                _model.soundPlayer23!
                                                    .setAsset(
                                                        'assets/audios/tapSound.mp3')
                                                    .then((_) => _model
                                                        .soundPlayer23!
                                                        .play());

                                                FFAppState().currentStoryID =
                                                    FFAppState().IDStory114;
                                                safeSetState(() {});
                                                if (FFAppState().isPremium) {
                                                  context.pushNamed(
                                                    Story11Part4Widget
                                                        .routeName,
                                                    extra: <String, dynamic>{
                                                      '__transition_info__':
                                                          TransitionInfo(
                                                        hasTransition: true,
                                                        transitionType:
                                                            PageTransitionType
                                                                .fade,
                                                      ),
                                                    },
                                                  );

                                                  FFAppState()
                                                      .addToReadStoriesList(
                                                          FFAppState()
                                                              .currentStoryID);
                                                  safeSetState(() {});
                                                  FFAppState()
                                                      .addToReadStoryIDs(
                                                          FFAppState()
                                                              .IDStory114
                                                              .toString());
                                                  safeSetState(() {});
                                                } else {
                                                  if (FFAppState()
                                                      .ReadStoriesList
                                                      .contains(FFAppState()
                                                          .currentStoryID)) {
                                                    context.pushNamed(
                                                      Story11Part4Widget
                                                          .routeName,
                                                      extra: <String, dynamic>{
                                                        '__transition_info__':
                                                            TransitionInfo(
                                                          hasTransition: true,
                                                          transitionType:
                                                              PageTransitionType
                                                                  .fade,
                                                        ),
                                                      },
                                                    );

                                                    FFAppState()
                                                        .addToReadStoryIDs(
                                                            FFAppState()
                                                                .IDStory114
                                                                .toString());
                                                    safeSetState(() {});
                                                  } else {
                                                    if (dateTimeFormat(
                                                          "yMd",
                                                          FFAppState()
                                                              .lastReadingTime,
                                                          locale:
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .languageCode,
                                                        ) !=
                                                        dateTimeFormat(
                                                          "yMd",
                                                          getCurrentTimestamp,
                                                          locale:
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .languageCode,
                                                        )) {
                                                      FFAppState()
                                                              .dailyStoryCount =
                                                          FFAppState()
                                                                  .dailyStoryCount +
                                                              1;
                                                      FFAppState()
                                                              .lastReadingTime =
                                                          getCurrentTimestamp;
                                                      FFAppState()
                                                          .addToReadStoriesList(
                                                              FFAppState()
                                                                  .currentStoryID);
                                                      safeSetState(() {});

                                                      context.pushNamed(
                                                        Story11Part4Widget
                                                            .routeName,
                                                        extra: <String,
                                                            dynamic>{
                                                          '__transition_info__':
                                                              TransitionInfo(
                                                            hasTransition: true,
                                                            transitionType:
                                                                PageTransitionType
                                                                    .fade,
                                                          ),
                                                        },
                                                      );

                                                      FFAppState()
                                                          .addToReadStoriesList(
                                                              FFAppState()
                                                                  .currentStoryID);
                                                      safeSetState(() {});
                                                      FFAppState()
                                                          .addToReadStoryIDs(
                                                              FFAppState()
                                                                  .IDStory114
                                                                  .toString());
                                                      safeSetState(() {});
                                                    } else {
                                                      if (FFAppState()
                                                              .dailyStoryCount <
                                                          2) {
                                                        FFAppState()
                                                                .dailyStoryCount =
                                                            FFAppState()
                                                                    .dailyStoryCount +
                                                                1;
                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});

                                                        context.pushNamed(
                                                          Story11Part4Widget
                                                              .routeName,
                                                          extra: <String,
                                                              dynamic>{
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );

                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});
                                                        FFAppState()
                                                            .addToReadStoryIDs(
                                                                FFAppState()
                                                                    .IDStory114
                                                                    .toString());
                                                        safeSetState(() {});
                                                      } else {
                                                        await showModalBottomSheet(
                                                          isScrollControlled:
                                                              true,
                                                          backgroundColor:
                                                              Colors
                                                                  .transparent,
                                                          enableDrag: false,
                                                          context: context,
                                                          builder: (context) {
                                                            return GestureDetector(
                                                              onTap: () {
                                                                FocusScope.of(
                                                                        context)
                                                                    .unfocus();
                                                                FocusManager
                                                                    .instance
                                                                    .primaryFocus
                                                                    ?.unfocus();
                                                              },
                                                              child: Padding(
                                                                padding: MediaQuery
                                                                    .viewInsetsOf(
                                                                        context),
                                                                child:
                                                                    Container(
                                                                  height: 300.0,
                                                                  child:
                                                                      DailyLimitSheetWidget(),
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                        ).then((value) =>
                                                            safeSetState(
                                                                () {}));
                                                      }
                                                    }
                                                  }
                                                }
                                              },
                                              text: 'اقرَأ المزيــد',
                                              options: FFButtonOptions(
                                                height: 31.47,
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        5.0, 0.0, 5.0, 0.0),
                                                iconPadding:
                                                    EdgeInsetsDirectional
                                                        .fromSTEB(
                                                            0.0, 0.0, 0.0, 0.0),
                                                color: Color(0xFFEEA667),
                                                textStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .override(
                                                          fontFamily:
                                                              'Tajawal ',
                                                          color: Colors.white,
                                                          fontSize: 18.0,
                                                          letterSpacing: 0.0,
                                                        ),
                                                elevation: 0.0,
                                                borderSide: BorderSide(
                                                  width: 1.0,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 0.0, 100.0),
                                        child: Container(
                                          width: 100.0,
                                          height: 100.0,
                                          decoration: BoxDecoration(
                                            gradient: LinearGradient(
                                              colors: [
                                                Color(0xFFF4AF9A),
                                                Colors.white
                                              ],
                                              stops: [0.0, 1.0],
                                              begin: AlignmentDirectional(
                                                  0.0, -1.0),
                                              end: AlignmentDirectional(0, 1.0),
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(2.0),
                                            border: Border.all(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .accent3,
                                              width: 2.0,
                                            ),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Flexible(
                                                child: InkWell(
                                                  splashColor:
                                                      Colors.transparent,
                                                  focusColor:
                                                      Colors.transparent,
                                                  hoverColor:
                                                      Colors.transparent,
                                                  highlightColor:
                                                      Colors.transparent,
                                                  onTap: () async {
                                                    _model.soundPlayer24 ??=
                                                        AudioPlayer();
                                                    if (_model.soundPlayer24!
                                                        .playing) {
                                                      await _model
                                                          .soundPlayer24!
                                                          .stop();
                                                    }
                                                    _model.soundPlayer24!
                                                        .setVolume(1.0);
                                                    _model.soundPlayer24!
                                                        .setAsset(
                                                            'assets/audios/tapSound.mp3')
                                                        .then((_) => _model
                                                            .soundPlayer24!
                                                            .play());

                                                    FFAppState()
                                                            .currentStoryID =
                                                        FFAppState().IDStory115;
                                                    safeSetState(() {});
                                                    if (FFAppState()
                                                        .isPremium) {
                                                      context.pushNamed(
                                                        Story11Part5Widget
                                                            .routeName,
                                                        extra: <String,
                                                            dynamic>{
                                                          '__transition_info__':
                                                              TransitionInfo(
                                                            hasTransition: true,
                                                            transitionType:
                                                                PageTransitionType
                                                                    .fade,
                                                          ),
                                                        },
                                                      );

                                                      FFAppState()
                                                          .addToReadStoriesList(
                                                              FFAppState()
                                                                  .currentStoryID);
                                                      safeSetState(() {});
                                                    } else {
                                                      if (FFAppState()
                                                          .ReadStoriesList
                                                          .contains(FFAppState()
                                                              .currentStoryID)) {
                                                        context.pushNamed(
                                                          Story11Part5Widget
                                                              .routeName,
                                                          extra: <String,
                                                              dynamic>{
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );
                                                      } else {
                                                        if (dateTimeFormat(
                                                              "yMd",
                                                              FFAppState()
                                                                  .lastReadingTime,
                                                              locale: FFLocalizations
                                                                      .of(context)
                                                                  .languageCode,
                                                            ) !=
                                                            dateTimeFormat(
                                                              "yMd",
                                                              getCurrentTimestamp,
                                                              locale: FFLocalizations
                                                                      .of(context)
                                                                  .languageCode,
                                                            )) {
                                                          FFAppState()
                                                                  .dailyStoryCount =
                                                              FFAppState()
                                                                      .dailyStoryCount +
                                                                  1;
                                                          FFAppState()
                                                                  .lastReadingTime =
                                                              getCurrentTimestamp;
                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});

                                                          context.pushNamed(
                                                            Story11Part5Widget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                        } else {
                                                          if (FFAppState()
                                                                  .dailyStoryCount <
                                                              2) {
                                                            FFAppState()
                                                                    .dailyStoryCount =
                                                                FFAppState()
                                                                        .dailyStoryCount +
                                                                    1;
                                                            FFAppState()
                                                                .addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                            safeSetState(() {});

                                                            context.pushNamed(
                                                              Story11Part5Widget
                                                                  .routeName,
                                                              extra: <String,
                                                                  dynamic>{
                                                                '__transition_info__':
                                                                    TransitionInfo(
                                                                  hasTransition:
                                                                      true,
                                                                  transitionType:
                                                                      PageTransitionType
                                                                          .fade,
                                                                ),
                                                              },
                                                            );

                                                            FFAppState()
                                                                .addToReadStoriesList(
                                                                    FFAppState()
                                                                        .currentStoryID);
                                                            safeSetState(() {});
                                                          } else {
                                                            await showModalBottomSheet(
                                                              isScrollControlled:
                                                                  true,
                                                              backgroundColor:
                                                                  Colors
                                                                      .transparent,
                                                              enableDrag: false,
                                                              context: context,
                                                              builder:
                                                                  (context) {
                                                                return GestureDetector(
                                                                  onTap: () {
                                                                    FocusScope.of(
                                                                            context)
                                                                        .unfocus();
                                                                    FocusManager
                                                                        .instance
                                                                        .primaryFocus
                                                                        ?.unfocus();
                                                                  },
                                                                  child:
                                                                      Padding(
                                                                    padding: MediaQuery
                                                                        .viewInsetsOf(
                                                                            context),
                                                                    child:
                                                                        Container(
                                                                      height:
                                                                          300.0,
                                                                      child:
                                                                          DailyLimitSheetWidget(),
                                                                    ),
                                                                  ),
                                                                );
                                                              },
                                                            ).then((value) =>
                                                                safeSetState(
                                                                    () {}));
                                                          }
                                                        }
                                                      }
                                                    }
                                                  },
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8.0),
                                                    child: CachedNetworkImage(
                                                      fadeInDuration: Duration(
                                                          milliseconds: 500),
                                                      fadeOutDuration: Duration(
                                                          milliseconds: 500),
                                                      imageUrl:
                                                          'https://res.cloudinary.com/ditztgnja/image/upload/q_auto,f_auto/v1771197910/03_kmwrsx.png',
                                                      width: MediaQuery.sizeOf(
                                                                  context)
                                                              .width *
                                                          1.0,
                                                      height: 200.0,
                                                      fit: BoxFit.contain,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        30.0, 0.0, 0.0, 0.0),
                                                child: Text(
                                                  'الجزء الخامس: \n\nالخطوة الأولى',
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Tajawal ',
                                                        fontSize: 17.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                                ),
                                              ),
                                              FFButtonWidget(
                                                onPressed: () async {
                                                  _model.soundPlayer25 ??=
                                                      AudioPlayer();
                                                  if (_model
                                                      .soundPlayer25!.playing) {
                                                    await _model.soundPlayer25!
                                                        .stop();
                                                  }
                                                  _model.soundPlayer25!
                                                      .setVolume(1.0);
                                                  _model.soundPlayer25!
                                                      .setAsset(
                                                          'assets/audios/tapSound.mp3')
                                                      .then((_) => _model
                                                          .soundPlayer25!
                                                          .play());

                                                  FFAppState().currentStoryID =
                                                      FFAppState().IDStory115;
                                                  safeSetState(() {});
                                                  if (FFAppState().isPremium) {
                                                    context.pushNamed(
                                                      Story11Part5Widget
                                                          .routeName,
                                                      extra: <String, dynamic>{
                                                        '__transition_info__':
                                                            TransitionInfo(
                                                          hasTransition: true,
                                                          transitionType:
                                                              PageTransitionType
                                                                  .fade,
                                                        ),
                                                      },
                                                    );

                                                    FFAppState()
                                                        .addToReadStoriesList(
                                                            FFAppState()
                                                                .currentStoryID);
                                                    safeSetState(() {});
                                                    FFAppState()
                                                        .addToReadStoryIDs(
                                                            FFAppState()
                                                                .IDStory115
                                                                .toString());
                                                    safeSetState(() {});
                                                  } else {
                                                    if (FFAppState()
                                                        .ReadStoriesList
                                                        .contains(FFAppState()
                                                            .currentStoryID)) {
                                                      context.pushNamed(
                                                        Story11Part5Widget
                                                            .routeName,
                                                        extra: <String,
                                                            dynamic>{
                                                          '__transition_info__':
                                                              TransitionInfo(
                                                            hasTransition: true,
                                                            transitionType:
                                                                PageTransitionType
                                                                    .fade,
                                                          ),
                                                        },
                                                      );

                                                      FFAppState()
                                                          .addToReadStoryIDs(
                                                              FFAppState()
                                                                  .IDStory115
                                                                  .toString());
                                                      safeSetState(() {});
                                                    } else {
                                                      if (dateTimeFormat(
                                                            "yMd",
                                                            FFAppState()
                                                                .lastReadingTime,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          ) !=
                                                          dateTimeFormat(
                                                            "yMd",
                                                            getCurrentTimestamp,
                                                            locale: FFLocalizations
                                                                    .of(context)
                                                                .languageCode,
                                                          )) {
                                                        FFAppState()
                                                                .dailyStoryCount =
                                                            FFAppState()
                                                                    .dailyStoryCount +
                                                                1;
                                                        FFAppState()
                                                                .lastReadingTime =
                                                            getCurrentTimestamp;
                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});

                                                        context.pushNamed(
                                                          Story11Part5Widget
                                                              .routeName,
                                                          extra: <String,
                                                              dynamic>{
                                                            '__transition_info__':
                                                                TransitionInfo(
                                                              hasTransition:
                                                                  true,
                                                              transitionType:
                                                                  PageTransitionType
                                                                      .fade,
                                                            ),
                                                          },
                                                        );

                                                        FFAppState()
                                                            .addToReadStoriesList(
                                                                FFAppState()
                                                                    .currentStoryID);
                                                        safeSetState(() {});
                                                        FFAppState()
                                                            .addToReadStoryIDs(
                                                                FFAppState()
                                                                    .IDStory115
                                                                    .toString());
                                                        safeSetState(() {});
                                                      } else {
                                                        if (FFAppState()
                                                                .dailyStoryCount <
                                                            2) {
                                                          FFAppState()
                                                                  .dailyStoryCount =
                                                              FFAppState()
                                                                      .dailyStoryCount +
                                                                  1;
                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});

                                                          context.pushNamed(
                                                            Story11Part5Widget
                                                                .routeName,
                                                            extra: <String,
                                                                dynamic>{
                                                              '__transition_info__':
                                                                  TransitionInfo(
                                                                hasTransition:
                                                                    true,
                                                                transitionType:
                                                                    PageTransitionType
                                                                        .fade,
                                                              ),
                                                            },
                                                          );

                                                          FFAppState()
                                                              .addToReadStoriesList(
                                                                  FFAppState()
                                                                      .currentStoryID);
                                                          safeSetState(() {});
                                                          FFAppState()
                                                              .addToReadStoryIDs(
                                                                  FFAppState()
                                                                      .IDStory115
                                                                      .toString());
                                                          safeSetState(() {});
                                                        } else {
                                                          await showModalBottomSheet(
                                                            isScrollControlled:
                                                                true,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            enableDrag: false,
                                                            context: context,
                                                            builder: (context) {
                                                              return GestureDetector(
                                                                onTap: () {
                                                                  FocusScope.of(
                                                                          context)
                                                                      .unfocus();
                                                                  FocusManager
                                                                      .instance
                                                                      .primaryFocus
                                                                      ?.unfocus();
                                                                },
                                                                child: Padding(
                                                                  padding: MediaQuery
                                                                      .viewInsetsOf(
                                                                          context),
                                                                  child:
                                                                      Container(
                                                                    height:
                                                                        300.0,
                                                                    child:
                                                                        DailyLimitSheetWidget(),
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          ).then((value) =>
                                                              safeSetState(
                                                                  () {}));
                                                        }
                                                      }
                                                    }
                                                  }
                                                },
                                                text: 'اقرَأ المزيــد',
                                                options: FFButtonOptions(
                                                  height: 31.47,
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          5.0, 0.0, 5.0, 0.0),
                                                  iconPadding:
                                                      EdgeInsetsDirectional
                                                          .fromSTEB(0.0, 0.0,
                                                              0.0, 0.0),
                                                  color: Color(0xFFEEA667),
                                                  textStyle: FlutterFlowTheme
                                                          .of(context)
                                                      .titleSmall
                                                      .override(
                                                        fontFamily: 'Tajawal ',
                                                        color: Colors.white,
                                                        fontSize: 18.0,
                                                        letterSpacing: 0.0,
                                                      ),
                                                  elevation: 0.0,
                                                  borderSide: BorderSide(
                                                    width: 1.0,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ].divide(SizedBox(height: 20.0)),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.0, 0.0),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: Opacity(
                              opacity: 0.8,
                              child: Align(
                                alignment: AlignmentDirectional(0.0, 1.0),
                                child: Container(
                                  width: 70.0,
                                  height: 70.0,
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        blurRadius: 4.0,
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryText,
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                      )
                                    ],
                                    gradient: LinearGradient(
                                      colors: [
                                        FlutterFlowTheme.of(context).tertiary,
                                        Color(0xFFEEE443)
                                      ],
                                      stops: [0.0, 1.0],
                                      begin: AlignmentDirectional(0.0, -1.0),
                                      end: AlignmentDirectional(0, 1.0),
                                    ),
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color:
                                          FlutterFlowTheme.of(context).warning,
                                    ),
                                  ),
                                  alignment: AlignmentDirectional(0.0, 0.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      _model.soundPlayer26 ??= AudioPlayer();
                                      if (_model.soundPlayer26!.playing) {
                                        await _model.soundPlayer26!.stop();
                                      }
                                      _model.soundPlayer26!.setVolume(1.0);
                                      _model.soundPlayer26!
                                          .setAsset(
                                              'assets/audios/tapSound.mp3')
                                          .then((_) =>
                                              _model.soundPlayer26!.play());

                                      context.pushNamed(
                                        FreeLibraryWidget.routeName,
                                        extra: <String, dynamic>{
                                          '__transition_info__': TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                          ),
                                        },
                                      );
                                    },
                                    child: Icon(
                                      FFIcons.kkbooks,
                                      color: Color(0xFF695127),
                                      size: 50.0,
                                    ),
                                  ).animateOnActionTrigger(
                                    animationsMap[
                                        'iconOnActionTriggerAnimation1']!,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Opacity(
                              opacity: 0.8,
                              child: Align(
                                alignment: AlignmentDirectional(0.0, 1.0),
                                child: Container(
                                  width: 70.0,
                                  height: 70.0,
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        blurRadius: 4.0,
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryText,
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                      )
                                    ],
                                    gradient: LinearGradient(
                                      colors: [
                                        FlutterFlowTheme.of(context).tertiary,
                                        Color(0xFFEEE443)
                                      ],
                                      stops: [0.0, 1.0],
                                      begin: AlignmentDirectional(0.0, -1.0),
                                      end: AlignmentDirectional(0, 1.0),
                                    ),
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color:
                                          FlutterFlowTheme.of(context).warning,
                                    ),
                                  ),
                                  alignment: AlignmentDirectional(0.0, 0.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      _model.soundPlayer27 ??= AudioPlayer();
                                      if (_model.soundPlayer27!.playing) {
                                        await _model.soundPlayer27!.stop();
                                      }
                                      _model.soundPlayer27!.setVolume(1.0);
                                      _model.soundPlayer27!
                                          .setAsset(
                                              'assets/audios/tapSound.mp3')
                                          .then((_) =>
                                              _model.soundPlayer27!.play());

                                      context.pushNamed(
                                        PremiumUsersWidget.routeName,
                                        extra: <String, dynamic>{
                                          '__transition_info__': TransitionInfo(
                                            hasTransition: true,
                                            transitionType:
                                                PageTransitionType.fade,
                                          ),
                                        },
                                      );
                                    },
                                    child: Icon(
                                      Icons.shopping_cart_sharp,
                                      color: Color(0xFF695127),
                                      size: 50.0,
                                    ),
                                  ).animateOnActionTrigger(
                                    animationsMap[
                                        'iconOnActionTriggerAnimation2']!,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
